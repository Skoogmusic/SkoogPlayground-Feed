//
// Copyright © 2017 Skoogmusic Inc.  All rights reserved.
//
import UIKit
import PlaygroundSupport
import Common

let viewController = LiveViewController()
viewController.setBackgroundGradient(gradient: .gradient4)
PlaygroundPage.current.liveView = viewController
