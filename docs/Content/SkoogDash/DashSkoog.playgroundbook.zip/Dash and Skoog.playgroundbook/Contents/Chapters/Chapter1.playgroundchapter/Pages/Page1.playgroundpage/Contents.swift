/*:
 Here you can drive Dash using Skoog! Make sure you connect Dash and Skoog, then tap "Run My Code" to start driving.
 
 The different colors on Skoog send different commands to Dash:
 
 Red:       Move Forward
 
 Blue:      Turn Left
 
 Yellow:    Move Backward
 
 Green:     Turn Right
 
 Orange:    Play a sound!
 
 Send a command using a single press on a Skoog side!
 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), moveBackward(), turnLeft(), turnRight(), waitForObstacleInFront(), waitForObstacleInRear(), waitForButton1Press(), waitForButton2Press(), waitForButton3Press(), waitForClap(), playSound(_:), SoundType, Bragging, HereICome, Interesting, Inputs, Horn, Wha, Awesome, CarEngine, Hi, Fantastic, OhNo, setLight(_:), ColorType, Red, Green, Blue, Yellow, White)
//#-hidden-code
setup()
public class DashSkoogListener: SkoogListener {
func press(side: Side, strength: Double) {
    switch side.name {
        case .red:
            moveForward()
            setLight(.Red)
            break
        case .blue:
            turnLeft()
            setLight(.Blue)
            break
        case .yellow:
            moveBackward()
            setLight(.Yellow)
            break
        case .green:
            turnRight()
            setLight(.Green)
            break
        case .orange:
            playSound(.Awesome)
            setLight(.White)
            break
        default:
            break
    }
}
    public override func peak(_ side: Side, _ peak: Double) {
        press(side: side, strength: peak)
    }
}

let dashSkoogListener = DashSkoogListener()
//exitProgram()
//#-end-hidden-code
