/*:
 Time to solve a puzzle! Can you make Dash drive through a maze?
 
 Decide how many moves you need to do just that and then hit Run My Code.
 
 Press the Skoog sides to determine your path, on the last press Dash will start moving!
 
 Don't forget the different colors on Skoog send different commands to Dash:
 
 Red:       Move Forward
 
 Blue:      Turn Left
 
 Yellow:    Move Backward
 
 Green:     Turn Right
 
 Hit Run My Code and give it a go!
 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveForward(), moveBackward(), turnLeft(), turnRight(), waitForObstacleInFront(), waitForObstacleInRear(), waitForButton1Press(), waitForButton2Press(), waitForButton3Press(), waitForClap(), playSound(_:), SoundType, Bragging, HereICome, Interesting, Inputs, Horn, Wha, Awesome, CarEngine, Hi, Fantastic, OhNo, setLight(_:), ColorType, Red, Green, Blue, Yellow, White)
//#-hidden-code
setup()
public class DashSkoogListener: SkoogListener {
    func press(side: Side, strength: Double) {
        switch side.name {
        case .red:
            commandList.append(.moveForwardCommand)
        case .blue:
            commandList.append(.turnLeftCommand)
        case .yellow:
            commandList.append(.moveBackwardCommand)
            break
        case .green:
            commandList.append(.turnRightCommand)
            break
        case .orange:
            break
        default:
            break
        }
        commandCounter += 1
//        updateCountLabel(count: commandCounter)
        if commandCounter == numOfCommands {
            executeCommands()
        }
        
    }
    
    func executeCommands() {
        for i in commandList {
            switch i {
            case .moveForwardCommand:
                moveForward()
            case .turnLeftCommand:
                turnRight()
            case .moveBackwardCommand:
                moveBackward()
            case .turnRightCommand:
                turnRight()
            }
        }
    }
    
    public override func peak(_ side: Side, _ peak: Double) {
        press(side: side, strength: peak)
    }
    
    var commandList : [DashCommands] = []
    var commandCounter : Int = 0
    enum DashCommands {
        case moveForwardCommand
        case turnLeftCommand
        case moveBackwardCommand
        case turnRightCommand
    }
}
//#-end-hidden-code
var numOfCommands = /*#-editable-code number of commands*/5/*#-end-editable-code*/
//#-hidden-code
let dashSkoogListener = DashSkoogListener()
//exitProgram()
//#-end-hidden-code
