public func playSound(_ type:SoundType){
    commandSender.playSound(type)
}

public func connectToRobot(_ name:String){
    commandSender.connectToRobot(name)
}

public func exitProgram(){
    commandSender.exitProgram()
}

public func moveForward(){
    commandSender.moveForward()
}

public func moveBackward(){
    commandSender.moveBackward()
}

public func turnRight(){
    commandSender.turnRight()
}

public func turnLeft(){
    commandSender.turnLeft()
}

public func playSoundCarEngine(){
    commandSender.playSoundCarEngine()
}

public func playSoundHi(){
    commandSender.playSoundHi()
}

public func setLight(_ type:ColorType){
    commandSender.setLight(type)
}

public func isObstacleInFront()->Bool{
    return commandSender.getSensorInFront()
}

public func isObstacleInRear()->Bool{
    return commandSender.getSensorInRear()
}

public func waitForObstacleInFront(){
    commandSender.waitForObstacleInFront()
}

public func waitForObstacleInRear(){
    commandSender.waitForObstacleInRear()
}

public func waitForClap(){
    commandSender.waitForClap()
}

public func waitForButton1Press(){
    commandSender.waitForButton1Press()
}

public func waitForButton2Press(){
    commandSender.waitForButton2Press()
}

public func waitForButton3Press(){
    commandSender.waitForButton3Press()
}
