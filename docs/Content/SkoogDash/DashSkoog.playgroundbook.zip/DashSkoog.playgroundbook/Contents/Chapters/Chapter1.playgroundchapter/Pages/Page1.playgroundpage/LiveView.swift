import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth


let robotViewController:RobotViewController = RobotViewController(1)
PlaygroundPage.current.liveView = robotViewController


extension SkoogListener {
    public var topLevelViewController : RobotViewController {
        return robotViewController
    }
    public func refreshBTUIExtension() {
        refreshBTUI()
        self.topLevelViewController.addChild(bluetoothUI!)
        self.topLevelViewController.view.addSubview((bluetoothUI?.view)!)
        
        NSLayoutConstraint.activate([
            bluetoothUI!.view.trailingAnchor.constraint(equalTo: self.topLevelViewController.view.trailingAnchor, constant: -20),
            bluetoothUI!.view.topAnchor.constraint(equalTo: self.topLevelViewController.view.topAnchor, constant: 20)
            ])
    }
}

extension RobotViewController {
    // failed attempt to change constraints in the LiveView... needed to do it in the source file. Not ideal.
    //    public func moveBTConnector() {
    //        NSLayoutConstraint.activate(
    //            [btView!.topAnchor.constraint(equalTo: liveViewSafeAreaGuide.topAnchor, constant: 20),
    //             btView!.trailingAnchor.constraint(equalTo: liveViewSafeAreaGuide.trailingAnchor, constant: -20)])
    //    }
    
    public var btmvc: BluetoothMIDIViewController {
        return skoogListener.bluetoothUI!
    }
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        btmvc.handleOutsideTouches()
    }
}

let skoogListener = SkoogListener()
skoogListener.refreshBTUIExtension()

