import Foundation
import UIKit
import CoreBluetooth
import PlaygroundSupport

open class SkoogListener : NSObject, SkoogDelegate, bleMessagesDelegate {
    public let skoog    = Skoog.sharedInstance
    public var bluetooth : BLEMessages?
    
    public var calibrationTimer : Timer?
    
    public var firmwareMajorVersion : Int = -1 {
        didSet {
            setFirmwareMajorVersion(firmwareMajorVersion: firmwareMajorVersion)
        }
    }
    public var firmwareMinorVersion : Int = -1 {
        didSet {
            setFirmwareMinorVersion(firmwareMinorVersion: firmwareMinorVersion)
        }
    }
    
    public func setFirmwareMajorVersion(firmwareMajorVersion : Int) {
        if self.skoogConnected {
            self.skoog.firmwareMajorVersion = firmwareMajorVersion
        }
    }
    
    public func setFirmwareMinorVersion(firmwareMinorVersion : Int) {
        if self.skoogConnected {
            self.skoog.firmwareMinorVersion = firmwareMinorVersion
            self.skoog.initialiseSkoog()
        }
    }
    
    public var pressCounterLabel = UILabel(frame: CGRect(x: 0, y: 44, width: 240, height: 256))
    public var skoogConnected : Bool = false
    public var newConnection : Bool = false
    public var connectedSkoog : CBPeripheral? = nil
    public var bluetoothUI : BluetoothMIDIViewController?
    public override init() {
        super.init()
        skoog.delegate = self
        skoog.setPolyMode(active: false)
        bluetooth = BLEMessages()
        bluetooth?.delegate = self
        Timer.scheduledTimer(timeInterval:0.1, target: self, selector: #selector(skoogSearchTask), userInfo: nil, repeats: false)
    }
    
    open func peak(_ side: Side, _ peak: Double) {
        // stub
    }
    
    open func continuous(_ side: Side) {
        // stub
    }
    
    open func release(_ side: Side) {
        // stub
    }
    
   
    
    open func updateProbe(_ packet: [Int]) {
        
    }
    
    open func showMagnetWarning(){
        
    }
    
    @objc public func setReadyToPlay(){
        if skoog.skoogConnected {
            //            self.readyToPlay = true
            skoog.calibrating = false
            //            red.active = true
            //            blue.active = true
            //            yellow.active = true
            //            green.active = true
            //            orange.active = true
        }
    }
    @objc open func skoogSearchTask() {
        skoog.searchForSkoog()
        // if we have a BLE connection to Skoog this will trigger a calibration
        // If not, nothing will happen, it will fail gracefully.
    }
    
    @objc open func calibrateTask() {
        skoog.calibrating = true
        bluetooth?.calibrate()
        
        if self.calibrationTimer != nil {
            if (self.calibrationTimer?.isValid)! {
                self.calibrationTimer?.invalidate()
            }
        }
        
        self.calibrationTimer = Timer.scheduledTimer(timeInterval:1.0, target: self, selector: #selector(setReadyToPlay), userInfo: nil, repeats: false)
    }
    
    open func skoogConnectionStatus(_ connected: Bool) {
        bluetoothUI?.skoogConnectionStatus(connected: connected)
        if connected == true && skoog.skoogConnected == true {
            bluetooth?.findSkoog(shouldConnect: true)
            Timer.scheduledTimer(timeInterval:1.5, target: self, selector: #selector(calibrateTask), userInfo: nil, repeats: false)
        }
    }
    
    public func refreshBTUI() {
        if bluetoothUI != nil {
            bluetoothUI!.view.removeFromSuperview()
            bluetoothUI!.removeFromParent()
            bluetoothUI = nil
        }
        bluetoothUI = BluetoothMIDIViewController()
        bluetoothUI?.view.translatesAutoresizingMaskIntoConstraints = false
        
        Timer.scheduledTimer(timeInterval:0.1, target: self, selector: #selector(skoogSearchTask), userInfo: nil, repeats: false)
    }
}
