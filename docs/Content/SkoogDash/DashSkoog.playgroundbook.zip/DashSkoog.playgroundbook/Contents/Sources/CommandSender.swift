//
//  RobotCommand.swift
//  DashBook
//
//  Created by Wonder Workshop on 3/17/17.
//  Copyright © 2016 Wonder Workshop inc. (https://www.makewonder.com/) All rights reserved.
//

import Foundation
import PlaygroundSupport

public enum CommandType: String{
    case COMMAND_LIGHT_GREEN    = "command_setLight_green"
    case COMMAND_LIGHT_YELLOW   = "command_setLight_yellow"
    case COMMAND_LIGHT_RED      = "command_setLight_red"
    case COMMAND_LIGHT_WHITE    = "command_setLight_white"
    case COMMAND_LIGHT_BLUE     = "command_setLight_blue"
    
    case COMMAND_MOVE_FORWARD   = "command_moveForward"
    case COMMAND_MOVE_BACKWARD  = "command_moveBackward"
    case COMMAND_TURN_RIGHT     = "command_turnRight"
    case COMMAND_TURN_LEFT      = "command_turnLeft"
    
    case COMMAND_SOUND_ENGINE       = "command_playSound_carEngine"
    case COMMAND_SOUND_HI           = "command_playSound_hi"
    case COMMAND_SOUND_AWESOME      = "command_playSound_awesome"
    case COMMAND_SOUND_FANTASTIC    = "command_playSound_fantastic"
    case COMMAND_SOUND_OHNO         = "command_playSound_ohNo"
    case COMMAND_SOUND_WHA          = "command_playSound_wha"
    
    case COMMAND_SOUND_BRAGGING         = "command_playSound_bragging"
    case COMMAND_SOUND_HEREICOME        = "command_playSound_hereICome"
    case COMMAND_SOUND_INTERESTING      = "command_playSound_interesting"
    case COMMAND_SOUND_INPUTSOUTPUTS    = "command_playSound_inputs"
    case COMMAND_SOUND_HORN             = "command_playSound_horn"
    
    case COMMAND_WAITFOR_OBSTACLE_FRONT = "command_waitForObstacleInFront"
    case COMMAND_WAITFOR_OBSTACLE_REAR  = "command_waitForObstacleInRear"
    case COMMAND_WAITFOR_CLAP           = "command_waitForClap"
    case COMMAND_WAITFOR_BUTTON1        = "command_waitForButton1Press"
    case COMMAND_WAITFOR_BUTTON2        = "command_waitForButton2Press"
    case COMMAND_WAITFOR_BUTTON3        = "command_waitForButton3Press"
    
    case COMMAND_CONNECT_ROBOT  = "SetRobotName"
    case COMMAND_EXIT_PROGRAM   = "ExitProgram"
    
    case COMMAND_GET_SENSOR_FRONT = "command_getSensorFront"
    case COMMAND_GET_SENSOR_REAR  = "command_getSensorRear"
    
    case FEEDBACK_WAITFOR_CLAP              = "feedback_waitForClap"
    case FEEDBACK_WAITFOR_OBSTACLE_FRONT    = "feedback_waitForObstacleInFront"
    case FEEDBACK_WAITFOR_OBSTACLE_REAR     = "feedback_waitForObstacleInRear"
    case FEEDBACK_WAITFOR_BUTTON1           = "feedback_waitForButton1Press"
    case FEEDBACK_WAITFOR_BUTTON2           = "feedback_waitForButton2Press"
    case FEEDBACK_WAITFOR_BUTTON3           = "feedback_waitForButton3Press"
    case FEEDBACK_FAIL                      = "feedback_fail"
    case FEEDBACK_SUCCESS                   = "feedback_success"
    
    case COMMAND_IDLE = "command_idle"
    case COMMAND_DISCONNECT = "command_disconnect"
    
}

/*
 CommandType.COMMAND_LIGHT_GREEN
 CommandType.COMMAND_LIGHT_YELLOW
 CommandType.COMMAND_LIGHT_RED
 CommandType.COMMAND_LIGHT_WHITE
 CommandType.COMMAND_LIGHT_BLUE
 
 CommandType.COMMAND_MOVE_FORWARD
 CommandType.COMMAND_MOVE_BACKWARD
 CommandType.COMMAND_TURN_RIGHT
 CommandType.COMMAND_TURN_LEFT
 
 CommandType.COMMAND_SOUND_ENGINE
 CommandType.COMMAND_SOUND_HI
 CommandType.COMMAND_SOUND_AWESOME
 CommandType.COMMAND_SOUND_FANTASTIC
 CommandType.COMMAND_SOUND_OHNO
 CommandType.COMMAND_SOUND_WHA
 
 CommandType.COMMAND_SOUND_BRAGGING
 CommandType.COMMAND_SOUND_HEREICOME
 CommandType.COMMAND_SOUND_INTERESTING
 CommandType.COMMAND_SOUND_INPUTSOUTPUTS
 CommandType.COMMAND_SOUND_HORN
 
 CommandType.COMMAND_WAITFOR_OBSTACLE_FRONT
 CommandType.COMMAND_WAITFOR_OBSTACLE_REAR
 CommandType.COMMAND_WAITFOR_CLAP
 CommandType.COMMAND_WAITFOR_BUTTON1
 CommandType.COMMAND_WAITFOR_BUTTON2
 CommandType.COMMAND_WAITFOR_BUTTON3
 */

public enum ColorType{
    case Green
    case Yellow
    case Red
    case White
    case Blue
}

public enum SoundType{
    case CarEngine
    case Hi
    case Awesome
    case Fantastic
    case OhNo
    case Wha
    
    case Bragging
    case HereICome
    case Interesting
    case Inputs
    case Horn
}

public protocol CommandPauseDelegate {
    var isReadyForMoreCommands: Bool { get set }
    var returnValue: Bool { get set }
}

extension CommandPauseDelegate {
    /// Waits until `isReadyForMoreCommands` is set to true.
    func wait() {
        repeat {
            RunLoop.main.run(mode: RunLoop.Mode.default,
                             before: Date(timeIntervalSinceNow: 0.1))
        } while !isReadyForMoreCommands
    }
}

public class CommandSender: CommandPauseDelegate {
    
    public var isReadyForMoreCommands = true
    public var returnValue = false
    
    var command: PlaygroundValue = .string("")
    //var commands:[PlaygroundValue] = [PlaygroundValue]() // PlaygroundValue could be .string(String) .dictionary([String:PlaygroundValue])
    
    public init(){
    }
    
    public func sendCommand(_ commandData:PlaygroundValue) {
        let page = PlaygroundPage.current
        if let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy {
            proxy.send(commandData)
        }
        // Spin the runloop until the LiveView process has completed the current command.
        isReadyForMoreCommands = false
        wait()
    }
    
    public func connectToRobot(_ name:String){
        command = .dictionary([CommandType.COMMAND_CONNECT_ROBOT.rawValue:.string(name)])
        sendCommand(command)
    }
    
    public func exitProgram()
    {
        command = .string(CommandType.COMMAND_EXIT_PROGRAM.rawValue)
        sendCommand(command)
    }
    
    public func moveForward(){
        command = .string(CommandType.COMMAND_MOVE_FORWARD.rawValue)
        sendCommand(command)
    }
    
    public func moveBackward(){
        command = .string(CommandType.COMMAND_MOVE_BACKWARD.rawValue)
        sendCommand(command)
    }
    
    public func turnRight(){
        command = .string(CommandType.COMMAND_TURN_RIGHT.rawValue)
        sendCommand(command)
    }
    
    public func turnLeft(){
        command = .string(CommandType.COMMAND_TURN_LEFT.rawValue)
        sendCommand(command)
    }
    
    public func playSoundCarEngine(){
        playSound(SoundType.CarEngine)
    }
    
    public func playSoundHi(){
        playSound(SoundType.Hi)
    }
    
    public func playSound(_ type:SoundType){
        switch type {
        case SoundType.CarEngine:
            command = .string(CommandType.COMMAND_SOUND_ENGINE.rawValue)
        case SoundType.Hi:
            command = .string(CommandType.COMMAND_SOUND_HI.rawValue)
        case SoundType.Awesome:
            command = .string(CommandType.COMMAND_SOUND_AWESOME.rawValue)
        case SoundType.Fantastic:
            command = .string(CommandType.COMMAND_SOUND_FANTASTIC.rawValue)
        case SoundType.OhNo:
            command = .string(CommandType.COMMAND_SOUND_OHNO.rawValue)
        case SoundType.Wha:
            command = .string(CommandType.COMMAND_SOUND_WHA.rawValue)
        case SoundType.Bragging:
            command = .string(CommandType.COMMAND_SOUND_BRAGGING.rawValue)
        case SoundType.HereICome:
            command = .string(CommandType.COMMAND_SOUND_HEREICOME.rawValue)
        case SoundType.Interesting:
            command = .string(CommandType.COMMAND_SOUND_INTERESTING.rawValue)
        case SoundType.Inputs:
            command = .string(CommandType.COMMAND_SOUND_INPUTSOUTPUTS.rawValue)
        case SoundType.Horn:
            command = .string(CommandType.COMMAND_SOUND_HORN.rawValue)
        }
        sendCommand(command)
    }
    
    public func setLight(_ type:ColorType){
        switch type {
        case ColorType.Green:
            command = .string(CommandType.COMMAND_LIGHT_GREEN.rawValue)
        case ColorType.Yellow:
            command = .string(CommandType.COMMAND_LIGHT_YELLOW.rawValue)
        case ColorType.Red:
            command = .string(CommandType.COMMAND_LIGHT_RED.rawValue)
        case ColorType.White:
            command = .string(CommandType.COMMAND_LIGHT_WHITE.rawValue)
        case ColorType.Blue:
            command = .string(CommandType.COMMAND_LIGHT_BLUE.rawValue)
        }
        sendCommand(command)
    }
    
    public func getSensorInFront()->Bool{
        command = .string(CommandType.COMMAND_GET_SENSOR_FRONT.rawValue)
        sendCommand(command)
        return returnValue
    }
    
    public func getSensorInRear()->Bool{
        command = .string(CommandType.COMMAND_GET_SENSOR_REAR.rawValue)
        sendCommand(command)
        return returnValue
    }
    
    public func waitForObstacleInFront(){
        command = .string(CommandType.COMMAND_WAITFOR_OBSTACLE_FRONT.rawValue)
        sendCommand(command)
    }
    
    public func waitForObstacleInRear(){
        command = .string(CommandType.COMMAND_WAITFOR_OBSTACLE_REAR.rawValue)
        sendCommand(command)
    }
    
    public func waitForClap(){
        command = .string(CommandType.COMMAND_WAITFOR_CLAP.rawValue)
        sendCommand(command)
    }
    
    public func waitForButton1Press(){
        command = .string(CommandType.COMMAND_WAITFOR_BUTTON1.rawValue)
        sendCommand(command)
    }
    
    public func waitForButton2Press(){
        command = .string(CommandType.COMMAND_WAITFOR_BUTTON2.rawValue)
        sendCommand(command)
    }
    
    public func waitForButton3Press(){
        command = .string(CommandType.COMMAND_WAITFOR_BUTTON3.rawValue)
        sendCommand(command)
    }
    
}
