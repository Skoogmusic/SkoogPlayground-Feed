//#-hidden-code
//
//  Contents.swift
//  spheroArcade
//
//  Created by Jordan Hesse on 2017-04-26.
//  Copyright © 2017 Sphero Inc. All rights reserved.
//
//#-end-hidden-code
/*:#localized(key: "")
 Here you can aim and drive your robot using a joystick or Skoog. Make sure you connect your robot, then tap "Run My Code" to start driving.
 
 The aim wheel changes the orientation of the robot. Spin the aim wheel around until the tail light is facing you.
 
 The joystick directly controls the robot. The farther you pull the joystick from the center, the faster the robot will roll.
 
 If Skoog is connected it will control the robot and the joystick will be deactivated. Use the sides of Skoog to control the robot direction. The harder you squeeze Skoog the faster it goes.
 */
//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, onReady(), self, connectedAction(), continous(side: Side), didValueChange(currentValue: , lastValue), disconnectedAction(), messageFilterRate, orangeAction(), redCounter)
//#-code-completion(identifier, show, ., roll(heading:speed:), stopRoll(), wait(for:), setMainLed(color:), setBackLed(brightness:), setStabilization(state:), setCollisionDetection(configuration:), startAiming(), stopAiming(), enableSensors(sensorMask:), disableSensors(), configureLocator(newX:newY:newYaw:), addSensorListener(_:), addCollisionListener(_:), setRawMotor(leftMotorPower:leftMotorMode:rightMotorPower:rightMotorMode:), addFreefallListener(_:), RawMotor, RawMotorMode, forward, reverse, off, brake, ignore, addLandListener(_:), Sound, play(), applause, ding, dizzy, no, sad, complete, success, shake, spin, tap, jump, slowDown, fall, hit, speedUp, powerDown, pop, bounce, plummet, evilLaugh, powerUp, bell, buttonPulse, celebrate, cheering, tick, lightning, bleep, sparkle, bloop, grow, allSounds, setFrontPSILed(color:), setBackPSILed(color:), setHoloProjectorLed(brightness:), setLogicDisplaysLed(brightness:), setDomePosition(angle:), setStance(_:), play(sound:playbackMode:), play(sound:), setHeadLed(brightness:), R2D2Sound, happy, cheerful, joyful, hello, excited, sad, scared, cautious, scan, talking, immediately, playOnlyIfNotPlaying, afterCurrent, R2D2Stance, bipod, tripod, waddle, CollisionData, attitude, locator, accelerometer, gyro, orientation, on, playAnimation(_:), R2D2Animations, alarmed, angry, annoyed, chatty, drive, excited, happy, ionBlast, laugh, sassy, scared, yes, sleep, surprised)



public class SpheroSkoogListener: SkoogListener {
    public var lastRedValue = 0.0
    public var redCounter = 0
    public var lastBlueValue = 0.0
    public var blueCounter = 0
    public var lastYellowValue = 0.0
    public var yellowCounter = 0
    public var lastGreenValue = 0.0
    public var greenCounter = 0
    public var messageFilterRate = 11
    
    public var rotationTimer : Timer?
    
    public var spheroHeading = 0
    public var toggle = true
//#-end-hidden-code

// Press Skoog to change color and direction
func press(side: Side, strength: Double) {
    var color : UIColor = .white
    var heading = 0
    switch side.name {
    case .red:
        //#-editable-code
        heading = 0
        color = .red
        //#-end-editable-code
    case .blue:
        //#-editable-code
        heading = 90
        color = .blue
        //#-end-editable-code
    case .yellow:
        //#-editable-code
        heading = 180
        color = .yellow
        //#-end-editable-code
    case .green:
        //#-editable-code
        heading = 270
        color = .green
        //#-end-editable-code
    case .orange:
        //#-editable-code
        color = .orange
        //#-end-editable-code
        break
    default:
        break
    }
    setMainLed(color: color)
    let speed = Int(side.value * 255.0)
    roll(heading: heading, speed: speed)
}
// Squeeze Skoog to change speed
func squeeze(side: Side) {
    var heading = 0
    switch side.name {
    case .red:
        //#-editable-code
        heading = 0
        //#-end-editable-code
    case .blue:
        //#-editable-code
        heading = 90
        //#-end-editable-code
    case .yellow:
        //#-editable-code
        heading = 180
        //#-end-editable-code
    case .green:
        //#-editable-code
        heading = 270
        //#-end-editable-code
    case .orange:
        break
    default:
        break
    }
    let speed = Int(side.rawValue * 255.0)
    roll(heading: heading, speed: speed)
}
// let go of Skoog to stop moving
func lift() {
    setMainLed(color: .white)
    stopRoll()
}

//#-hidden-code
    public override func skoogConnectionStatus(connected: Bool) {
        super.skoogConnectionStatus(connected: connected)
        if connected == true && skoog.skoogConnected == true {
            setMainLed(color: .green)
            Timer.scheduledTimer(timeInterval:0.33, target: self, selector: #selector(connectedAction), userInfo: nil, repeats: false)
        }
        else {
            setMainLed(color: .red)
            Timer.scheduledTimer(timeInterval:0.33, target: self, selector: #selector(disconnectedAction), userInfo: nil, repeats: false)
        }
    }
    
    @objc func connectedAction() {
        setMainLed(color: .white)
        Timer.scheduledTimer(timeInterval:0.33, target: self, selector: #selector(greenFlash), userInfo: nil, repeats: false)
    }
    
    @objc func disconnectedAction() {
        setMainLed(color: .white)
        Timer.scheduledTimer(timeInterval:0.33, target: self, selector: #selector(redFlash), userInfo: nil, repeats: false)
    }
    
    @objc func greenFlash() {
        setMainLed(color: .green)
        Timer.scheduledTimer(timeInterval:0.33, target: self, selector: #selector(white), userInfo: nil, repeats: false)
    }
    
    @objc func redFlash() {
        setMainLed(color: .red)
        Timer.scheduledTimer(timeInterval:0.33, target: self, selector: #selector(white), userInfo: nil, repeats: false)
    }
    
    @objc func white() {
        setMainLed(color: .white)
    }
    
    public override func peak(side: Side, peak: Double) {
        press(side: side, strength: peak)
    }
    
    @objc func orangeAction() {
        rotateAim(heading: spheroHeading)
        spheroHeading += 5
        if spheroHeading > 360 {
            spheroHeading = 0
        }
    }
    
    public override func continuous(side: Side) {
        if side.name == .red {
            if didValueChange(side.value, lastRedValue) && redCounter % messageFilterRate == 0 {
                squeeze(side: side)
                //                roll(heading: 0, speed: Int(side.rawValue * 255.0))
                redCounter = 0
            }
            lastRedValue = side.value
            redCounter += 1
        }
        else if side.name == .blue {
            if didValueChange(side.value, lastBlueValue) && blueCounter % messageFilterRate == 0 {
                squeeze(side: side)
                //                roll(heading: 90, speed: Int(side.rawValue * 255.0))
                blueCounter = 0
            }
            lastBlueValue = side.value
            blueCounter += 1
        }
        else if side.name == .yellow {
            if didValueChange(side.value, lastYellowValue) && yellowCounter % messageFilterRate == 0 {
                squeeze(side: side)
                //                roll(heading: 180, speed: Int(side.rawValue * 255.0))
                yellowCounter = 0
            }
            lastYellowValue = side.value
            yellowCounter += 1
        }
        else if side.name == .green {
            if didValueChange(side.value, lastGreenValue) && greenCounter % messageFilterRate == 0 {
                squeeze(side: side)
                //                roll(heading: 270, speed: Int(side.rawValue * 255.0))
                greenCounter = 0
            }
            lastGreenValue = side.value
            greenCounter += 1
        }
    }
    
    func didValueChange(_ currentValue: Double,_ lastValue: Double)->Bool {
        if currentValue != lastValue {
            return true
        }
        return false
    }
    
    public override func release(side: Side) {
        lift()
        lastRedValue = 0.0
        lastBlueValue = 0.0
        lastYellowValue = 0.0
        lastGreenValue = 0.0
    }
}

let spheroSkoogListener = SpheroSkoogListener()

func onReady() {
    addJoystickListener { (x, y) in
        if !spheroSkoogListener.skoogConnected {
            if x == 0 && y == 0 {
                stopRoll()
            } else {
                let heading = atan2(x, y) * 180.0 / Double.pi
                
                let speed = (x*x + y*y) * 255.0
                
                roll(heading: Int(heading), speed: Int(speed))
            }
        }
    }
    
    addAimHeadingListener { (heading: Int) in
        rotateAim(heading: heading)
    }
    
    addAimStartListener {
        startAiming()
    }
    
    addAimStopListener {
        stopAiming()
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true
setupContent(assessment: TemplateAssessmentController(), userCode: onReady)
//#-end-hidden-code

