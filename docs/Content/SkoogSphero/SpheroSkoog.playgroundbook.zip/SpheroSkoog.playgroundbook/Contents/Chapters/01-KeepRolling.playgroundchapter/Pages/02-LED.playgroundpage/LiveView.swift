//
//  LiveView.swift
//  spheroArcade
//
//  Created by Jordan Hesse on 2017-04-26.
//  Copyright © 2017 Sphero Inc. All rights reserved.
//

import UIKit

import PlaygroundSupport

let templateLiveViewController: TemplateDrivingLiveViewController = TemplateDrivingLiveViewController.instantiateFromStoryboard()

extension SkoogListener {
    public var topLevelViewController : TemplateDrivingLiveViewController {
        return templateLiveViewController
    }
    public func refreshBTUIExtension() {
        refreshBTUI()
        self.topLevelViewController.addChildViewController(bluetoothUI!)
        self.topLevelViewController.view.addSubview((bluetoothUI?.view)!)
        
        NSLayoutConstraint.activate([
            bluetoothUI!.view.leadingAnchor.constraint(equalTo: self.topLevelViewController.liveViewSafeAreaGuide.leadingAnchor, constant: 22),
            bluetoothUI!.view.topAnchor.constraint(equalTo: self.topLevelViewController.liveViewSafeAreaGuide.topAnchor, constant: 22)
            ])
    }
}

extension TemplateDrivingLiveViewController {
    public var btmvc: BluetoothMIDIViewController {
        return skoogListener.bluetoothUI!
    }
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        btmvc.handleOutsideTouches()
    }
}

let skoogListener = SkoogListener()
skoogListener.refreshBTUIExtension()

PlaygroundPage.current.liveView = templateLiveViewController
PlaygroundPage.current.needsIndefiniteExecution = true
