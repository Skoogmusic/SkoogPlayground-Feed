//
//  Skoog.swift
//  Skoog
//
//  Created by Keith Nagle on 10/06/2016.
//  Copyright © 2016 Skoogmusic Ltd. All rights reserved.
//
//import Foundation
//import Darwin
import CoreMIDI
import UIKit
import QuartzCore

public protocol SkoogDelegate: class {
    func peak(side: Side, peak: Double)
    func continuous(side: Side)
    func release(side: Side)
    func skoogConnectionStatus(connected: Bool)
}

public enum ColorString: String {
	case red
	case blue
	case yellow
	case green
	case orange
	case white
	var string: String {
		switch self {
		case .red:
			return "red"
		case .blue:
			return "blue"
		case .yellow:
			return "yellow"
		case .green:
			return "green"
		case .orange:
			return "orange"
		case .white:
			return "white"
		}
	}
}




/**
	Side Class - used to store info about the playing state of each side of the Skoog

 - active:  Indicates if the side is turned on or off.
 - isPlaying:  Used to monitor the current playing state of the side.
 - color: UIColor value of the side.
 - rawValue: The raw squeeze data.
 - response: Sets the response adjustment level (0 - 12).
 - value: The response curve adjusted squeeze value.
 - peak: Reports the strength of peaks detected in the squeeze data.
 - angle: Reports the 0-359 degree angle (where yellow is 0 or 360 degrees) for the current press.
 - name: String name of the current side.
 - blend_in_xy:  
 - blend_out_xy:
 - play(): Function to set the active state of the side to true (turn on).
 - stop(): Function to set the active state of the side to false (turn off).
 */

public class Side: NSObject {
    public var active : Bool = true
    public var isPlaying : Bool = false
    public var color : UIColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
    public var rawValue : Double = 0
    public var value : Double = 0
    public var peak : Peak? = Peak.init()
    public var peakValue : Double? = 0
    public var deltaT : Double? = 0
    public var index : Int = 0 // perhaps not needed but useful for identifying by index for now
    public var response : Double = 0.0
    public var angle : Double = 0.0
    public var name : ColorString = .white
    public var blend_in_xy : Double = 0.0
    public var blend_out_xy : Double = 0.0
    public var threshold : Double = 0.0
    public func play() {
        self.active = true
    }
    public func stop() {
        self.active = false
    }
    public override init() {
        super.init()
    }
}

// The "singleton" instance
public let SkoogInstance = Skoog()

let skoogNotificationKey = "com.skoogmusic.skoogNotificationKey"


public class Skoog: NSObject {
    
    public weak var delegate:SkoogDelegate?
    
    enum Zone: Int {
        case red_side = 0,      // 1
        blue_side,              // 2
        yellow_side,            // 3
        green_side,             // 4
        orange_side,            // 5
        red_blue,               // 6
        blue_yellow,            // 7
        yellow_green,           // 8
        red_green,              // 9
        orange_red,             // 10
        orange_red_blue,        // 11
        orange_blue,            // 12
        orange_blue_yellow,     // 13
        orange_yellow,          // 14
        orange_yellow_green,    // 15
        orange_green,           // 16
        orange_red_green,       // 17
        none
    }
    var themidipacket : [Int] = [0, 0, 0, 0, 0, 0, 0]
    
    let bufferSize = 5
    
    //    var z1Buffer = Array(repeating: 0, count: 2)
    //    var z2Buffer = Array(repeating: 0, count: 2)
    var r1Buffer = Array(repeating: 0, count: 5)
    var r2Buffer = Array(repeating: 0, count: 5)
    
    var x1Buffer = Array(repeating: 0, count: 5)
    var y1Buffer = Array(repeating: 0, count: 5)
    var z1Buffer = Array(repeating: 0, count: 5)
    
    var x2Buffer = Array(repeating: 0, count: 5)
    var y2Buffer = Array(repeating: 0, count: 5)
    var z2Buffer = Array(repeating: 0, count: 5)
    
    
    var activeZones : [[Zone]] = [[.red_side, .none, .none],
                                  [.blue_side, .none, .none],
                                  [.yellow_side, .none, .none],
                                  [.green_side, .none, .none],
                                  [.orange_side, .none, .none],
                                  [.red_side, .blue_side, .none],
                                  [.blue_side, .yellow_side, .none],
                                  [.yellow_side, .green_side, .none],
                                  [.red_side, .green_side, .none],
                                  [.orange_side, .red_side, .none],
                                  [.orange_side, .red_side, .blue_side],
                                  [.orange_side, .blue_side, .none],
                                  [.orange_side, .blue_side, .yellow_side],
                                  [.orange_side, .yellow_side, .none],
                                  [.orange_side, .yellow_side, .green_side],
                                  [.orange_side, .green_side, .none],
                                  [.orange_side, .red_side, .green_side],
                                  [.none, .none, .none]];
    
    public class var sharedInstance:Skoog {
        return SkoogInstance
    }
    
    var status = OSStatus(noErr)
    var midiClient = MIDIClientRef()
    var outputPort = MIDIPortRef()
    var inputPort = MIDIPortRef()
    var virtualSourceEndpointRef = MIDIEndpointRef()
    var virtualDestinationEndpointRef = MIDIEndpointRef()
    var midiInputPortref = MIDIPortRef()
    
    public var red : Side
    public var blue : Side
    public var yellow : Side
    public var green : Side
    public var orange : Side
    public var sides : [Side]
    
    public var polyMode = true
    public var sendVirtualMIDI = false
    public var sendNetworkMIDI = false
    public var threshRelease : Bool = true
    
    var R1 : Double = 0.0
    var R2 : Double = 0.0
    var T1 : Double = 0.0
    var T2 : Double = 0.0
    var Z3 : Double = 0.0
    var ZC : Double = 0.0
    var DX : Double = 0.0
    var DY : Double = 0.0
    var Rxy : Double = 0.0
    var Rxyz : Double = 0.0
    public var Txy : Double = 0.0
    var dT : Double = 0.0
    var Tz : Double = 0.0
    public var R_zoom : Double = 0.0
    public var Z_zoom : Double = 0.0
    
    var Rxyz_old : Double = 0.0;
    var Rxy_old : Double = 0.0;
    var R1_old : Double = 0.0;
    var R2_old : Double = 0.0;
    var T1_old : Double = 0.0;
    var T2_old : Double = 0.0;
    var Tz_old : Double = 0.0;
    var Z3_old : Double = 0.0;
    
    var lastZone : Zone = .none
    var zone : Zone = .none
    var param2 : Double = 0
    var param3 : Double = 0
    var param4 : Double = 0
    
    public var threshold : Double = 0
    public var z_threshold : Double = 0
    public var thresholdZoom : Double = 0
    public var z_thresholdZoom : Double = 0
    var XYcone : Double = 15.0
    var ZconeZ : Double = 11.5
    var ZconeXY : Double = 22.5
    var coneAngle : Double = 0
    var redBlueAngle : Double = 0
    var blueYellowAngle : Double = 0
    var yellowGreenAngle : Double = 0
    var redGreenAngle : Double = 0
    var bend_note : Double = 0
    var bend_out : Double = 0
    var bend_in : Double = 0
    var blend_out_xy : Double = 0
    var blend_in_xy : Double = 0
    var blend_out_z : Double = 0
    var blend_in_z : Double = 0
    
    var Tz_corrected : Double = 0
    var Z3_corrected : Double = 0
    var blocking = false
    public var calibrating = false
    public var skoogConnected = false
    public var midiInputPortConnectionMade = false
    var currenttime = NSDate()
    var lasttime = NSDate()
    
    var firmwareMajorVersion : Int = -1
    var firmwareMinorVersion : Int = -1
    
    var lastPacket : Double = 0.0
    var currentPacket : Double = 0.0
    var lastTime : Double = 0.0
    var currentTime : Double = 0.0
    var packetCount : Int = 0

    
    override init() {
        self.red = Side()
        self.blue = Side()
        self.yellow = Side()
        self.green = Side()
        self.orange = Side()
        
        self.red.index = 0
        self.blue.index = 1
        self.yellow.index = 2
        self.green.index = 3
        self.orange.index = 4
        
        self.red.name = .red //"red"
        self.blue.name =  .blue //"blue"
        self.yellow.name = .yellow //"yellow"
        self.green.name = .green //"green"
        self.orange.name = .orange //"orange"
        
        self.sides = [red, blue, yellow, green, orange]
        
        self.red.color      =   UIColor(colorLiteralRed: 218.0/255.0, green: 60.0/255.0, blue: 0.0, alpha: 1.0)
        self.blue.color     =   UIColor(colorLiteralRed: 55.0/255.0, green: 127.0/255.0, blue: 178.0/255.0, alpha: 1.0)
        self.yellow.color   =   UIColor(colorLiteralRed: 254.0/255.0, green: 224.0/255.0, blue: 0.0, alpha: 1.0)
        self.green.color    =   UIColor(colorLiteralRed: 61.0/255.0,  green: 155.0/255.0, blue: 53.0/255.0, alpha: 1.0)
        self.orange.color   =   UIColor(colorLiteralRed: 249.0/255.0, green: 154.0/255.0, blue: 0.0, alpha: 1.0)
        
        
        
        super.init()
        
        self.R1 = 0
        self.T1 = 180
        self.R2 = 0
        self.T2 = 180
        self.Z3 = 0
        self.DX = 64
        self.DY = 64
        self.Rxy = 0
        self.Rxyz = 0
        self.Txy = 180
        self.dT = 0
        self.Tz = 90
        self.threshold = 0.0014 // was 0.02
        self.z_threshold = 0.0014
        self.thresholdZoom = 0.0014
        self.z_thresholdZoom = 0.0014 // 0.018
        self.R_zoom = 1.0
        self.Z_zoom = 1.0
        
        self.XYcone = 16 //these values "fill" the space - temporary until cone of shame implememted
        self.ZconeZ = 16.5
        self.ZconeXY = 10.0
        self.zone = .none
        self.lastZone = .none
        self.param3 = 0.0
        self.param4 = 0.0
        
        setPolyMode(active:self.polyMode)
        //        changeXYcone(XYcone)
//        searchForSkoog()
        
        status = MIDIClientCreateWithBlock("com.skoogmusic.myMIDIClient" as CFString, &midiClient, MyMIDINotifyBlock)
        if status != noErr {
            print("Error creating midi client : \(status)")
        }
        else{
            print("Created midi client : \(status)")
        }
        
        status = MIDISourceCreate(midiClient,
                                  "Skoog" as CFString,
                                  &virtualSourceEndpointRef)
        if status == noErr {
            print("created virtual destination")
        } else {
            print("error creating virtual destination: \(status)")
        }
        
    }
    // MARK: MIDI methods
    func MyMIDINotifyBlock(midiNotification: UnsafePointer<MIDINotification>) {
        let notification = midiNotification.pointee
        switch (notification.messageID) {
        case .msgSetupChanged:
            print("Setup changed!")
        //            searchForSkoog()
        case .msgObjectAdded:
            print("Object added!")
            if !skoogConnected {
                print("Searching for skoog")
                searchForSkoog()
            }
        case .msgObjectRemoved:
            print("Object removed!")
            
            if skoogConnected {
                searchForSkoog()
            }
        case .msgPropertyChanged:
            //            print("Property changed!")
            print("")
        case .msgThruConnectionsChanged:
            print("Thru connections changed!")
        case .msgSerialPortOwnerChanged:
            print("Serial port owner changed!")
        case .msgIOError:
            print("IO Error!")
        }
    }
    
    //The system assigns unique IDs to all objects
    func getUniqueID(_ endpoint:MIDIEndpointRef) -> (OSStatus, MIDIUniqueID) {
        var id = MIDIUniqueID(0)
        let status = MIDIObjectGetIntegerProperty(endpoint, kMIDIPropertyUniqueID, &id)
        if status != noErr {
            print("error getting unique id \(status)")
            //checkError(status)
        }
        return (status,id)
    }
    
    public func notify(notification:Notification) -> Void {
//        //respond to status update notifications
//        print("Catch notification")
//        
//        guard let userInfo = notification.userInfo,
//            let connectionStatus  = userInfo["connectionStatus"] as? Bool else {
//                print("No userInfo found in notification")
//                return
//        }
//        let alert = UIAlertController(title: "Notification!",
//                                      connectionStatus:"\(connectionStatus) received",
//            preferredStyle: UIAlertControllerStyle.alert)
//        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
//        self.present(alert, animated: true, completion: nil)
    }
    
    
    public func searchForSkoog(){
        print("SEARCH FOR SKOOG CALLED")
        let numberOfDevices = MIDIGetNumberOfDevices()
        
        for count:Int in 0 ..< numberOfDevices {
            let midiDevice = MIDIGetDevice(count)
            var unmanagedProperties: Unmanaged<CFPropertyList>?
            
            MIDIObjectGetProperties(midiDevice, &unmanagedProperties, false)
            if let midiProperties: CFPropertyList = unmanagedProperties?.takeUnretainedValue() {
                let midiDictionary = midiProperties as! NSDictionary
                if (midiDictionary.object(forKey: "name") as! String == "Skoog" && midiDictionary.object(forKey: "offline") as! Int == 0) {
                    //print("Found a connected Skoog! \(midiDictionary.object(forKey: "uniqueID"))")
                    skoogConnected = true
                    if skoogConnected == true {
                        delegate?.skoogConnectionStatus(connected: true)
                        NotificationCenter.default.post(name: Notification.Name(rawValue: skoogNotificationKey), object: nil, userInfo: ["connectionStatus": self.skoogConnected])                    }
                    // reset firmware version. Will start accepting signals once we discover the real firmware version
                    firmwareMajorVersion = -1
                    firmwareMinorVersion = -1
                    // start accepting MIDI packets from Skoog
                    if !midiInputPortConnectionMade {
                        start()
                    }
                    break
                }
                else if (midiDictionary.object(forKey: "name") as! String == "Skoog" && midiDictionary.object(forKey: "offline") as! Int == 1){
                    //print("Found an offline Skoog!")
                    skoogConnected = false
                    //                    print("set skoogConnected = false 4")
                }
                
            }
            else {
                print("Unable to load properties for \(count)")
            }
        }
        // if we get this far, there are no connected skoogs
        if skoogConnected == false {
            delegate?.skoogConnectionStatus(connected: false)
            NotificationCenter.default.post(name: Notification.Name(rawValue: skoogNotificationKey), object: nil, userInfo: ["connectionStatus": self.skoogConnected])
            midiInputPortConnectionMade = false
        }
    }
    
    func connectSourcesToInputPort() {
        var status = OSStatus(noErr)
        let sourceCount = MIDIGetNumberOfSources()
        print("source count \(sourceCount)")
        
        for srcIndex in 0 ..< sourceCount {
            let midiEndPoint = MIDIGetSource(srcIndex)
            status = MIDIPortConnectSource(inputPort,
                                           midiEndPoint,
                                           nil)
            if status == OSStatus(noErr) {
                print("yay connected endpoint to inputPort!")
                midiInputPortConnectionMade = true
            } else {
                print("Oh, no!")
            }
            status = MIDIPortConnectSource(inputPort, MIDINetworkSession.default().sourceEndpoint(), nil)
        }
    }
    
    public func sendMidiNoteOn(note: Int, velocity: Int, channel: Int) {
        
        var packet:MIDIPacket = MIDIPacket();
        packet.timeStamp = 0;
        packet.length = 3;
        packet.data.0 = 0x90 + UInt8(channel); // Note On event channel 1
        packet.data.1 = UInt8(note) //0x3C; // Note C3
        packet.data.2 = UInt8(velocity); // Velocity
        var packetList:MIDIPacketList = MIDIPacketList(numPackets: 1, packet: packet);
        
        if sendNetworkMIDI {
            // Get the first destination
            let dest:MIDIEndpointRef = MIDIGetDestination(0);
            MIDISend(outputPort, dest, &packetList);
        }
        
        if sendVirtualMIDI {
            MIDIReceived(virtualSourceEndpointRef, &packetList)
        }
    }
    public func sendMidiNoteOff(note: Int, velocity: Int, channel: Int) {
        var packet:MIDIPacket = MIDIPacket();
        packet.timeStamp = 0;
        packet.length = 3;
        packet.data.0 = 0x80 + UInt8(channel); // Note Off event channel 1
        packet.data.1 = UInt8(note) //0x3C; // Note C3
        packet.data.2 = UInt8(velocity); // Velocity
        var packetList = MIDIPacketList(numPackets: 1, packet: packet);
        
        if sendNetworkMIDI {
            // Get the first destination
            let dest:MIDIEndpointRef = MIDIGetDestination(0);
            MIDISend(outputPort, dest, &packetList);
        }
        if sendVirtualMIDI {
            MIDIReceived(virtualSourceEndpointRef, &packetList)
        }
    }
    public func sendMidiContinuous(note: Int, velocity: Int, channel: Int) {
        var packet:MIDIPacket = MIDIPacket();
        packet.timeStamp = 0;
        packet.length = 3;
        packet.data.0 = 0xA0 + UInt8(channel); // Note Off event channel 1
        packet.data.1 = UInt8(note) //0x3C; // Note C3
        packet.data.2 = UInt8(velocity); // Velocity
        var packetList = MIDIPacketList(numPackets: 1, packet: packet);
        
        if sendNetworkMIDI {
            // Get the first destination
            let dest:MIDIEndpointRef = MIDIGetDestination(0);
            MIDISend(outputPort, dest, &packetList);
        }
        if sendVirtualMIDI {
            MIDIReceived(virtualSourceEndpointRef, &packetList)
        }
    }
    
    public func start(){
        var readBlock: MIDIReadBlock
        readBlock = MyMIDIReadBlock
        
        var status = OSStatus(noErr)
        
        if status == OSStatus(noErr) {
            status = MIDIPortDispose(inputPort)
            if status == OSStatus(noErr) {
                print("disposed of input port")
            } else {
                print("error disposing of input port : \(status)")
            }
            status = MIDIPortDispose(outputPort)
            if status == OSStatus(noErr) {
                print("disposed of output port")
            } else {
                print("error disposing of output port : \(status)")
            }
        }
        
        status = OSStatus(noErr)
        
        if status == OSStatus(noErr) {
            status = MIDIInputPortCreateWithBlock(midiClient, "com.skoogmusic.MIDIInputPort" as CFString, &inputPort, readBlock)
            if status == OSStatus(noErr) {
                print("created input port")
            } else {
                print("error creating input port : \(status)")
            }
        }
        status = MIDIOutputPortCreate(midiClient,
                                      "com.skoogmusic.OutputPort" as CFString,
                                      &outputPort)
        
        if status == noErr {
            print("created output port")
        } else {
            print("error creating output port : \(status)")
        }
        
        //        status = MIDIDestinationCreateWithBlock(midiClient,
        //                                                "com.skoogmusic.VirtualDest" as CFString,
        //                                                &virtualDestinationEndpointRef,
        //                                                MIDIPassThru)
        enableNetwork()
        connectSourcesToInputPort()
        
    }
    
    ///  Take the packets emitted frome the MusicSequence and forward them to the virtual source.
    ///
    ///  - parameter packetList:    packets from the MusicSequence
    ///  - parameter srcConnRefCon: not used
    func MIDIPassThru(packetList: UnsafePointer<MIDIPacketList>, srcConnRefCon: UnsafeMutableRawPointer?) -> Swift.Void {
        print("sending packets to source \(packetList)")
        MIDIReceived(virtualSourceEndpointRef, packetList)
        
        //        dumpPacketList(packetList.memory)
    }
    func enableNetwork() {
        MIDINetworkSession.default().isEnabled = true
        MIDINetworkSession.default().connectionPolicy = .anyone
        print("net session enabled \(MIDINetworkSession.default().isEnabled)")
        print("net session networkPort \(MIDINetworkSession.default().networkPort)")
        print("net session networkName \(MIDINetworkSession.default().networkName)")
        print("net session localName \(MIDINetworkSession.default().localName)")
        
    }
    
    func MyMIDIReadBlock(packetList: UnsafePointer<MIDIPacketList>, srcConnRefCon: UnsafeMutableRawPointer?) -> Swift.Void {
        let packets = packetList.pointee
        let packet:MIDIPacket = packets.packet
        var ap = UnsafeMutablePointer<MIDIPacket>.allocate(capacity: 1)
        ap.initialize(to:packet)
        
        for _ in 0 ..< packets.numPackets {
            let p = ap.pointee
            handle(p)
            ap = MIDIPacketNext(ap)
        }
    }
    func medianFilter(array: [Int]) ->[Int] {
        var output : [Int] = array
        for i in 0...3 {
            if i == 0 {
                let replacementArray = [array[0], array[0], array[1]]
                output[i] = replacementArray.sorted()[1]
            }
            else if i == 3 {
                let replacementArray = [y1Buffer[2], y1Buffer[3], y1Buffer[4]]
                output[i] = replacementArray.sorted()[1]
            }
            else {
                let replacementArray = [array[i-1], array[i], array[i+1]]
                output[i] = replacementArray.sorted()[1]
            }
        }
        return output
    }
    
    func print(_ object: Any) {
        Swift.print(object)
    }
    
    //TODO: set up decodeangle and routing for new firmware version
    func preprocess(_ packet:MIDIPacket) {
        // small bit of pre-processing to get numbers
        // from the MIDI range into a more sensible range for dealing with angles
        
        // if we're the new firmware version
        if firmwareMajorVersion > 0 && firmwareMinorVersion > 0
        {
            //print("NEW FIRMWARE 2.1")
            var x1 = Double(Int8(truncatingBitPattern: Int(packet.data.2)))
            var y1 = Double(Int8(truncatingBitPattern: Int(packet.data.5)))
            var x2 = Double(Int8(truncatingBitPattern: Int(packet.data.11)))
            var y2 = Double(Int8(truncatingBitPattern: Int(packet.data.14)))
            
            var z1 = Double(Int8(truncatingBitPattern: Int(packet.data.8)))
            let z2 = Double(Int8(truncatingBitPattern: Int(packet.data.17)))
            
            //            print("z1Buffer: \(z1Buffer)")
            
            let zcorr = xcorrelate_bignorm(array1: z1Buffer, array2: z2Buffer)
            //            xcorrelate_normalised(array1: z2Buffer, array2: z2Buffer)
            //            xcorrelate(array1: z1Buffer, array2: z2Buffer) / sqrt(  *  )
            
            
            
            let out3 = Double(Int8(truncatingBitPattern: Int(packet.data.20)))
            
            if x1 == out3 && (y1 == 0 || z1 == 0){
                x1 = 0
                print("Filtering a glitch!!!!!!!!!!!!!!!!")
            }
            
            
            
            //            print("\(x1 == 1 ? "1" : "XXX")",
            //                    "\(y1 == 2 ? "2" : "XXX")",
            //                    "\(zz1 == 3 ? "3" : "XXX")",
            //                    "\(x2 == 4 ? "4" : "XXX")",
            //                    "\(y2 == 5 ? "5" : "XXX")",
            //                    "\(zz2 == 6 ? "6" : "XXX")",
            //                    "\((out3 == 7 || out3 == 9 || out3 == 13 || out3 == 15) ? "7" : "XXX")")
            
            //            print("\(x1)",
            //                "\(y1)",
            //                "\(z1)",
            //                "\(x2)",
            //                "\(y2)",
            //                "\(z2)",
            //                "\(out3)")
            
            
            // print("rBuffer = \(rBuffer)")
            x1Buffer.remove(at: 4)
            x1Buffer.insert(Int(x1), at: 0)
            
            
            
            //            for i in 0...3 {
            //                if i == 0 {
            //                    let replacementArray = [x1Buffer[0], x1Buffer[0], x1Buffer[1]]
            //                    x1Buffer[i] = replacementArray.sorted()[1]
            //                }
            //                else if i == 3 {
            //                    let replacementArray = [x1Buffer[2], x1Buffer[3], x1Buffer[4]]
            //                    x1Buffer[i] = replacementArray.sorted()[1]
            //                }
            //                else {
            //                    let replacementArray = [x1Buffer[i-1], x1Buffer[i], x1Buffer[i+1]]
            //                    x1Buffer[i] = replacementArray.sorted()[1]
            //                }
            //            }
            
            y1Buffer.remove(at: bufferSize - 1)
            y1Buffer.insert(Int(y1), at: 0)
            
            z1Buffer.remove(at: bufferSize - 1)
            z1Buffer.insert(Int(z1), at: 0)
            
            x2Buffer.remove(at: bufferSize - 1)
            x2Buffer.insert(Int(x2), at: 0)
            y2Buffer.remove(at: bufferSize - 1)
            y2Buffer.insert(Int(y2), at: 0)
            
            z2Buffer.remove(at: bufferSize - 1)
            z2Buffer.insert(Int(z2), at: 0)
            
            
            //            z1Buffer = y1Buffer
            if x1 == out3 {
                x1Buffer[0] = medianFilter(array: x1Buffer)[1]
            }
            else if y1 == x1 {
                y1Buffer[0] = medianFilter(array: y1Buffer)[1]
            }
            else if z1 == y1 {
                z1Buffer[0] = medianFilter(array: z1Buffer)[1]
            }
            else if x2 == z1 {
                x2Buffer[0] = medianFilter(array: x2Buffer)[1]
            }
            else if y2 == x2 {
                y2Buffer[0] = medianFilter(array: y2Buffer)[1]
            }
            else if z2 == y2 {
                z2Buffer[0] = medianFilter(array: z2Buffer)[1]
            }
            
            let r1 = getMagnitude(x1, y: y1)
            r1Buffer.remove(at: bufferSize - 1)
            r1Buffer.insert(Int(r1), at: 0)
            let r2 = getMagnitude(x2, y: y2)
            r2Buffer.remove(at: bufferSize - 1)
            r2Buffer.insert(Int(r2), at: 0)
            
            x1 = x1Buffer[0] < 0 ? Double(x1Buffer[0]) / 128.0 : Double(x1Buffer[0]) / 127.0
            y1 = y1Buffer[0] < 0 ? Double(y1Buffer[0]) / 128.0 : Double(y1Buffer[0]) / 127.0
            z1 = z1Buffer[0] < 0 ? Double(z1Buffer[0]) / 128.0 : Double(z1Buffer[0]) / 127.0
            
            x2 = x2Buffer[0] < 0 ? Double(x2Buffer[0]) / 128.0 : Double(x2Buffer[0]) / 127.0
            y2 = y2Buffer[0] < 0 ? Double(y2Buffer[0]) / 128.0 : Double(y2Buffer[0]) / 127.0
            
            let x = 0.5 * (x1 + x2)
            let y = 0.5 * (y1 + y2)
            var z = 0.0
            
            
            let rz1corr = xcorrelate_bignorm(array1: z1Buffer, array2: r1Buffer)
            let rz2corr = xcorrelate_bignorm(array1: z2Buffer, array2: r2Buffer)
			
            var zcorrgate = 0.0
            if zcorr.isFinite && rz1corr.isFinite && rz2corr.isFinite {
                
                
                if (!rz1corr.isZero || !rz2corr.isZero){
                    zcorrgate = zcorr / (rz1corr + rz2corr)
                    //                    print("zcorrgate  = \(zcorrgate)")
                    
                }
                else if zcorr > 0.2 {
                    zcorrgate = 100//zcorr
                    //                    print(">>> zcorrgate  = \(zcorrgate)")
                    
                }
            }
            
            //TODO: Calculate covariance/correlation between zz0 ans zz1
            
            if zcorrgate > 0.3 {
                //                print("--------------------ORANGE LET THROUGH z1: \(z1) z2: \(z2)")
                z = 0.5 * Double(z1Buffer[1] + z2Buffer[1]) / 127.0
            }
            else{
                //                print("--------------------Z IS DEAD")
                
            }
            
			
            R1 = getMagnitude(x1, y: y1)
            T1 = radToDegrees(atan2(x1, y1)) + 180.0
            
            
            R2 = getMagnitude(x2, y: y2)
            T2 = radToDegrees(atan2(x2, y2)) + 180.0
            
            R1 = getMagnitude(x, y: y)
            T1 = radToDegrees(atan2(x, y)) + 180.0
            
            
            R2 = R1
            T2 = T1
            
            
            
            Z3 = z;
            
            
            if !calibrating {
                // once we've set our main variables the main
                // work can be done on decoding the signal
                decodeAngle2()
                // Then we can route the signals to any delegate listening for updates
                routeSignals2()
            }
        }
        else if firmwareMajorVersion == 0 && firmwareMinorVersion == 0 { // old firmware version (indiegogo and first Apple revision (no firmware number on either)
            //            print("OLD FIRMWARE 2.0")
            R1 = Double(packet.data.2) / 127.0
            T1 = Double(packet.data.5) * (360.0 / 127.0)
            R2 = Double(packet.data.8) / 127.0
            T2 = Double(packet.data.11) * (360.0 / 127.0)
            Z3 = Double(packet.data.14) / 127.0
            // this may end up being a different method or variation of decodeAngle()
            if !calibrating {
                decodeAngle()
                // routeSignals might always be the same function, but if the firmware version is -1 then we don't to send anything yet
                // Maybe need something cleverer that this
                routeSignals()
            }
        }
    }
    
    // MARK:  Cross Correlation
    func xcorrelate_normalised(array1: [Int], array2: [Int]) {
        var j1 = 0
        //        var j2 = 0
        var k1 = 0
        var k2 = 0
        var i = 0
        var xcorr = Array(repeating: 0.0, count: 2 * bufferSize - 1)
        while i < (2 * bufferSize - 1) {
            var sum = 0.0
            if i > (bufferSize - 1){
                k1 = 2 * bufferSize - 2 - i
                k2 = bufferSize - 1
                for n in 0 ... k1 {
                    //print("IF: array1 element \(n) array2 element \(k2 - (k1 - n))")
                    sum += Double (array1[n] * array2[k2 - (k1 - n)])
                    sum /=  sqrt(Double (array1[n] * array1[n] * array2[k2 - (k1 - n)] * array2[k2 - (k1 - n)]))
                }
                xcorr[i] = Double(sum)
            }
            else {
                j1 = bufferSize - i - 1;
                k1 = bufferSize -	1;
                for n in j1 ... k1 {
                    //print("ELSE: array1 element \(n) array2 element \(n - j1)")
                    sum += Double (array1[n] * array2[n - j1])
                    sum /=  sqrt(Double (array1[n] * array1[n] * array2[n - j1] * array2[n - j1]))
                    
                }
                xcorr[i] = Double(sum)
            }
            i += 1
        }
        
        
        //return xcorr
        //        print("xcorr: \(xcorr)")
        //        print("xcorr max \(xcorr.max())")
    }
    
    
    func xcorrelate_bignorm(array1: [Int], array2: [Int]) -> Double {
        var j1 = 0
        //        var j2 = 0
        var k1 = 0
        var k2 = 0
        var i = 0
        var xcorr = Array(repeating: 0.0, count: 2 * bufferSize - 1)
        while i < (2 * bufferSize - 1) {
            var sum = 0.0
            if i > (bufferSize - 1){
                k1 = 2 * bufferSize - 2 - i
                k2 = bufferSize - 1
                for n in 0 ... k1 {
                    //print("IF: array1 element \(n) array2 element \(k2 - (k1 - n))")
                    sum += Double (array1[n] * array2[k2 - (k1 - n)])
                    sum /=  abs(array1[n]) >= abs(array2[k2 - (k1 - n)])
                        ? Double (array1[n] * array1[n])
                        : Double (array2[k2 - (k1 - n)] * array2[k2 - (k1 - n)])
                }
                xcorr[i] = Double(sum)
            }
            else {
                j1 = bufferSize - i - 1;
                k1 = bufferSize -	1;
                for n in j1 ... k1 {
                    //print("ELSE: array1 element \(n) array2 element \(n - j1)")
                    sum += Double (array1[n] * array2[n - j1])
                    sum /= abs(array1[n]) >= abs(array2[n - j1])
                        ? Double (array1[n] * array1[n])
                        : Double (array2[n - j1] * array2[n - j1])
                }
                xcorr[i] = Double(sum)
            }
            i += 1
        }
        
        var xcorrsum = 0.0;
        for n in 0 ... xcorr.count - 1 {
            if xcorr[n].isFinite{
                xcorrsum += xcorr[n]
            }
        }
        
        //        print("max \(xcorr.max()) : sum/n = \(xcorrsum/Double(xcorr.count))")
        
        return xcorrsum/Double(xcorr.count)
    }
    
    
    func xcorrelate_smallnorm(array1: [Int], array2: [Int]) -> Double {
        var j1 = 0
        //        var j2 = 0
        var k1 = 0
        var k2 = 0
        var i = 0
        var xcorr = Array(repeating: 0.0, count: 2 * bufferSize - 1)
        while i < (2 * bufferSize - 1) {
            var sum = 0.0
            if i > (bufferSize - 1){
                k1 = 2 * bufferSize - 2 - i
                k2 = bufferSize - 1
                for n in 0 ... k1 {
                    //print("IF: array1 element \(n) array2 element \(k2 - (k1 - n))")
                    sum += Double (array1[n] * array2[k2 - (k1 - n)])
                    sum /=  abs(array1[n]) <= abs(array2[k2 - (k1 - n)])
                        ? Double (array1[n] * array1[n])
                        : Double (array2[k2 - (k1 - n)] * array2[k2 - (k1 - n)])
                }
                xcorr[i] = Double(sum)
            }
            else {
                j1 = bufferSize - i - 1;
                k1 = bufferSize -	1;
                for n in j1 ... k1 {
                    //print("ELSE: array1 element \(n) array2 element \(n - j1)")
                    sum += Double (array1[n] * array2[n - j1])
                    sum /= abs(array1[n]) <= abs(array2[n - j1])
                        ? Double (array1[n] * array1[n])
                        : Double (array2[n - j1] * array2[n - j1])
                }
                xcorr[i] = Double(sum)
            }
            i += 1
        }
        
        var xcorrsum = 0.0;
        for n in 0 ... xcorr.count - 1 {
            if xcorr[n].isFinite{
                xcorrsum += xcorr[n]
            }
        }
		
        return xcorrsum/Double(xcorr.count)
    }
    
    
    
    func xcorrelate(array1: [Int], array2: [Int]) -> Array<Double> {
        //        let before = CACurrentMediaTime()
        
        
        var j1 = 0
        //        var j2 = 0
        var k1 = 0
        var k2 = 0
        var i = 0
        let buffersize = 8;//TBC
        var xcorr = Array(repeating: 0.0, count: 2 * buffersize - 1)
        while i < (2 * buffersize - 1) {
            var sum = 0
            if i > (buffersize - 1){
                k1 = 2 * buffersize - 1 - i
                k2 = buffersize - 1
                for n in 0 ... k1 {
                    sum += array1[n] * array2[k2 - (k1 - n)]
                }
                xcorr[i] = Double(sum)
            }
            else {
                j1 = buffersize - i - 1;
                k1 = buffersize -	1;
                for n in j1 ... k1 {
                    sum += array1[n] * array2[n - j1]
                }
                xcorr[i] = Double(sum)
            }
            i += 1
        }
        //        let after = CACurrentMediaTime()-before
        //        print("Time to run xcorr method: \(after)")
        //        print("xcorr: \(xcorr)")
        //        print("xcorr max \(xcorr.max())")
        return xcorr
    }
    
    
    func handle(_ packet:MIDIPacket) {
        if packet.data.1 == 102 &&
            packet.data.4 == 103 &&
            packet.data.7 == 104 &&
            packet.data.10 == 105 &&
            packet.data.13 == 106 &&
            packet.data.16 == 107 &&
            packet.data.19 == 108 {
            //print("raw packet: \(packet)")
            self.themidipacket[0] = Int(packet.data.2)
            self.themidipacket[1] = Int(packet.data.5)
            self.themidipacket[2] = Int(packet.data.8)
            self.themidipacket[3] = Int(packet.data.11)
            self.themidipacket[4] = Int(packet.data.14)
            self.themidipacket[5] = Int(packet.data.17)
            self.themidipacket[6] = Int(packet.data.20)
            packetCount += 1
            currentPacket = CACurrentMediaTime()
            currentTime = currentPacket
            
			if currentTime-lastTime >= 1.0 {
                packetCount = 0
                lastTime = CACurrentMediaTime()
            }
            lastPacket = currentPacket
            //            CACurrentMediaTime
            preprocess(packet)

        }
    }
    
    // MARK: Helper methods
    public func initialiseSkoog() {
        setPolyMode(active: self.polyMode)
        // and anything else that needs doing...
    }
    
    public func setPolyMode(active: Bool) {
        //        print("Setting mono/Poly mode")
        if active {
            if firmwareMajorVersion > 0 && firmwareMinorVersion > 0 {
                self.XYcone = 16.0
                self.ZconeZ = 30.0
                self.ZconeXY = 10
                self.polyMode = true
            }
            else {
                self.XYcone = 16.0
                self.ZconeZ = 16.5
                self.ZconeXY = 10
                self.polyMode = true
            }
        }
        else {
            if firmwareMajorVersion > 0 && firmwareMinorVersion > 0 {
                self.XYcone = 45.0
                self.ZconeZ = 45.0
                self.ZconeXY = 45.0
                self.polyMode = false
            }
            else {
                self.XYcone = 45.0
                self.ZconeZ = 45.0
                self.ZconeXY = 30
                self.polyMode = false
            }
        }
        changeXYcone(self.XYcone)
    }
    
    public func getSkoogConnected()->Bool {
        return self.skoogConnected
    }
    
    func getMagnitude(_ x:Double, y:Double)->Double
    {
        return sqrt(x * x + y * y)
    }
    
    func radToDegrees(_ radians:Double)->Double
    {
        return radians * 180.0 / Double.pi
    }
    
    func degToRadians(_ degrees:Double)->Double
    {
        return Double.pi * degrees / 180
    }
    
    func cosAplusB(_ a:Double, b:Double)->Double
    {
        return cos(a) * cos(b) - sin(a) * sin(b)
    }
    
    func cosAminusB(_ a:Double, b:Double)->Double
    {
        return cos(a) * cos(b) + sin(a) * sin(b)
    }
    
    func sinAplusB(_ a:Double, b:Double)->Double
    {
        return sin(a) * cos(b) + sin(b) * cos(a)
    }
    
    func sinAminusB(_ a:Double, b:Double)->Double
    {
        return sin(a) * cos(b) - sin(b) * cos(a)
    }
    
    func gatedLowPass(_ newinput:Double, oldinput:Double, alpha:Double, LPthreshold:Double, LPgate:Double)->Double
    {
        if newinput < LPthreshold
        {
            if newinput < LPgate
            {
                return 0.0
            }
            else
            {
                return  alpha * newinput + (1.0 - alpha) * oldinput
            }
        }
        else
        {
            return newinput
        }
    }
    
    func diffLowPass(_ newinput:Double, oldinput :Double, alpha:Double, LPdiff:Double)->Double
    {
        if fabs(newinput-oldinput) < LPdiff
        {
            return  alpha * newinput + (1.0 - alpha) * oldinput
        }
        else
        {
            return newinput
        }
    }
    
    func variableLowPass(_ newinput:Double, oldinput:Double, alpha:Double, LPthreshold:Double, LPgate:Double)->Double
    {
        if (newinput < (3.0 * LPgate))
        {
            if (newinput < (0.25 * LPgate))
            {
                return 0.0
            }
            else
            {
                let varalpha = ((1.0 - 0.000001) * alpha / (2.75 * LPgate)) * newinput + (1 - 3.0*(1.0 - 0.000001)/2.75) * alpha
                return  varalpha * newinput + (1.0 - varalpha) * oldinput
            }
        }
        else
        {
            return alpha * newinput + (1.0 - alpha) * oldinput
        }
    }
    
    func variableDiffLowPass(_ newinput:Double, lastoutput:Double, alpha:Double, LPdiff:Double, signalstrength:Double, LPgate:Double)->Double {
        let change = fabs(newinput-lastoutput)
        if change < LPdiff {
            if change < 35.0 {
                var varalpha = alpha * change / 35.0       // Linear Alpha Variation
                
                if signalstrength < (3.0 * LPgate) {
                    varalpha *= signalstrength / (3.0 * LPgate)
                }
                return  varalpha * newinput + (1.0 - varalpha) * lastoutput
            }
            else {
                return  alpha * newinput + (1.0 - alpha) * lastoutput
            }
        }
        else {
            return newinput
        }
    }
    
    // scale the input sensor values and make sure they don't exceed 1 or go below 0
    func zoom(_ x:Double, y:Double)->Double {
        if x * y > 0.999999 {
            return 0.999999
        }
        else if x * y < 0.0000001 {
            return 0.0000001
        }
        else {
            return x * y
        }
    }
    
    func changeXYcone(_ angle:Double) {
        XYcone = angle
        coneAngle = 90.0 - (2.0 * angle)
        redBlueAngle = 180.0 + angle
        redGreenAngle = 90.0 + angle
        blueYellowAngle = 270.0 + angle
        yellowGreenAngle = angle
    }
    
    func calculateResponse (amount: Double, input: Double)->Double {
        return input / (pow(2, -amount) * (1.0 - input) + input)
    }
    
    func invertResponse(amount : Double, input : Double, invertPercentage: Double)->Double {
        return input / (pow(2, amount * invertPercentage) * (1.0 - input) + input)
    }
    
    // MARK: Decode MIDI packets
    func decodeAngle2() {
        //        print("R1: \(R1) R2: \(R2), T1: \(T1), T2: \(T2)")
        //        print("T1: \(T1)")
        
        //TODO: confirm angle LP alpha
        T1 = diffLowPass(T1, oldinput: T1_old, alpha: 0.85, LPdiff: 45.0)
        T2 = diffLowPass(T2, oldinput: T2_old, alpha: 0.85, LPdiff: 45.0)
        
        // Correction to angle for single sensor activation scenarios
        if R1 == 0.0 && R2 > 0.0 {
            T1 = T2
        }
        else if R1 > 0.0 && R2 == 0 {
            T2 = T1
        }
        
        //TODO: confiigure input LP alpha
        //        R1 = variableLowPass(zoom(R1, y: R_zoom), oldinput: R1_old, alpha: 0.5, LPthreshold: 1.5, LPgate: zoom(0.023622, y: R_zoom))
        //        R2 = variableLowPass(zoom(R2, y: R_zoom), oldinput: R2_old, alpha: 0.5, LPthreshold: 1.5, LPgate: zoom(0.023622, y: R_zoom))
        
        // calculate average Rxy from sensors 1 and 2
        //        Rxy = 0.5.squareRoot() * getMagnitude(R1, y: R2)
        Rxy = 0.5 * (R1 + R2)
        Rxy = (0.0...1.0).clamp(value: Rxy)
        
        //TODO: confiigure input T1 alpha (prev 0.166)
        
        T1 = variableDiffLowPass(T1, lastoutput: T1_old, alpha: 0.5, LPdiff: 45.0, signalstrength:Rxy, LPgate: zoom(0.023622, y: R_zoom))
        
        Txy = T1
        
        //TODO: confiigure input Z alpha
        //        Z3 = gatedLowPass(zoom(Z3, y: R_zoom), oldinput: Z3_old, alpha: 0.052, LPthreshold: 1.5, LPgate: z_threshold)
        
        Rxyz = getMagnitude(Rxy, y: Z3)
        
        param3 = 0.0
        param4 = 0.0
        
        thresholdZoom = 0.012;  //lowest value is 1/127 = 0.0078 - pass if over 1.5 * 0.0078
        z_thresholdZoom = 0.012;
        
        //TODO: configure input thresholds
        if Rxyz > thresholdZoom || Rxy > thresholdZoom || Z3 > z_thresholdZoom {
            if Rxyz > thresholdZoom {
                Rxyz = (Rxyz - thresholdZoom)/(1.0 - thresholdZoom) //normalise output after taking threshold into account
            }
            if Rxy > thresholdZoom {
                Rxy = (Rxy - thresholdZoom)/(1.0 - thresholdZoom) //normalise output after taking threshold into account
            }
            if Z3 > z_thresholdZoom {
                Z3 = (Z3 - z_thresholdZoom)/(1.0 - z_thresholdZoom) //normalise output after taking threshold into account
            }
            
            Tz = radToDegrees(atan2(Z3, Rxy))
            
            //            Tz = diffLowPass(Tz, oldinput: Tz_old, alpha: 0.95, LPdiff: 91.0)
            
            
            Rxyz = (0.0...1.0).clamp(value: getMagnitude(Rxy, y: Z3))
            
            if (Tz >= 90 - ZconeZ && Tz <= 90 + ZconeZ) {
                zone = .orange_side
                param4 = -((Tz - 90) / ZconeZ)
            }
            else {
                if Tz <= ZconeXY {
                    if Txy >= 270 - XYcone && Txy <= 270 + XYcone {
                        zone = .blue_side
                        param3 = (Txy - 270) / XYcone
                    }
                    else if Txy > (180.0 + XYcone) && Txy < (270.0 - XYcone) {
                        zone = .red_blue
                        param3 = (Txy - redBlueAngle) / coneAngle
                    }
                    else if Txy >= 180 - XYcone && Txy <= 180 + XYcone {
                        zone = .red_side
                        param3 = (Txy - 180) / XYcone
                    }
                    else if Txy > (90 + XYcone) && Txy < (180 - XYcone) {
                        zone = .red_green
                        param3 = (Txy - redGreenAngle) / coneAngle
                    }
                    else if Txy >= 90 - XYcone && Txy <= 90 + XYcone {
                        zone = .green_side
                        param3 = (Txy-90)/XYcone
                    }
                    else if Txy > XYcone && Txy < (90 - XYcone) {
                        zone = .yellow_green
                        
                        param3 = (Txy - yellowGreenAngle) / coneAngle
                    }
                    else if (Txy >= 0 && Txy <= XYcone) || Txy >= 360 - XYcone {
                        zone = .yellow_side
                        param3 = Txy > 360 - XYcone ? (Txy - 360) / XYcone : Txy / XYcone
                    }
                    else {
                        zone = .blue_yellow
                        param3 = (Txy - blueYellowAngle) / coneAngle
                    }
                    param4 = (Tz) / ZconeXY
                }
                else {
                    if Txy >= 270 - XYcone && Txy <= 270 + XYcone {
                        zone = .orange_blue
                        param3 = (Txy-270) / XYcone
                    }
                    else if Txy > 180 + XYcone && Txy < 270 - XYcone {
                        zone = .orange_red_blue
                        param3 = (Txy - 180) / (90 - XYcone)
                    }
                    else if Txy >= 180 - XYcone && Txy <= 180 + XYcone {
                        zone = .orange_red
                        param3 = (Txy - 180) / XYcone
                    }
                    else if Txy > 90 + XYcone && Txy < 180 - XYcone {
                        zone = .orange_red_green
                        param3 = (Txy - 135) / (45 - XYcone)
                    }
                    else if Txy >= 90 - XYcone && Txy <= 90 + XYcone {
                        zone = .orange_green
                        param3 = (Txy - 90) / XYcone
                    }
                    else if (Txy > XYcone && Txy < 90 - XYcone) {
                        zone = .orange_yellow_green
                        param3 = (Txy - 45) / (45 - XYcone)
                    }
                    else if (Txy >= 0 && Txy <= XYcone) || Txy > 360 - XYcone {
                        zone = .orange_yellow
                        param3 = Txy > 360 - XYcone ? (Txy-360) / XYcone : (Txy) / XYcone
                    }
                    else {
                        zone = .orange_blue_yellow
                        param3 = (Txy-315) / (45-XYcone)
                    }
                    param4 = (Tz - ZconeXY) / (90-ZconeZ-ZconeXY) //90-ZconeZ-ZconeXY is the width of the remaining segement
                }
            }
        }
        else {
            
            zone = .none
            Rxyz = 0.0 //normalise output after taking threshold into account
            Rxy = 0.0 //normalise output after taking threshold into account
            Z3 = 0.0 //normalise output after taking threshold into account
            Tz = ZconeXY + 0.5 * (90 - ZconeZ - ZconeXY) //180 * atan2f(Z3, Rxy) / M_PI
            Txy = 180.0
        }
        
        Rxyz_old = Rxyz
        Rxy_old = Rxy
        R1_old = R1
        R2_old = R2
        T1_old = T1
        T2_old = T2
        Tz_old = Tz
        Z3_old = Z3
    }
    
    
    func routeSignals2()
    {
        let zone1 : Int = activeZones[zone.rawValue][0].rawValue
        let zone2 : Int = activeZones[zone.rawValue][1].rawValue
        let zone3 : Int = activeZones[zone.rawValue][2].rawValue
        
        let lastZone1 : Int = activeZones[lastZone.rawValue][0].rawValue
        let lastZone2 : Int = activeZones[lastZone.rawValue][1].rawValue
        let lastZone3 : Int = activeZones[lastZone.rawValue][2].rawValue
        
        currenttime = NSDate()
        let deltaT = currenttime.timeIntervalSince(lasttime as Date)
        lasttime = currenttime
        // send shut up message(s)
        if (zone != lastZone && lastZone != .none)
        {  // don't repeatedly tell lastZone to shut up if he hasn't changed
            if (lastZone1 != zone1 &&
                lastZone1 != zone2 &&
                lastZone1 != zone3)
            {
                if (lastZone1 != Zone.none.rawValue) {
                    flushSide(index:lastZone1)
                }
            }
            if (lastZone2 != zone1 &&
                lastZone2 != zone2 &&
                lastZone2 != zone3)
            {
                if (lastZone2 != Zone.none.rawValue) {
                    flushSide(index:lastZone2)
                }
            }
            if (lastZone3 != zone1 &&
                lastZone3 != zone2 &&
                lastZone3 != zone3)
            {
                if (lastZone3 != Zone.none.rawValue) {
                    flushSide(index:lastZone3)
                }
            }
        }
        
        bend_out = 1 - 0.5 * (param3 + 1.0)
        bend_in = 1 - bend_out
        
        let blend_in_xy = abs(sin(param3 * .pi / 2))
        let blend_out_xy = cos(param3 * .pi / 2)
        let blend_in_z = abs(sin(param4 * .pi / 2))
        
        let inputBlendOutXY = Rxy * blend_out_xy
        let inputBlendInXY = Rxy * blend_in_xy
        let inputBlendInZ = Rxyz * blend_in_z
        let inputBlendOutZ = Rxyz * blend_out_z
        let inputBlendOutXYZ = Rxyz * blend_out_z * blend_out_xy
        let inputBlendInXYZ = Rxyz * blend_out_z * blend_in_xy
        
        switch (zone)
        {
        case .none:
            if lastZone != .none
            {
                for i in 0 ... 4 {
                    if sides[i].isPlaying {
                        flushSide(index:i)
                    }
                }
            }
        case .red_side:
            red.rawValue = Rxy
        case .blue_side:
            blue.rawValue = Rxy
        case .yellow_side:
            yellow.rawValue = Rxy
        case .green_side:
            green.rawValue = Rxy
        case .orange_side:
            orange.rawValue = Rxyz
        default:
            if polyMode
            {
                switch (zone)
                {
                case .red_blue:
                    red.rawValue       = inputBlendOutXY
                    blue.rawValue      = inputBlendInXY
                case .blue_yellow:
                    blue.rawValue      = inputBlendOutXY
                    yellow.rawValue    = inputBlendInXY
                case .yellow_green:
                    yellow.rawValue    = inputBlendOutXY
                    green.rawValue     = inputBlendInXY
                case .red_green:
                    green.rawValue     = inputBlendOutXY
                    red.rawValue       = inputBlendInXY
                case .orange_red:
                    orange.rawValue    = inputBlendInZ
                    red.rawValue       = inputBlendOutZ
                case .orange_blue:
                    orange.rawValue    = inputBlendInZ
                    blue.rawValue      = inputBlendOutZ
                case .orange_yellow:
                    orange.rawValue    = inputBlendInZ
                    yellow.rawValue    = inputBlendOutZ
                case .orange_green:
                    orange.rawValue    = inputBlendInZ
                    green.rawValue     = inputBlendOutZ
                case .orange_red_blue:
                    orange.rawValue    = inputBlendInZ
                    red.rawValue       = inputBlendOutXYZ
                    blue.rawValue      = inputBlendInXYZ
                case .orange_blue_yellow:
                    orange.rawValue    = inputBlendInZ
                    blue.rawValue      = inputBlendOutXYZ
                    yellow.rawValue    = inputBlendInXYZ
                case .orange_yellow_green:
                    orange.rawValue    = inputBlendInZ
                    yellow.rawValue    = inputBlendOutXYZ
                    green.rawValue     = inputBlendInXYZ
                case .orange_red_green:
                    orange.rawValue    = inputBlendInZ
                    red.rawValue       = inputBlendOutXYZ
                    green.rawValue     = inputBlendInXYZ
                default: break
                }
            }
        }
        var peak : Double?
        if zone1 != Zone.none.rawValue {
            
            if sides[zone1].rawValue >= sides[zone1].threshold {
                peak = sides[zone1].peak?.detect(input: sides[zone1].rawValue, dT: deltaT)
                sides[zone1].peakValue = peak
                sides[zone1].deltaT = deltaT
            }
            else {
                sides[zone1].peak?.reset()
                if threshRelease {
                    flushSide(index:zone1)
                    threshRelease = false
                }
                //                peak = sides[zone1].peak?.detect(input: 0.0, dT: deltaT)
            }
            
            sides[zone1].value = calculateResponse(amount: sides[zone1].response, input: sides[zone1].rawValue)
            delegate?.continuous(side: sides[zone1])
            if peak != nil {
                if (peak! > 0.0) {
                    delegate?.peak(side: sides[zone1], peak: calculateResponse(amount: sides[zone1].response, input: peak!))
                    //TODO: threshRelease setup for mono (single zone) mode only
                    threshRelease = true
                    sides[zone1].isPlaying = true
                }
            }

        }
        peak = nil
//        if zone2 != Zone.none.rawValue {
//            if sides[zone2].rawValue >= sides[zone2].threshold {
//                peak = sides[zone2].peak?.detect(input: sides[zone2].rawValue, dT: deltaT)
//            }
//            else {
//                sides[zone2].peak?.reset()
//                if threshRelease {
//                    print("release the pressure 2!")
//                    flushSide(index:zone2)
//                }
//            }
//            sides[zone2].value = calculateResponse(amount: sides[zone2].response, input: sides[zone2].rawValue)
//            if peak != nil {
//                if (peak! > 0.0) {
//                    delegate?.peak(side: sides[zone2], peak: calculateResponse(amount: sides[zone2].response, input: peak!))
//                    sides[zone2].isPlaying = true
//                }
//            }
//            delegate?.continuous(side: sides[zone2])
//        }
//        peak = nil
//        if zone3 != Zone.none.rawValue {
//            if sides[zone3].rawValue >= sides[zone3].threshold {
//                peak  = sides[zone3].peak?.detect(input: sides[zone3].rawValue, dT: deltaT)
//            }
//            else {
//                sides[zone3].peak?.reset()
//                if threshRelease {
//                    flushSide(index:zone3)
//                }            }
//            //            let peak = sides[zone3].peak?.detect(input: sides[zone3].rawValue, dT: deltaT)
//            sides[zone3].value = calculateResponse(amount: sides[zone3].response, input: sides[zone3].rawValue)
//            if peak != nil {
//                if (peak! > 0.0) {
//                    delegate?.peak(side: sides[zone3], peak: calculateResponse(amount: sides[zone3].response, input: peak!))
//                    sides[zone3].isPlaying = true
//                }
//            }
//            delegate?.continuous(side: sides[zone3])
//        }
        
        //        if !polyMode {
        //            if zone.rawValue <= Zone.orange_side.rawValue {
        //                let peak = sides[zone.rawValue].peak?.detect(input: sides[zone.rawValue].rawValue, dT: deltaT)
        ////                print("Peak \(peak)")
        //                sides[zone.rawValue].value = calculateResponse(amount: sides[zone.rawValue].response, input: sides[zone.rawValue].rawValue)
        //                if peak != nil {
        //                    if (peak! > 0.0) {
        //                        delegate?.peak(sides[zone.rawValue], calculateResponse(amount: sides[zone.rawValue].response, input: peak!))
        //                    }
        //                }
        //                else {
        //                    sides[zone.rawValue].angle = param3
        //                    delegate?.continuous(sides[zone.rawValue])
        //                }
        //            }
        //        }
        lastZone = zone
    }
  
    
    
    
    // MARK: Decode MIDI packets
    func decodeAngle() {
        //        print("R1: \(R1) R2: \(R2), T1: \(T1), T2: \(T2)")
        //        print("T1: \(T1)")
        T1 = diffLowPass(T1, oldinput: T1_old, alpha: 0.05, LPdiff: 45.0)
        T2 = diffLowPass(T2, oldinput: T2_old, alpha: 0.05, LPdiff: 45.0)
        
        // Correction to angle for single sensor activation scenarios
        if R1 == 0.0 && R2 > 0.0 {
            T1 = T2
        }
        else if R1 > 0.0 && R2 == 0 {
            T2 = T1
        }
        
        R1 = variableLowPass(zoom(R1, y: R_zoom), oldinput: R1_old, alpha: 0.045, LPthreshold: 1.5, LPgate: zoom(0.023622, y: R_zoom))
        R2 = variableLowPass(zoom(R2, y: R_zoom), oldinput: R2_old, alpha: 0.045, LPthreshold: 1.5, LPgate: zoom(0.023622, y: R_zoom))
        
        // calculate average Rxy from sensors 1 and 2
        Rxy = 0.5.squareRoot() * getMagnitude(R1, y: R2)
        
        T1 = variableDiffLowPass(T1, lastoutput: T1_old, alpha: 0.166, LPdiff: 45.0, signalstrength:Rxy, LPgate: zoom(0.023622, y: R_zoom))
        
        Txy = T1
        
        Z3 = gatedLowPass(zoom(Z3, y: R_zoom), oldinput: Z3_old, alpha: 0.052, LPthreshold: 1.5, LPgate: z_threshold)
        
        Rxyz = getMagnitude(Rxy, y: Z3)
        
        param3 = 0.0
        param4 = 0.0
        
        
        if Rxyz > thresholdZoom || Rxy > thresholdZoom || Z3 > z_thresholdZoom {
            if Rxyz > thresholdZoom {
                Rxyz = (Rxyz - thresholdZoom)/(1.0 - thresholdZoom) //normalise output after taking threshold into account
            }
            if Rxy > thresholdZoom {
                Rxy = (Rxy - thresholdZoom)/(1.0 - thresholdZoom) //normalise output after taking threshold into account
            }
            if Z3 > z_thresholdZoom {
                Z3 = (Z3 - z_thresholdZoom)/(1.0 - z_thresholdZoom) //normalise output after taking threshold into account
            }
            
            Tz = radToDegrees(atan2(Z3, Rxy))
            
            if lastZone != .none {
                if (lastZone == .green_side || lastZone == .yellow_side ||
                    lastZone == .orange_red_green || lastZone == .orange_yellow_green ||
                    lastZone == .orange_red_blue || lastZone == .orange_blue_yellow ||
                    lastZone == .orange_red || lastZone == .orange_blue ||
                    lastZone == .orange_yellow || lastZone == .orange_green) && Rxy == 0.0 && Tz == 90.0
                {
                    blocking = true
                }
                
                if blocking {
                    Z3 = 0.0
                    Tz = Tz_old
                }
                Tz = diffLowPass(Tz, oldinput: Tz_old, alpha: 0.166, LPdiff: 91.0)
            }
            else {
                blocking = false
                Tz = diffLowPass(Tz, oldinput: Tz_old, alpha: 0.95, LPdiff: 91.0)
            }
            
            
            var m : Double = 0.85
            var c : Double = 23.6
            var correction_factor_XY : Double = 0.0
            
            if Txy < 180.0 || Txy > (360.0 - XYcone) && Tz < 90.0 {
                if Tz > 74.6 {
                    m = 0.2916
                    c = 58.2633
                }
                
                correction_factor_XY = sin(degToRadians(Txy)) + 1.0 * (((Txy < 45.0 || Txy > 315.0)) ? cos(degToRadians(2.0 * Txy)) : 0.0)
                
                Tz_corrected = Tz * (1.0 - correction_factor_XY * (1.0 - 1.0 / m)) - correction_factor_XY * c / m
                
                if (Tz_corrected <= 0.0) {
                    Tz_corrected    = 0.000000001
                    ZC              = 0.000000001
                }
                else if (Tz_corrected >= 78.5) { // Above 78.5 tanf blows up.
                    Tz_corrected = Tz
                    ZC = Z3
                }
                else {
                    ZC = Rxy * tan(degToRadians(Tz_corrected))
                }
                Rxyz = getMagnitude(Rxy, y: ZC)
            }
            else {
                ZC = Z3
                Tz_corrected = Tz
            }
            
            if (Tz_corrected >= 90 - ZconeZ && Tz_corrected <= 90 + ZconeZ) {
                zone = .orange_side
                param4 = -((Tz_corrected - 90) / ZconeZ)
            }
            else {
                if Tz_corrected <= ZconeXY {
                    if Txy >= 270 - XYcone && Txy <= 270 + XYcone {
                        zone = .blue_side
                        param3 = (Txy - 270) / XYcone
                    }
                    else if Txy > (180.0 + XYcone) && Txy < (270.0 - XYcone) {
                        zone = .red_blue
                        param3 = (Txy - redBlueAngle) / coneAngle
                    }
                    else if Txy >= 180 - XYcone && Txy <= 180 + XYcone {
                        zone = .red_side
                        param3 = (Txy - 180) / XYcone
                    }
                    else if Txy > (90 + XYcone) && Txy < (180 - XYcone) {
                        zone = .red_green
                        param3 = (Txy - redGreenAngle) / coneAngle
                    }
                    else if Txy >= 90 - XYcone && Txy <= 90 + XYcone {
                        zone = .green_side
                        param3 = (Txy-90)/XYcone
                    }
                    else if Txy > XYcone && Txy < (90 - XYcone) {
                        zone = .yellow_green
                        
                        param3 = (Txy - yellowGreenAngle) / coneAngle
                    }
                    else if (Txy >= 0 && Txy <= XYcone) || Txy >= 360 - XYcone {
                        zone = .yellow_side
                        param3 = Txy > 360 - XYcone ? (Txy - 360) / XYcone : Txy / XYcone
                    }
                    else {
                        zone = .blue_yellow
                        param3 = (Txy - blueYellowAngle) / coneAngle
                    }
                    param4 = (Tz_corrected) / ZconeXY
                }
                else {
                    if Txy >= 270 - XYcone && Txy <= 270 + XYcone {
                        zone = .orange_blue
                        param3 = (Txy-270) / XYcone
                    }
                    else if Txy > 180 + XYcone && Txy < 270 - XYcone {
                        zone = .orange_red_blue
                        param3 = (Txy - 180) / (90 - XYcone)
                    }
                    else if Txy >= 180 - XYcone && Txy <= 180 + XYcone {
                        zone = .orange_red
                        param3 = (Txy - 180) / XYcone
                    }
                    else if Txy > 90 + XYcone && Txy < 180 - XYcone {
                        zone = .orange_red_green
                        param3 = (Txy - 135) / (45 - XYcone)
                    }
                    else if Txy >= 90 - XYcone && Txy <= 90 + XYcone {
                        zone = .orange_green
                        param3 = (Txy - 90) / XYcone
                    }
                    else if (Txy > XYcone && Txy < 90 - XYcone) {
                        zone = .orange_yellow_green
                        param3 = (Txy - 45) / (45 - XYcone)
                    }
                    else if (Txy >= 0 && Txy <= XYcone) || Txy > 360 - XYcone {
                        zone = .orange_yellow
                        param3 = Txy > 360 - XYcone ? (Txy-360) / XYcone : (Txy) / XYcone
                    }
                    else {
                        zone = .orange_blue_yellow
                        param3 = (Txy-315) / (45-XYcone)
                    }
                    param4 = (Tz_corrected - ZconeXY) / (90-ZconeZ-ZconeXY) //90-ZconeZ-ZconeXY is the width of the remaining segement
                }
            }
        }
        else {
            
            zone = .none
            Rxyz = 0.0 //normalise output after taking threshold into account
            Rxy = 0.0 //normalise output after taking threshold into account
            Z3 = 0.0 //normalise output after taking threshold into account
            ZC = 0.0 //normalise output after taking threshold into account
            Tz = ZconeXY + 0.5 * (90 - ZconeZ - ZconeXY) //180 * atan2f(Z3, Rxy) / M_PI
            Txy = 180.0
        }
        
        Rxyz_old = Rxyz
        Rxy_old = Rxy
        R1_old = R1
        R2_old = R2
        T1_old = T1
        T2_old = T2
        Tz_old = Tz
        Z3_old = Z3
    }
    // MARK: Route decoded signals back to the delegate
    func routeSignals()
    {
        let zone1 : Int = activeZones[zone.rawValue][0].rawValue
        let zone2 : Int = activeZones[zone.rawValue][1].rawValue
        let zone3 : Int = activeZones[zone.rawValue][2].rawValue
        
        let lastZone1 : Int = activeZones[lastZone.rawValue][0].rawValue
        let lastZone2 : Int = activeZones[lastZone.rawValue][1].rawValue
        let lastZone3 : Int = activeZones[lastZone.rawValue][2].rawValue
        
        currenttime = NSDate()
        let deltaT = currenttime.timeIntervalSince(lasttime as Date)
        lasttime = currenttime
        // send shut up message(s)
        if (zone != lastZone && lastZone != .none)
        {  // don't repeatedly tell lastZone to shut up if he hasn't changed
            if (lastZone1 != zone1 &&
                lastZone1 != zone2 &&
                lastZone1 != zone3)
            {
                if (lastZone1 != Zone.none.rawValue) {
                    sides[lastZone1].rawValue = 0.0
                    sides[lastZone1].value = 0.0
                    sides[lastZone1].peak?.reset()
                    delegate?.release(side: sides[lastZone1])
                    delegate?.continuous(side: sides[lastZone1])
                }
            }
            if (lastZone2 != zone1 &&
                lastZone2 != zone2 &&
                lastZone2 != zone3)
            {
                if (lastZone2 != Zone.none.rawValue) {
                    sides[lastZone2].rawValue = 0.0
                    sides[lastZone2].value = 0.0
                    sides[lastZone2].peak?.reset()
                    delegate?.release(side: sides[lastZone2])
                    delegate?.continuous(side: sides[lastZone2])
                }
            }
            if (lastZone3 != zone1 &&
                lastZone3 != zone2 &&
                lastZone3 != zone3)
            {
                if (lastZone3 != Zone.none.rawValue) {
                    sides[lastZone3].rawValue = 0.0
                    sides[lastZone3].value = 0.0
                    sides[lastZone3].peak?.reset()
                    delegate?.release(side: sides[lastZone3])
                    delegate?.continuous(side: sides[lastZone3])
                }
            }
        }
        
        bend_out = 1 - 0.5 * (param3 + 1.0)
        bend_in = 1 - bend_out
        
        let blend_in_xy = abs(sin(param3 * .pi / 2))
        let blend_out_xy = cos(param3 * .pi / 2)
        let blend_in_z = abs(sin(param4 * .pi / 2))
        
        let inputBlendOutXY = Rxy * blend_out_xy
        let inputBlendInXY = Rxy * blend_in_xy
        let inputBlendInZ = Rxyz * blend_in_z
        let inputBlendOutZ = Rxyz * blend_out_z
        let inputBlendOutXYZ = Rxyz * blend_out_z * blend_out_xy
        let inputBlendInXYZ = Rxyz * blend_out_z * blend_in_xy
        
        switch (zone)
        {
        case .none:
            if lastZone != .none
            {
                for i in 0 ... 4 {
                    sides[i].rawValue = 0.0
                    sides[i].value = 0.0
                    sides[i].peak?.reset()
                    delegate?.release(side: sides[i])
                    delegate?.continuous(side: sides[i])
                }
            }
        case .red_side:
            red.rawValue = Rxy
        case .blue_side:
            blue.rawValue = Rxy
        case .yellow_side:
            yellow.rawValue = Rxy
        case .green_side:
            green.rawValue = Rxy
        case .orange_side:
            orange.rawValue = Rxyz
        default:
            if polyMode
            {
                switch (zone)
                {
                case .red_blue:
                    red.rawValue       = inputBlendOutXY
                    blue.rawValue      = inputBlendInXY
                case .blue_yellow:
                    blue.rawValue      = inputBlendOutXY
                    yellow.rawValue    = inputBlendInXY
                case .yellow_green:
                    yellow.rawValue    = inputBlendOutXY
                    green.rawValue     = inputBlendInXY
                case .red_green:
                    green.rawValue     = inputBlendOutXY
                    red.rawValue       = inputBlendInXY
                case .orange_red:
                    orange.rawValue    = inputBlendInZ
                    red.rawValue       = inputBlendOutZ
                case .orange_blue:
                    orange.rawValue    = inputBlendInZ
                    blue.rawValue      = inputBlendOutZ
                case .orange_yellow:
                    orange.rawValue    = inputBlendInZ
                    yellow.rawValue    = inputBlendOutZ
                case .orange_green:
                    orange.rawValue    = inputBlendInZ
                    green.rawValue     = inputBlendOutZ
                case .orange_red_blue:
                    orange.rawValue    = inputBlendInZ
                    red.rawValue       = inputBlendOutXYZ
                    blue.rawValue      = inputBlendInXYZ
                case .orange_blue_yellow:
                    orange.rawValue    = inputBlendInZ
                    blue.rawValue      = inputBlendOutXYZ
                    yellow.rawValue    = inputBlendInXYZ
                case .orange_yellow_green:
                    orange.rawValue    = inputBlendInZ
                    yellow.rawValue    = inputBlendOutXYZ
                    green.rawValue     = inputBlendInXYZ
                case .orange_red_green:
                    orange.rawValue    = inputBlendInZ
                    red.rawValue       = inputBlendOutXYZ
                    green.rawValue     = inputBlendInXYZ
                default: break
                }
            }
        }
        var peak : Double?
        if zone1 != Zone.none.rawValue {
            if sides[zone1].rawValue >= sides[zone1].threshold {
                peak = sides[zone1].peak?.detect(input: sides[zone1].rawValue, dT: deltaT)
            }
            else {
                sides[zone1].peak?.reset()
                if threshRelease {
                    print("release the pressure 1!")
                    delegate?.release(side: sides[zone1])
                    threshRelease = false
                }
                //                peak = sides[zone1].peak?.detect(input: 0.0, dT: deltaT)
            }
            
            sides[zone1].value = calculateResponse(amount: sides[zone1].response, input: sides[zone1].rawValue)
            if peak != nil {
                if (peak! > 0.0) {
                    delegate?.peak(side: sides[zone1], peak: calculateResponse(amount: sides[zone1].response, input: peak!))
                    //TODO: threshRelease setup for mono (single zone) mode only
                    threshRelease = true
                }
            }
            delegate?.continuous(side: sides[zone1])
        }
        peak = nil
        if zone2 != Zone.none.rawValue {
            if sides[zone2].rawValue >= sides[zone2].threshold {
                peak = sides[zone2].peak?.detect(input: sides[zone2].rawValue, dT: deltaT)
            }
            else {
                sides[zone2].peak?.reset()
                if threshRelease {
                    print("release the pressure 2!")
                    delegate?.release(side: sides[zone2])
                }
            }
            sides[zone2].value = calculateResponse(amount: sides[zone2].response, input: sides[zone2].rawValue)
            if peak != nil {
                if (peak! > 0.0) {
                    delegate?.peak(side: sides[zone2], peak: calculateResponse(amount: sides[zone2].response, input: peak!))
                }
            }
            delegate?.continuous(side: sides[zone2])
        }
        peak = nil
        if zone3 != Zone.none.rawValue {
            if sides[zone3].rawValue >= sides[zone3].threshold {
                peak  = sides[zone3].peak?.detect(input: sides[zone3].rawValue, dT: deltaT)
            }
            else {
                sides[zone3].peak?.reset()
                if threshRelease {
                    delegate?.release(side: sides[zone3])
                }            }
            //            let peak = sides[zone3].peak?.detect(input: sides[zone3].rawValue, dT: deltaT)
            sides[zone3].value = calculateResponse(amount: sides[zone3].response, input: sides[zone3].rawValue)
            if peak != nil {
                if (peak! > 0.0) {
                    delegate?.peak(side: sides[zone3], peak: calculateResponse(amount: sides[zone3].response, input: peak!))
                }
            }
            delegate?.continuous(side: sides[zone3])
        }
        
        //        if !polyMode {
        //            if zone.rawValue <= Zone.orange_side.rawValue {
        //                let peak = sides[zone.rawValue].peak?.detect(input: sides[zone.rawValue].rawValue, dT: deltaT)
        ////                print("Peak \(peak)")
        //                sides[zone.rawValue].value = calculateResponse(amount: sides[zone.rawValue].response, input: sides[zone.rawValue].rawValue)
        //                if peak != nil {
        //                    if (peak! > 0.0) {
        //                        delegate?.peak(sides[zone.rawValue], calculateResponse(amount: sides[zone.rawValue].response, input: peak!))
        //                    }
        //                }
        //                else {
        //                    sides[zone.rawValue].angle = param3
        //                    delegate?.continuous(sides[zone.rawValue])
        //                }
        //            }
        //        }
        lastZone = zone
    }
    
    public func flushSide(index:Int){
        sides[index].rawValue = 0.0
        sides[index].value = 0.0
        sides[index].peak?.reset()
        delegate?.release(side: sides[index])
        delegate?.continuous(side: sides[index])
        sides[index].isPlaying = false
    }
}
