//
//  SensorMaskCommandResponse.swift
//  SupportingContent
//
//  Created by Malin Sundberg on 2018-08-16.
//  Copyright © 2018 Sphero Inc. All rights reserved.
//

import Foundation

public struct SensorMaskCommandResponse: CommandResponseV2 {}
public struct SensorExtendedMaskCommandResponse: CommandResponseV2 {}
