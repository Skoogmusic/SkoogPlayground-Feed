//
// Copyright © 2017 Skoogmusic Inc.  All rights reserved.
//
import UIKit
import PlaygroundSupport

let viewController = LiveViewController()

viewController.setBackgroundGradient(gradient: .gradient4)

PlaygroundPage.current.liveView = viewController
