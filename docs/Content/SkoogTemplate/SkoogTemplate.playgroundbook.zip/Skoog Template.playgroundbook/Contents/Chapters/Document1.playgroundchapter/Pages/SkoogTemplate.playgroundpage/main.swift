//#-hidden-code
/*
 Copyright (C) 2016 Skoogmusic Ltd. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:** This is your blank canvas. Go crazy!
*/
//#-hidden-code

import UIKit
import PlaygroundSupport
import CoreAudioKit
import SpriteKit
import SceneKit
import Common

PlaygroundSupport.PlaygroundPage.current.needsIndefiniteExecution = true

public class skoogContents: PlaygroundViewController {
    public var inst: SoundStyle = .marimba
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, setNotes, setRipple, speed, noteShift, distance, angle, side, color, size, strength, value, rawValue, addPing, setSound(_:), Instrument.type, ., name, true, false)
//#-code-completion(identifier, show, acid, candyBee, fmModulator, sineWave, solarWind, gamelan, strat, rhodes, jharp, marimba, ocarina, minimogo, elecpiano, nylonguitar, vibraphone, afromallet, timpani)
//#-code-completion(literal, show, boolean, color)
//#-code-completion(keyword, show, for, if, let, var, while)
//#-editable-code tap to edit
func setup() {
	setSound(.vibraphone)
	
	setNotes(red:     32,
	         blue:    48,
	         yellow:  60,
	         green:   72,
	         orange:  84)
	
	addPing("red",
	        noteShift: 4,
	        distance: 1.5)
	
	addPing("white",
	        noteShift: 7,
	        distance: 2.5)
}
    
func press(side: Side, strength: Double) {
	ripple(color: side.color, size: strength)
}
    
func squeeze(side: Side) {

}
    
func lift(side: Side) {

}
  
func pingOn(index: Int, noteShift: Int, strength: Double) {

}

func pingOff(index: Int, noteShift: Int) {

}
//#-end-editable-code
	
    //#-hidden-code
    public override func peak(_ side: Side,_ peak: Double) {
        //on this page, call press before super, otherwise note settings will be out pf step
        press(side: side, strength: peak)
        super.peak(side, peak)
    }
    
    public override func continuous(_ side: Side) {
        super.continuous(side)
        squeeze(side:side)
    }
    
    public override func release(_ side: Side) {
        super.release(side)
        lift(side:side)
    }
    
    public override func pingPlay(index: Int, offset: Int, strength: Double) {
        super.pingPlay(index: index, offset: offset, strength: strength)
        pingOn(index: index, noteShift: offset, strength: strength)
    }
    
    public override func pingStop(index: Int, offset: Int) {
        super.pingStop(index: index, offset: offset)
        pingOff(index: index, noteShift: offset)
    }
}
let contents	=	skoogContents()
contents.setup()
contents.view.clipsToBounds = true
contents.view.translatesAutoresizingMaskIntoConstraints = false
contents.skoogSKscene.circle?.sceneDescription = String(format: "%@ %@ %@", contents.skoogSKscene.getBasicDescription(), contents.skoogSKscene.getNumberOfPings(), contents.skoogSKscene.getPingDescriptions())
contents.setBackgroundGradient(gradient: .gradient4)

PlaygroundPage.current.liveView = contents
//#-end-hidden-code
