//#-hidden-code
/*
 Copyright (C) 2017 Skoogmusic Ltd. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:** Learn how to use a threshold to adjust the responsiveness of your Skwitch.
 
 Press Run My Code.
 
 To connect, choose your Skwitch from the connection menu in the top right.
 
 By adjusting the threshold of Skwitch we can determine how hard a press must be in order to play a note.
 
 The dashed line represents a [threshold](glossary://threshold). In coding, thresholds are used to change how a program responds to new data. In our case, we use it to play a note.
 
 * callout(New Concept - Set Threshold):
 
 The graph on this page will display how hard you are pressing Skwitch. The dotted line represents the activation threshold.
 
 
 **Challenge:** Change the threshold values below to get a feel for how the threshold affects the response. Keep it between 0.0 and 1.0!
 
 */
//#-hidden-code

import UIKit
import PlaygroundSupport
import CoreAudioKit
import SpriteKit
import SceneKit

PlaygroundSupport.PlaygroundPage.current.needsIndefiniteExecution = true

public class skoogContents: PlaygroundViewController {
    //#-end-hidden-code
    //#-code-completion(everything, hide)
    //#-code-completion(identifier, show, marimba, candyBee, rhodes, Ocarina, elecpiano, .)
    //#-hidden-code
    public var aboveThresh : Bool = false
func setup() {
changeAlpha = false
growCircle  = false
playNotes = true

var thresholds : [Double]
var test : Double
    
if let storedValue = PlaygroundKeyValueStore.current["testFloat"],
    case .floatingPoint(let value) = storedValue {
    test = value
}
    
if let storedValues = PlaygroundKeyValueStore.current["thresholds"],
    case .array(let values) = storedValues {
//        thresholds = values
}

// Show the new Skoog Plotter
drawGraph = true

// Do you want to show labels onscreen?
showSqueezeLabel = true
    
//#-end-hidden-code
setThreshold(/*#-editable-code */0.2/*#-end-editable-code*/)

/*:
This function can be used to change your instrument sound, try a different one!
*/
setSound(/*#-editable-code */.marimba/*#-end-editable-code*/)
//#-hidden-code
}
    
    
public override func peak(_ side: Side,_ peak: Double) {
    if peak > threshold {
//        noteOn(sideIndex: side.index, velocity: peak)
    }
}
    
    public var noteIsOn : Bool = false

public override func continuous(_ value: Double) {
    super.continuous(value)
    if value > threshold && !noteIsOn {
        noteIsOn = true
        noteOn(sideIndex: 4, velocity: threshold)
    }
    else if value < threshold && noteIsOn {
        noteIsOn = false
    }
}

public override func release(_ side: Side) {
    super.release(side)
    //readyToPlay = true
}
}
let contents	=	skoogContents()
contents.setSound(.timpani)
contents.setup()
contents.view.clipsToBounds = true
contents.view.translatesAutoresizingMaskIntoConstraints = false
contents.rectangle.rectangle?.sceneDescription = NSLocalizedString("A graph showing squeeze data from your Skwitch is displayed.  As you squeeze the Skwitch the squeeze data moves higher or lower on the screen depending on how hard you press.  There is a horizontal line across the graph, indicating a threshold level that can be adjusted in your code.  A sound will be triggered when the squeeze data goes higher than the threshold.", comment: "live view 3 label")
contents.setBackgroundGradient(gradient: .gradient6)

PlaygroundPage.current.liveView = contents

var taskComplete : Bool = false

if  contents.red.threshold != 0.2 &&
    contents.blue.threshold != 0.2 &&
    contents.yellow.threshold != 0.2 &&
    contents.green.threshold != 0.2 &&
    contents.orange.threshold != 0.2
{
    taskComplete = true
}
else {
    taskComplete = false
}
if taskComplete {
    PlaygroundPage.current.assessmentStatus = .pass(message: NSLocalizedString("Great job!", comment: "Great job string"))
    
    let theArray = [PlaygroundValue.floatingPoint(contents.red.threshold),
                    PlaygroundValue.floatingPoint(contents.blue.threshold),
                    PlaygroundValue.floatingPoint(contents.yellow.threshold),
                    PlaygroundValue.floatingPoint(contents.green.threshold),
                    PlaygroundValue.floatingPoint(contents.orange.threshold)]
    PlaygroundKeyValueStore.current["thresholds"] = .array(theArray)
    PlaygroundKeyValueStore.current["testFloat"] = .floatingPoint(1.7)
}
else {
    PlaygroundPage.current.assessmentStatus = .fail(hints: [NSLocalizedString("For the best musical response, set the threshold as low as possible so that the Skwitch responds as quickly as possible.", comment: "Graph page hint 1 string"), NSLocalizedString("Try setting all threshold values less than 0.2 for red, blue, yellow, green, orange.", comment: "Graph page hint 2 string")], solution: nil)
}
//#-end-hidden-code
