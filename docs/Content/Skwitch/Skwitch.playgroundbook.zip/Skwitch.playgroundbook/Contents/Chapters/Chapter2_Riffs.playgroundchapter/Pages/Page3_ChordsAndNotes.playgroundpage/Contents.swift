//#-hidden-code
/*
 Copyright (C) 2016 Skoogmusic Ltd. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
*/

//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
**Goal:** Make Skwitch play chords and notes using a threshold.

 In an `else-if` statement we can make different things happen based on certain conditions.
 Here we use an `else-if` statement to make Skwitch respond differently depending on how hard we press.
 

**Challenge:** Finish the `else-if` statement to make Skwitch play a chord when it's over a threshold of 0.5.
 */
//#-hidden-code
import UIKit
import PlaygroundSupport
import CoreAudioKit
import SpriteKit
import SceneKit

PlaygroundSupport.PlaygroundPage.current.needsIndefiniteExecution = true
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, playNote(:), playChord(:))

public class skwitchContents: PlaygroundViewController {
    
    func setup() {
        //Override default values
        showRipples = true
        playNotes = false
        setKey(.D, type: .minor)
        setSound(.rhodes)
        //#-end-hidden-code
        
        
//set the threshold for Skwitch here
setThreshold(/*#-editable-code */0.5/*#-end-editable-code*/)
        //#-hidden-code
    }
    
    //#-end-hidden-code
func press(strength: Double) {
    if strength > threshold {
        //#-editable-code
        playChord(strength)
        //#-end-editable-code
    }
    else {
        //Try the 'playNote() function here and pass it 'strength'.
        //#-editable-code
        
        //#-end-editable-code
    }
//#-hidden-code
}
    
    func setKey(_ key: Key, type: ScaleType) {
        session.setKey(key, type: type)
    }
    func playNote(_ strength: Double) {
        noteOn(sideIndex:4, velocity: strength)
    }
    func playChord(_ strength: Double) {
        noteOn(sideIndex:4, velocity: strength, chord: true)
    }
    
    public override func peak(_ side: Side,_ peak: Double) {
        //on this page, call press before super, otherwise note settings will be out pf step
        press(strength: peak)
        super.peak(side, peak)
    }
}
let contents    =    skwitchContents()
contents.setup()
//contents.printSoundStyle()
contents.view.clipsToBounds = true
contents.view.translatesAutoresizingMaskIntoConstraints = false
contents.skoogSKscene.circle?.sceneDescription = String(format: "%@ %@ %@", NSLocalizedString("A black Skwitch Circle appears in the center of the Live View. This will glow orange when you press the Skwitch, and a matching colored ripple will expand and fade across the screen.", comment: "live view 4 label"), contents.skoogSKscene.getNumberOfPings(), contents.skoogSKscene.getPingDescriptions())
contents.setBackgroundGradient(gradient: .gradient1)

PlaygroundPage.current.liveView = contents
