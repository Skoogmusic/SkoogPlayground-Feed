//#-hidden-code
/*
 Copyright (C) 2016 Skoogmusic Ltd. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
Try changing the notes that are in the `setRiff()` function.

We've added a few Pings to the Live View for you to play with. You'll meet Pings again later.

Press the Skwitch to play all the notes in the riff. Notice how the circle changes color and causes a ripple when you play?
*/
//#-hidden-code
import UIKit
import PlaygroundSupport
import CoreAudioKit
import SpriteKit
PlaygroundSupport.PlaygroundPage.current.needsIndefiniteExecution = true
public class skoogContents: PlaygroundViewController {
    public var inst: SoundStyle = .marimba
    func setup() {
        growCircle = true
        changeAlpha = true
        showRipples = true
        showPressLabels = false
        showSqueezeLabel = false
        changeColor = true
        playNotes = true
        setRipple(speed: 1.5)
        setSound(.marimba)
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, ., setKey(:type:), addPing(:shift:), addPing(:index:), noteShift, fixedNote)
//#-end-hidden-code
//To create your riff add a comma separated list of numbers from 0 to 6 representing the notes in the current scale.
setRiff([/*#-editable-code*/0, 1, 2, 3, 4, 5, 6/*#-end-editable-code*/])
        
/*:
Try setting the Key with the `setKey()` function.
*/
setKey(/*#-editable-code*/.D/*#-end-editable-code*/, type:/*#-editable-code*/.major/*#-end-editable-code*/)
        
/*:
Here's some space to type your own code. Try changing your sound!
*/
//#-editable-code
//#-end-editable-code
        
//#-hidden-code
addPing(.noteShift, shift: 5, distance: 1.0)
addPing(.fixedNote, index: 5, distance: 2.5)
addPing(.chord, index: 2, distance: 3)
        

    }
    
    func setKey(_ key: Key, type: ScaleType) {
        session.setKey(key, type: type)
    }
}
let contents    =    skoogContents()
contents.setup()
contents.view.clipsToBounds = true
contents.view.translatesAutoresizingMaskIntoConstraints = false
contents.skoogSKscene.circle?.sceneDescription = String(format: "%@ %@ %@", contents.skoogSKscene.getBasicDescription(), contents.skoogSKscene.getNumberOfPings(), contents.skoogSKscene.getPingDescriptions())
contents.setBackgroundGradient(gradient: .gradient4)

PlaygroundPage.current.liveView = contents
//#-end-hidden-code
