//#-hidden-code
/*
 Copyright (C) 2018 Skoogmusic Ltd. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
*/
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:** Learn how to add a Chord Ping.
 
 We've seen note Pings, now lets look at a chord ping.
 
 addPing(.chord, index: 0)
 
 A chord ping can either be a fixed chord or a chord shift. There are two different functions for adding these.
 
 * callout(Ping Types):
 * addPing(.chord, index: Int)
 * addPing(.chord, shift: Int)
 
*/
//#-hidden-code
import UIKit
import PlaygroundSupport
import CoreAudioKit
import SpriteKit

PlaygroundSupport.PlaygroundPage.current.needsIndefiniteExecution = true
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, ., noteShift, fixedNote, setKey(:type:), addPing(:shift:), addPing(:index:))
public class skwitchContents: PlaygroundViewController {
    func setup() {
        //Override default values
        showRipples = true
        setKey(.D, type: .minor)
        setSound(.rhodes)
        //#-end-hidden-code
addPing(/*#-editable-code */.chord/*#-end-editable-code*/, index:/*#-editable-code */0/*#-end-editable-code*/)
//Add a chord shift Ping here
//#-editable-code

//#-end-editable-code
//#-hidden-code
    }
    func setKey(_ key: Key, type: ScaleType) {
        session.setKey(key, type: type)
    }
}
let contents    =    skwitchContents()
contents.setup()
//contents.printSoundStyle()
contents.view.clipsToBounds = true
contents.view.translatesAutoresizingMaskIntoConstraints = false
contents.skoogSKscene.circle?.sceneDescription = String(format: "%@ %@ %@", NSLocalizedString("A black Skwitch Circle appears in the center of the Live View. This will become orange when you press Skwitch, and a matching colored ripple will expand and fade across the screen.", comment: "live view 4 label"), contents.skoogSKscene.getNumberOfPings(), contents.skoogSKscene.getPingDescriptions())
contents.setBackgroundGradient(gradient: .gradient1)

PlaygroundPage.current.liveView = contents
//#-end-hidden-code
