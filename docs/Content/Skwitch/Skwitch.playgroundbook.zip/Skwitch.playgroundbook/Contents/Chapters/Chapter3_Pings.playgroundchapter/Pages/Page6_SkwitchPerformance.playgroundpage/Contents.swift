//#-hidden-code
/*
 Copyright (C) 2016 Skoogmusic Ltd. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 
 **Goal:** Set up multiple Pings. It’s time for your performance!
 
 This is your blank canvas: choose your key and instrument, set up your scene, and try adding a few extra Pings to your code too. Refer back to previous pages if you have to, and have fun!
 
 * callout(To add a Ping):
 `addPing()`
 
 By default Pings are arranged in a spiral, creating a cascade of notes. They can also be arranged by distance from the center (measured as the number of Ping diameters), and by angle (in degrees clockwise from 12 o'clock).
 
 **Exercise 1:** Create noteshift Pings at a distance of 1.0, with shifts of 5, 10, and 14.\
 **Exercise 2:** To play a simple note sequence, add three note Pings at a fixed angle at distances of 0.5, 1.5, and 2.5.
 * callout(Tip):
 Pings are best enjoyed in fullscreen! Touch the middle of the screen till the slider appears then drag left.
 */
//#-hidden-code

import UIKit
import PlaygroundSupport
import CoreAudioKit
import SpriteKit
import SceneKit

PlaygroundSupport.PlaygroundPage.current.needsIndefiniteExecution = true

public class skoogContents: PlaygroundViewController {
    public var inst: SoundStyle = .marimba
    
    func setup() {
        
        //#-code-completion(everything, hide)
        //#-code-completion(identifier, show, ripple(color:size:), pulse(color:size:))
        //#-code-completion(identifier, show, addPing(_:noteShift:distance:angle:))
        
        //#-code-completion(identifier, show, setNotes, setRipple, speed, noteShift, distance, angle, side, color, size, strength, value, rawValue, addPing, setSound(_:), Instrument.type, ., name, true, false)
        //#-code-completion(identifier, show, acid, candyBee, fmModulator, sineWave, solarWind, gamelan, strat, rhodes, jharp, marimba, ocarina, minimogo, elecpiano, nylonguitar, vibraphone, afromallet, timpani)
        //#-code-completion(literal, show, boolean, color)
        //#-code-completion(keyword, show, for, if, let, var, while)
        //#-end-hidden-code
//#-editable-code tap to edit
setSound(.marimba)
setKey(.C, type: .major)
        
setThreshold(0.2)
        
setRiff([0, 1, 2, 3, 4, 5, 6])

addPing(.noteShift, shift: 5, distance: 1.0)
addPing(.fixedNote, index: 5, distance: 2.5)
addPing(.chord, index: 2, distance: 3)
        
//#-hidden-code
    }
    func setKey(_ key: Key, type: ScaleType) {
        session.setKey(key, type: type)
    }
    
    
    func press(side: Side, strength: Double) {
        var threshold = /*#-editable-code */0.65/*#-end-editable-code*/
        if strength > threshold {

        }
        else {

        }
    }
    public override func peak(_ side: Side,_ peak: Double) {
        //on this page, call press before super, otherwise note settings will be out pf step
        press(side: side, strength: peak)
        super.peak(side, peak)
    }
    
}
let contents    =    skoogContents()
contents.setup()
contents.view.clipsToBounds = true
contents.view.translatesAutoresizingMaskIntoConstraints = false
contents.skoogSKscene.circle?.sceneDescription = String(format: "%@ %@ %@", contents.skoogSKscene.getBasicDescription(), contents.skoogSKscene.getNumberOfPings(), contents.skoogSKscene.getPingDescriptions())
contents.setBackgroundGradient(gradient: .gradient4)

PlaygroundPage.current.liveView = contents
//#-end-hidden-code
