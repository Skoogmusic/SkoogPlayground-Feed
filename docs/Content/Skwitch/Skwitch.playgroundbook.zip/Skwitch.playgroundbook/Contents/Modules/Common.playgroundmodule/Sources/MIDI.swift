
//
//  Instrument.swift
//
//  Created by David Skulina on 27/09/2016.
//  Copyright © 2017 Skoogmusic Ltd. All rights reserved.
//

import Foundation
import AudioToolbox
import CoreAudio
import UIKit

public typealias MidiNoteNumber = Int
public typealias MidiChannel = Int
public typealias MidiVelocity = Int


public enum MIDIStatus: UInt8 {
    case noteOn
    case noteOff
    case channelPressure
    case aftertouch
    case pitchBend
    case pitchRange
    case expression
    case modulation
    case volume
    case pan
	case controlChange
    case timbre
    var value: UInt8 {
        switch self {
        case .noteOn:
            return 0x90
        case .noteOff:
            return 0x80
        case .channelPressure:  // Channel Pressure (After-touch)
            return 0xD0
        case .aftertouch:       // Polyphonic Key Pressure (Aftertouch)
            return 0xA0
        case .pitchBend:
            return 0xE0
        case .pitchRange, .expression, .modulation, .volume, .pan, .controlChange, .timbre:
            return 0xB0
        }
    }
}

let CABTMIDINotificationKey = "com.skoogmusic.CABTMIDINotificationKey"

public struct CABTMIDIStatus {
    enum ConnectionStatus: Int {
        case connectedAsPeripheral = 0
        case connectedToPeripheral
        case disconnected
        func string() -> String {
            switch(self) {
            case .connectedAsPeripheral:
                return NSLocalizedString("Connected", comment: "Connected text")
            case .connectedToPeripheral:
                return NSLocalizedString("Connected", comment: "Connected text")
            case .disconnected:
                return NSLocalizedString("Disconnected", comment: "Disconnected text")
            }
        }
    }
    var connected : ConnectionStatus = .disconnected
    var skwitchName : String = "Skwitch"
    var skwitchIdiom : UIUserInterfaceIdiom = .pad
    var skwitchUniqueID : Int = 0
    var BLEMIDIDeviceName : String = ""
    var BLEMIDIDeviceUUID : String  = ""
    var BLEMIDIDeviceModel : String  = ""
    var BLEMIDIDeviceIdiom : UIUserInterfaceIdiom = .pad
}

public struct mpeOptionStatus : Loopable {
    var active: Bool = false
    var noteOn: Bool = true
    var channelPressure: Bool = true
    var modulation: Bool = false
    var pitchBend: Bool = false
    var timbre: Bool = false
    var zoneMaster: Int = 0
}

public enum MPEchannelMode: Int {
	case mpeChannelModeLow = 0
	case mpeChannelModeHigh
}

public protocol SkwitchMIDIDelegate: class {
    func peak(_ side: Side,_ peak: Double)
    func continuous(_ value: Double)
    func release(_ side: Side)
    var sides : [Side] {get set}
}

public let SkwitchMIDIInstance = SkwitchMIDI()

public class SkwitchMIDI : NSObject {
    public weak var delegate : SkwitchMIDIDelegate?
    var noteOnArray     = [[UInt32]]() // initialise blank array
    var isPlaying : Bool
    var MPEstatus : Bool = false
    var MPEchannelMode : MPEchannelMode = .mpeChannelModeLow
    var options = mpeOptionStatus()
    
    public var midiInputPortConnectionMade = false
    
    var status = OSStatus(noErr)
    var midiClient = MIDIClientRef()
    var inputPort = MIDIPortRef()
    var outputPort = MIDIPortRef()
    var virtualSourceEndpointRef = MIDIEndpointRef()
    var isCABTConnectedToPeripheral = false
    
    @objc public class var sharedInstance:SkwitchMIDI {
        return SkwitchMIDIInstance
    }
    
    /// Initialize.
    public override init() {
        self.isPlaying = false
        super.init()
        status = MIDIClientCreateWithBlock("SkoogAccessMIDIClient" as CFString, &midiClient, MIDINotify)
        if status != noErr {
            print("Error creating midi client : \(status)")
        }
        else {
            print("Created midi client : \(status)")
        }
        status = MIDISourceCreate(midiClient, "Skwitch" as CFString, &virtualSourceEndpointRef)
        status = MIDIOutputPortCreate(midiClient, "com.skoogmusic.OutputPort" as CFString, &outputPort)
    }
    

    func MIDINotify(_ midiNotification: UnsafePointer<MIDINotification>) {
        let notification = midiNotification.pointee
        switch (notification.messageID) {
        case .msgSetupChanged:
            print("Setup changed!")
            searchForSkwitch()
        case .msgObjectAdded:
            print("Object added!")
        case .msgObjectRemoved:
            print("Object removed!")
        case .msgPropertyChanged:
            print("Property changed!")
        case .msgThruConnectionsChanged:
            print("Thru connections changed!")
        case .msgSerialPortOwnerChanged:
            print("Serial port owner changed!")
        case .msgIOError:
            print("IO Error!")
        }
    }
    
    public func searchForSkwitch() {
        let numberOfDevices = MIDIGetNumberOfDevices()
        let numberOfSources = MIDIGetNumberOfSources()
        let numberOfDestinations = MIDIGetNumberOfDestinations()
        let numberOfExternal = MIDIGetNumberOfExternalDevices()
        var connection = CABTMIDIStatus()
        print("SEARCH FOR SKWITCH CALLED - numberOfDevices: ",numberOfDevices,"numberOfSources",numberOfSources, "numberOfDestinations",numberOfDestinations,"numberOfExternal",numberOfExternal)

        var skwitchDevice : NSDictionary? = nil
        var onlineDevices : [NSDictionary?] = [nil]
        for count:Int in 0 ..< numberOfDevices {
            let midiDevice = MIDIGetDevice(count)
            var unmanagedProperties: Unmanaged<CFPropertyList>?
            MIDIObjectGetProperties(midiDevice, &unmanagedProperties, false)
            
            if let midiProperties: CFPropertyList = unmanagedProperties?.takeUnretainedValue() {
                let midiDictionary = midiProperties as! NSDictionary
                let deviceName = midiDictionary.object(forKey: "name") as! String
                if midiDictionary.object(forKey: "offline") as! Int == 0 {
                    if deviceName.starts(with: "Skwitch") {
                        skwitchDevice = midiDictionary
                        if onlineDevices[0] == nil {
                            onlineDevices[0] = skwitchDevice
                        }
                        else {
                            onlineDevices.append(skwitchDevice)
                        }
                    }
                    else {
                        if onlineDevices[0] == nil {
                            onlineDevices[0] = midiDictionary
                        }
                        else {
                            onlineDevices.append(midiDictionary)
                        }
                    }
                }
            }
        }
        if let skwitch = skwitchDevice {
            print("Found a Skwitch! \(skwitch)")
            connection.skwitchName = skwitch.object(forKey: "name") as! String
            connection.skwitchUniqueID = skwitch.object(forKey: "uniqueID") as! Int
            connection.skwitchIdiom = UIDevice.current.userInterfaceIdiom
            
            if onlineDevices[0] != nil {
                for (_, device) in onlineDevices.enumerated() {
                    let deviceUUID = device?.object(forKey: "BLE MIDI Device UUID")
                    let deviceName = device?.object(forKey: "name") as! String
                    let offlineStatus = device?.object(forKey: "offline") as! Int
                    if deviceUUID != nil {
                        if let skwitchUUID = skwitch.object(forKey: "Last Connected Central UUID") {
                            if skwitchUUID as! String == deviceUUID as! String {
                                connection.BLEMIDIDeviceName = deviceName
                                connection.BLEMIDIDeviceModel = device?.object(forKey: "model") as! String
                                connection.BLEMIDIDeviceUUID = deviceUUID as! String
                                connection.BLEMIDIDeviceIdiom = (device?.object(forKey: "model") as! String).starts(with: "iPad") ? .pad : .phone
                               
                                if connection.BLEMIDIDeviceName.starts(with: "Skwitch") {
                                    print(">>> we connected to Skwitch >> do something")
                                    connection.connected = .connectedToPeripheral
                                }
                                else {
                                    connection.connected = .connectedAsPeripheral
                                }
                                print(connection.skwitchName, "is connected to", connection.BLEMIDIDeviceName)
                                break
                            }
                        }
                        else if deviceName.starts(with: "Skwitch") {
                            //print(">>> we connected to Skwitch >> do something")
                            connection.BLEMIDIDeviceName = deviceName
                            connection.BLEMIDIDeviceModel = device?.object(forKey: "model") as! String
                            connection.BLEMIDIDeviceUUID = deviceUUID as! String
                            connection.BLEMIDIDeviceIdiom = (device?.object(forKey: "model") as! String).starts(with: "iPad") ? .pad : .phone
                            connection.connected = .connectedToPeripheral
                            if !midiInputPortConnectionMade {
                                start()
                            }
                        }
                    }
                }
//                if  connection.connected == .disconnected {
//                    print("CABT", connection.skwitchName, "disconnected")
//                    midiInputPortConnectionMade = false
//                }
            }
        }
        Settings.cabtMIDI = connection
    }
    
    func MyMIDIReadBlock(packetList: UnsafePointer<MIDIPacketList>, srcConnRefCon: UnsafeMutableRawPointer?) -> Swift.Void {
        let packets = packetList.pointee
        
        let packet:MIDIPacket = packets.packet
        
        var ap = UnsafeMutablePointer<MIDIPacket>.allocate(capacity:1)
        ap.initialize(to: packet)
//        print("midireadblock \(ap)")
        for _ in 0 ..< packets.numPackets {
            let p = ap.pointee
            print("midireadblock \(p)")
            handle(p)
            ap = MIDIPacketNext(ap)
        }
        
    }
    
    var midiState : MIDIStatus = MIDIStatus.noteOff
    
    func handle(_ packet: MIDIPacket) {
        var p = packet.asArray()
        
        var i : Int = 0

        while i < packet.length {

            let data =  p[Int(i)] & 0xF0 //without channel
            let channel  = p[Int(i)] & 0x0F //channel
            
            print("data & 0xF0", data & 0xF0, i)

            switch data {
            case MIDIStatus.noteOn.value:
                //            print("NoteOn")
                if midiState == MIDIStatus.noteOff {
                    let vel = p[i + 2]
                    let peak : Double = Double(vel) / 127.0
                    midiState = MIDIStatus.noteOn
                    delegate?.peak((delegate?.sides[4])!, peak)
                }
                
            case MIDIStatus.noteOff.value:
                //            print("NoteOff")
                delegate?.release((delegate?.sides[4])!)
                midiState = MIDIStatus.noteOff
                
            case MIDIStatus.pitchBend.value:
                let pitchBend = p[i + 1]
                print("We have a pitch bend message: \(pitchBend)")
                break
            case  MIDIStatus.channelPressure.value:
                let channelPressure = p[i + 1]
                let value : Double = Double(channelPressure) / 127.0
                delegate?.continuous(value)
                print("We have a channelPressure message: \(channelPressure)")
                break
            case MIDIStatus.timbre.value:
                let timbre = p[i + 1]
                print("We have a timbre message: \(timbre)")
                
                break
            default:
                print("Different message at the start of packet! \(packet.data.0)") 
                break
            }
            
            if data == MIDIStatus.channelPressure.value {
                i += 2
            }
            else {
                i += 3
            }
        }
    }

/////////////////////////////////////////////////////////////////////////
// MARK: - MIDI Setup methods
/////////////////////////////////////////////////////////////////////////
    
    public func MIDIevent(status: MIDIStatus, data1: Int, data2: Int, channel: MidiChannel) {
        //print("message status \(status)")
        var packet:MIDIPacket = MIDIPacket();
        packet.timeStamp = 0
        packet.length = 3
        packet.data.0 = status.value | MPEchannel(fromChannel:channel)
        packet.data.1 = UInt8(data1)
        packet.data.2 = UInt8(data2 >= 0 ? data2 : 0)
        var packetList : MIDIPacketList = MIDIPacketList(numPackets: 1, packet: packet);
        
        let destinationCount = MIDIGetNumberOfDestinations()
        for destinationIndex in 0 ..< destinationCount {
            let dest:MIDIEndpointRef = MIDIGetDestination(destinationIndex)
            let status = MIDISend(outputPort, dest, &packetList)
            if status != noErr {
                print("bad status \(status) sending msg")
            }
        }
 
        let status = MIDIReceived(virtualSourceEndpointRef, &packetList)
        if status != noErr {
            print("bad status \(status) receiving msg")
        }
    }

    
    
/////////////////////////////////////////////////////////////////////////
// MARK: - MIDI methods
/////////////////////////////////////////////////////////////////////////
    
    public func start() {
        
        var status = OSStatus(noErr)
        
        if status == OSStatus(noErr) {
            status = MIDIInputPortCreateWithBlock(midiClient, "com.skoogmusic.SkwitchPlaygroundPort" as CFString, &inputPort, MyMIDIReadBlock)
            print("STarting INput \(status)")
            if status == OSStatus(noErr) {
                print("created input port")
            } else {
                print("error creating input port : \(status)")
            }
        }
        connectSourcesToInputPort()
    }
    
    func connectSourcesToInputPort() {
        var status = OSStatus(noErr)
        let sourceCount = MIDIGetNumberOfSources()
        for srcIndex in 0 ..< sourceCount {
//        let srcIndex = 2
            let midiEndPoint = MIDIGetSource(srcIndex)
            // Use below to get the name of a source
            var str : Unmanaged<CFString>?
            MIDIObjectGetStringProperty(midiEndPoint, kMIDIPropertyDisplayName, &str)
            
            
            if let name = str?.takeRetainedValue() as? String, name.starts(with: "Skwitch"){
            
                
                status = MIDIPortConnectSource(inputPort,
                                               midiEndPoint,
                                               nil)
                // Use below to get the name of a source
                //            var str : Unmanaged<CFString>?
                //            MIDIObjectGetStringProperty(midiEndPoint, kMIDIPropertyDisplayName, &str)
                if status == OSStatus(noErr) {
                    print("Source count \(sourceCount) ,connected to \(srcIndex)")
                    midiInputPortConnectionMade = true
                }
                else {
                    print("oh crap!")
                }
            }
        }
    }
    
//    public func noteOn(noteNum:MidiNoteNumber, velocity: MidiVelocity, channel: MidiChannel)    {
//        MIDIevent(status: .noteOn, data1: noteNum, data2: velocity, channel: channel)
//    }
//
//
//    public func noteOff(noteNum:MidiNoteNumber, channel: MidiChannel)    {
//        MIDIevent(status: .noteOff, data1: noteNum, data2: 0, channel: channel)
//    }

    public func noteOn(noteNum: [MidiNoteNumber], velocity: MidiVelocity, channel: MidiChannel)    {
//        for note in noteNum {
//            MIDIevent(status: .noteOn, data1: note, data2: velocity, channel: channel)
//        }
    }
    
    public func noteOff(noteNum: [MidiNoteNumber], channel: MidiChannel)    {
//        for note in noteNum {
//            MIDIevent(status: .noteOff, data1: note, data2: 0, channel: channel)
//        }
    }
    
    public func channelPressure(pressure:Int, channel: MidiChannel)    {
        MIDIevent(status: .channelPressure, data1: pressure, data2: 0, channel: channel)
    }
    
    public func afterTouch(note: MidiNoteNumber, touch:Int, channel: MidiChannel)    {
        if !MPEstatus { //Do not send polyphonic aftertouch if MPE mode is active
            MIDIevent(status: .aftertouch, data1: note, data2: touch, channel: channel)
        }
        else {
            MIDIevent(status: .channelPressure, data1: touch, data2: 0, channel: channel)
        }
    }
    
    public func pitchBend(bend:Int, channel: MidiChannel) {
        let lsb = UInt8(bend & 0xFF)
        let msb = UInt8((bend >> 7) & 0xFF)
        MIDIevent(status: .pitchBend, data1: Int(lsb), data2: Int(msb), channel: channel)
    }
    
    public func pitchRange(range:Int, channel: MidiChannel) {
        MIDIevent(status: .controlChange, data1: 100, data2: 0, channel: channel) //RPN LSB
        MIDIevent(status: .controlChange, data1: 101, data2: 0, channel: channel) //RPN MSB
        MIDIevent(status: .pitchRange, data1: 6, data2: range, channel: channel)
        MIDIevent(status: .pitchRange, data1: 38, data2: 0, channel: channel)
    }
    
    public func volume(value:Int, channel: MidiChannel)    {
        MIDIevent(status: .volume, data1: 7, data2: value, channel: channel)
    }
    
    public func modulate(value:Int, channel: MidiChannel)    {
        MIDIevent(status: .modulation, data1: 1, data2: value, channel: channel)
    }
    
    public func expression(value:Int, channel: MidiChannel)    {
        MIDIevent(status: .expression, data1: 11, data2: value, channel: channel)
    }
    
    public func pan(value:Int, channel: MidiChannel)    {
        MIDIevent(status: .pan, data1: 10, data2: value, channel: channel)
    }
    
    public func panic() {
        for channel in 1...16 {
            MIDIevent(status: .controlChange, data1: 64, data2: 0, channel: channel)  //sustain to zero
            MIDIevent(status: .controlChange, data1: 120, data2: 0, channel: channel) //All sound off
            MIDIevent(status: .controlChange, data1: 123, data2: 0, channel: channel) //All notes Off
            for note in 0...127 {
                MIDIevent(status: .noteOff, data1: note, data2: 0, channel: channel)
            }
        }
    }
    
    /////////////////////////////////////////////////////////////////////////
    // MARK: - MPE methods
    /////////////////////////////////////////////////////////////////////////
    
    // MPE Specification Revision 1.25a 15 Dec 2015
    
    // Activating MPE mode
    // This area of the protocol is concerned only with activating MPE mode. The method of deactivation, and the default behaviour of an instrument when MPE mode is deactivated, is left to the manufacturer.
    // It is expected that the activation and configuration messages will usually be conveyed by a DAW or a control application to a controller or synthesizer to set it up for a specific situation. RPN messages received by a device should not be retransmitted automatically to any listening devices, as this can cause loopback problems. It is up to the user to ensure that their setup is configured properly.
    // MPE works over MIDI Mode 3 (Omni Off, Poly On), which is the default mode of most synthesizers. It is configured exclusively using RPN 6 †.
    
    // Power-on behaviour
    // It is expected that most compatible devices will, when powered on for the first time, send or accommodate note data on Channels 2-16, with Channel 1 configured as the zone master channel. This would provide a good initial user experience in a monotimbral mode and, in the case of accidental misconfiguration, would be the least ‘wrong’ thing to do.
    // Setting up zones
    // Sending RPN 6 † on any channel defines a new zone in accordance with six rules:
    // 1) Note channel allocation begins on the channel on which the RPN is received, and occupies a number of channels specified by the data entry CC message.
    // 2) The zone master channel for the new zone is one lower than the channel on which the RPN is received.
    // 3) If part of the new zone overwrites either the zone master channel or the lowest note channel of an existing zone, the older zone is deleted entirely.
    // 4) Otherwise, if any part of the new zone overwrites a part of an existing zone, the older zone will be shortened.
    // 5) Defining the number of note channels as 16, on any channel, erases all currently-defined zones. When an instrument is played when all zones have been deleted, preferred behaviour is for the device to work in a single-channel compatibility mode, with MPE effectively turned off. Preferred behaviour for synthesizers is to switch to omni mode.
    // 6) This protocol does not wrap the channel space. The RPN is never sent or actioned on Channel 1, because this would leave nowhere to place the zone master channel. For the same reason, zones should not be defined that extend beyond Channel 16.
    // How numerous zones map to a performer’s controller – whether split across a range of keys or otherwise assigned – is left to the manufacturer.

    
    public func MPEmode(stateActive: Bool) {
        
        var channel : Int
        switch (MPEchannelMode) {
        case .mpeChannelModeLow:
            channel = 1
        case .mpeChannelModeHigh:
            channel = 16
        }
        
        if stateActive{
            MIDIevent(status: .controlChange, data1: 101, data2: 0, channel: channel)   //RPN MSB
            MIDIevent(status: .controlChange, data1: 100, data2: 6, channel: channel)   //RPN LSB
            MIDIevent(status: .controlChange, data1: 6, data2: 5, channel: channel)     //Data Entry (MSB)
            MIDIevent(status: .controlChange, data1: 38, data2: 0, channel: channel)    //Data Entry (LSB)
            MIDIevent(status: .controlChange, data1: 101, data2: 127, channel: channel) //RPN MSB
            MIDIevent(status: .controlChange, data1: 100, data2: 127, channel: channel) //RPN LSB

//            MIDIevent(status: .controlChange, data1: 100, data2: 127, channel: channel)
//            MIDIevent(status: .controlChange, data1: 101, data2: 127, channel: channel)
        }
        else{
            MIDIevent(status: .controlChange, data1: 127, data2: 0, channel: channel)
        }
        MPEstatus = stateActive
    }
    
    
    public func timbre(value: Int = 0, channel: MidiChannel = 0) {
        MIDIevent(status: .timbre, data1: 74, data2: value, channel: channel)
    }
    

    public func MPEchannel(fromChannel: MidiChannel) -> UInt8 {
        guard MPEstatus else{
            return UInt8(fromChannel) // pass straight through if not in MPE mode
        }
        
        switch (MPEchannelMode) {
            case .mpeChannelModeLow:
                return UInt8(fromChannel + 2) //channels start at 2 and increment (side index starts at 0)
            case .mpeChannelModeHigh:
                return UInt8(15 - fromChannel) //channels start at 15 and decrement (side index starts at 0)
        }
    }
    
    
    
}

protocol Loopable {
    func allProperties() throws -> [String: Any]
}

extension Loopable {
    func allProperties() throws -> [String: Any] {
        
        var result: [String: Any] = [:]
        
        let mirror = Mirror(reflecting: self)
        
        // Optional check to make sure we're iterating over a struct or class
        guard let style = mirror.displayStyle, style == .struct || style == .class else {
            throw NSError()
        }
        
        for (property, value) in mirror.children {
            guard let property = property else {
                continue
            }
            
            result[property] = value
        }
        
        return result
    }
}
