//
//  SkwitchSession.swift
//  Skwitch
//
//  Created by James Callaghan on 29/03/2018.
//  Copyright © 2018 Skoogmusic Ltd. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation

enum DeviceType : Int {
    case iPhone5s = 0
    case iPhone6
    case iPhone6Plus
    case iPhone6s
    case iPhone6sPlus
    case iPhone7
    case iPhone7Plus
    case iPhoneSE
    case iPhone8
    case iPhone8Plus
    case iPhoneX
    case iPad
    case invalid
    //add all iphones
}

public struct DeviceState {
    var isStationary = false
}

public struct DeviceSettings {
    var device : DeviceType = .iPhoneX
    var screen = Screen()
    var state = DeviceState()
    var magnetometer = Magnetometer()
    var sideLength : CGFloat = 200
    var radius : CGFloat = 115
    var overlap = CGSize(width: 0, height: 0)                       // Size of area to set aside for Skwitch screen overlap
    var screenOverlap = CGRect(x: 0, y:0, width: 0, height: 0)      // Location/Area to set aside for Skwitch screen overlap
    var skwitchWidthConstraint : CGFloat = 0
    var position = CGPoint(x: 0, y:0)                               // centre position for skwitch (square, rounded rect)
    var segPosition = CGPoint(x: 0, y:0)                            // centre position for segment control UI
    var activeRange : [Double] = [70,85,100]
    var menuAnchor = CGPoint(x:0,y:0)
//    var audioMode : AudioMode = .midi
    var speechRate : Float = 0.5
    var speechPitch : Float = 1
    var speechVoice : String = AVSpeechSynthesisVoiceIdentifierAlex
    var sourceMenuTouchEnabled : Bool = true
    var menuLockisShown = false
    var annoucementsActive = true
    var cabtMIDI : CABTMIDIStatus = CABTMIDIStatus(){
        didSet {
            if cabtMIDI.connected != oldValue.connected {
                //print("cabtMIDI status has changed to:", cabtMIDI.connected)
                NotificationCenter.default.post(name: Notification.Name(rawValue: CABTMIDINotificationKey),
                                                object: nil,
                                                userInfo: ["connected": cabtMIDI.connected == .connectedAsPeripheral, "status" : cabtMIDI])
            }
        }
    }

    
    public init() {
        device = getDevice()
        switch (device){
        case .iPhone5s: //Top Height: 17.01mm
            print("IPHONE 5S")
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: -25)
            position = CGPoint(x: 0, y:  sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension - 150)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhone6: //Top Height: 17.49mm
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: 20)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhone6Plus: //Top Height: 18.71mm
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: 20)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhone6s: //Top Height: 17.12mm
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: 20)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhone6sPlus: //Top Height: 18.34mm
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: 20)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhone7: //Top Height: 17.12mm
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: 20)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhone7Plus: //Top Height: 18.34mm
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: 20)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhoneSE: //Top Height: 17.01mm NEED TO CHECK
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: 20)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhone8:
            /* Iphone 8 Dimensional Info TBC
             * magnetometer Y distance from bottom edge of phone: 119.92mm TBC
             * magnetometer X distance 51.43mm from right hand edge
             * screen active area height 104.05mm
             * 17.19mm from top to active area
             * total phone height 138.97mm
             * => Magenetometer Y distance from top of screen: 90.56 - 4.99 = 85.57
             * => % of screen Height from top = 85.57/135.75 = 63%
             * The overlap
             */
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: 20)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
        case .iPhone8Plus:
            /* Iphone 8 Plus Dimensional Info TBC
             * magnetometer Y distance from bottom edge of phone: 119.92mm TBC
             * magnetometer X distance 51.43mm from right hand edge
             * screen active area height 104.05mm
             * 18.42mm from top to active area
             * total phone height 138.97mm
             * => Magenetometer Y distance from top of screen: 90.56 - 4.99 = 85.57
             * => % of screen Height from top = 85.57/135.75 = 63%
             * The overlap
             */
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: sideLength, height: -25)
            position = CGPoint(x: magnetometer.position.x, y: magnetometer.position.y + 0.5 * sideLength - overlap.height)
            position = CGPoint(x: 0, y:  sideLength - overlap.height)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension - 250)
            segPosition = CGPoint(x: 0, y: -125)
            activeRange = [70,85,100]
            
        case .iPhoneX:
            /* IphoneX Dimensional Info
             * magnetometer Y distance from top edge of phone: 90.56mm
             * screen (active area cutout) Y distance from top edge of phone: 4.99mm
             * screen active area height 135.75mm
             * => Magenetometer Y distance from top of screen: 90.56 - 4.99 = 85.57
             * => % of screen Height from top = 85.57/135.75 = 63%
             */
            
            magnetometer.position = CGPoint(x: -0.5 * screen.smallestDimension, y: -105)
            sideLength = 564
            overlap = CGSize(width: 75, height: sideLength)
            position = CGPoint(x: magnetometer.position.x + overlap.width - 0.5 * sideLength, y: magnetometer.position.y)
            screenOverlap = CGRect(x: magnetometer.position.x, y: magnetometer.position.y - 0.5 * overlap.height , width: overlap.width, height: overlap.height)
            skwitchWidthConstraint = screenOverlap.width + 24
            menuAnchor = CGPoint(x:position.x + 0.5 * sideLength - radius, y: position.y + 0.5 * sideLength - radius + 250)
            segPosition = CGPoint(x: 0.5 * overlap.width - 1, y: magnetometer.position.y)
            activeRange = [70,60,30]
            
        case .iPad:
            magnetometer.position = CGPoint(x: 0, y: 0.5 * screen.largestDimension)//TBC
            sideLength = 564
            overlap = CGSize(width: 75, height: sideLength)
            position = CGPoint(x: magnetometer.position.x + overlap.width - 0.5 * sideLength,   y: magnetometer.position.y)
            screenOverlap = CGRect(x: 0, y: position.y, width: overlap.width, height: overlap.height)
            menuAnchor = CGPoint(x:0 , y: 0.62 * screen.largestDimension + 250)
            activeRange = [2000,2000,2000]
        default:
            print("Device Not compat")
        }
        
        if let rate = UserDefaults.standard.value(forKey: "SpeechRate") as? Float {
            speechRate  = rate
        }
        if let pitch = UserDefaults.standard.value(forKey: "SpeechPitch") as? Float {
            speechPitch  = pitch
        }
        if let voice = UserDefaults.standard.value(forKey: "SelectedVoice") as? String {
            speechVoice = voice
        }
    }
    //TODO: detect iphone type
    func getDevice() -> DeviceType {
        var result : DeviceType = .iPhoneX
        if UIDevice.current.userInterfaceIdiom == .phone {
            if UIDevice.current.modelName == .iPhoneX {
                print ("I'm an iPhone X")
                result = .iPhoneX
            }
            else if UIDevice.current.modelName == .iPhone5s {
                print ("I'm an iPhone 5")
                result = .iPhone5s
            }
            else if result == .iPhone8Plus{
                print ("I'm an iPhone")
                result = .iPhone8Plus
            }
            else {
                result = .invalid
            }
            
        }
        else if UIDevice.current.userInterfaceIdiom == .pad {
            print ("I'm an iPad")
            result = .iPad
        }
        return result
    }
}


struct Magnetometer {
    var position : CGPoint = CGPoint(x: 0, y: 0) //relativeToCentre
    var reportsCalibrationState = true
    enum ProximityStatus : Int {
        case low = 0
        case medium
        case high
    }
    var proximityStatus : ProximityStatus = .low
    struct ProximityThreshold {
        var low : Double = 70
        var high : Double = 120
    }
    var proximityThreshold = ProximityThreshold()
    mutating func setProximityStatus(value: Double) {
        if value <= proximityThreshold.low {
            proximityStatus = .low
        }
        else if value >= proximityThreshold.high {
            proximityStatus = .high
        }
        else {
            proximityStatus = .medium
        }
    }
}

struct Screen {
    var width = UIScreen.main.bounds.width
    var height = UIScreen.main.bounds.height
    var largestDimension = UIScreen.main.bounds.width > UIScreen.main.bounds.height
        ? UIScreen.main.bounds.width
        : UIScreen.main.bounds.height
    
    var smallestDimension = UIScreen.main.bounds.width > UIScreen.main.bounds.height
        ? UIScreen.main.bounds.height
        : UIScreen.main.bounds.width
}

