//
//  Extensions.swift
//  PlaygroundContent
//
//  Created by Keith Nagle on 25/04/2017.
//  Copyright © 2017 Skoogmusic Ltd. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit
import CoreAudioKit
import CoreMIDI

extension ClosedRange {
    func clamp(value : Bound) -> Bound {
        return self.lowerBound > value ? self.lowerBound
            : self.upperBound < value ? self.upperBound
            : value
    }
}

public func >(left: Int, right: Double)->Bool {
    let rightSide = Int(right)
    return left > rightSide
}

public func >(left: Double, right: Int)->Bool {
    let rightSide = Double(right)
    return left > rightSide
}

public func <(left: Int, right: Double)->Bool {
    let rightSide = Int(right)
    return left < rightSide
}

public func <(left: Double, right: Int)->Bool {
    let rightSide = Double(right)
    return left < rightSide
}

public func >=(left: Int, right: Double)->Bool {
    let rightSide = Int(right)
    return left >= rightSide
}

public func >=(left: Double, right: Int)->Bool {
    let rightSide = Double(right)
    return left >= rightSide
}

public func <=(left: Int, right: Double)->Bool {
    let rightSide = Int(right)
    return left <= rightSide
}

public func <=(left: Double, right: Int)->Bool {
    let rightSide = Double(right)
    return left <= rightSide
}

public func ==(left: Double, right: Int)->Bool {
    let rightSide = Double(right)
    return left == rightSide
}

public func ==(left: Int, right: Double)->Bool {
    let rightSide = Int(right)
    return left == rightSide
}

public func !=(left: Double, right: Int)->Bool {
    let rightSide = Double(right)
    return left != rightSide
}

public func !=(left: Int, right: Double)->Bool {
    let rightSide = Int(right)
    return left != rightSide
}

extension String {
    var first: String {
        return String(prefix(1))
    }
    var last: String {
        return String(suffix(1))
    }
    var uppercaseFirst: String {
        return first.uppercased() + String(dropFirst())
    }
}


extension UIColor {
    /**
     Create a ligher color
     */
    func lighter(by percentage: CGFloat = 30.0) -> UIColor {
        return self.adjustBrightness(by: abs(percentage))
    }
    
    /**
     Create a darker color
     */
    func darker(by percentage: CGFloat = 30.0) -> UIColor {
        return self.adjustBrightness(by: -abs(percentage))
    }
    
    /**
     Try to increase brightness or decrease saturation
     */
    func adjustBrightness(by percentage: CGFloat = 30.0) -> UIColor {
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        if self.getHue(&h, saturation: &s, brightness: &b, alpha: &a) {
            if b < 1.0 {
                let newB: CGFloat = max(min(b + (percentage/100.0)*b, 1.0), 0,0)
                return UIColor(hue: h, saturation: s, brightness: newB, alpha: a)
            } else {
                let newS: CGFloat = min(max(s - (percentage/100.0)*s, 0.0), 1.0)
                return UIColor(hue: h, saturation: newS, brightness: b, alpha: a)
            }
        }
        return self
    }
    
    /**
     Return the vector4 value
     */
    var vectorFloat4Value : vector_float4{
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        if self.getRed(&r, green: &g, blue: &b, alpha: &a) {
            return vector_float4(Float(r),Float(g),Float(b),Float(a))
        }
        else {
            return vector_float4(Float(r),Float(g),Float(b),Float(a))
        }
    }
    
    func blend(color: UIColor, alpha: CGFloat = 0.5) -> UIColor {

            var (r1, g1, b1, a1): (CGFloat, CGFloat, CGFloat, CGFloat) = (0, 0, 0, 0)
            var (r2, g2, b2, a2): (CGFloat, CGFloat, CGFloat, CGFloat) = (0, 0, 0, 0)
            
            self.getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
            color.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
            
            return UIColor(red: 0.5 * (r1 + r2), green: 0.5 * (g1 + g2), blue: 0.5 * (b1 + b2), alpha: (a1 + alpha * a2) / (1.0 + alpha) )
        }
}

extension UIView {
    func startRotating(duration: Double = 1) {
        let kAnimationKey = "rotation"
        
        if self.layer.animation(forKey: kAnimationKey) == nil {
            let animate = CABasicAnimation(keyPath: "transform.rotation")
            animate.duration = duration
            animate.repeatCount = Float.infinity
            animate.fromValue = 0.0
            animate.toValue = .pi * 2.0
            self.layer.add(animate, forKey: kAnimationKey)
        }
    }
    func stopRotating() {
        let kAnimationKey = "rotation"
        
        if self.layer.animation(forKey: kAnimationKey) != nil {
            self.layer.removeAnimation(forKey: kAnimationKey)
        }
    }
}

extension UIDevice {
    var isiPhoneX: Bool {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        if identifier.range(of:"iPhone10,3") != nil || identifier.range(of:"iPhone10,6") != nil {
            return true
        }
        else {
            return false
        }
    }
    
    var modelName: DeviceType {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        //print("Identifier \(identifier)")
        switch identifier {
        case "iPod5,1", "iPhone3,1", "iPhone3,2", "iPhone3,3", "iPod7,1", "iPhone4,1", "iPhone5,1", "iPhone5,2", "iPhone5,3", "iPhone5,4": //here
            return .invalid
        case "iPhone6,1", "iPhone6,2":
            return .iPhone5s
        case "iPhone7,2":
            return .iPhone6
        case "iPhone7,1":
            return .iPhone6Plus
        case "iPhone8,1":
            return .iPhone6s
        case "iPhone8,2":
            return .iPhone6sPlus
        case "iPhone9,1", "iPhone9,3":
            return .iPhone7
        case "iPhone9,2", "iPhone9,4":
            return .iPhone7Plus
        case "iPhone8,4":
            return .iPhoneSE
        case "iPhone10,1", "iPhone10,4":
            return .iPhone8
        case "iPhone10,2", "iPhone10,5":
            return .iPhone8Plus
        case "iPhone10,3", "iPhone10,6":
            return .iPhoneX
        case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":
            return .iPad
        case "iPad3,1", "iPad3,2", "iPad3,3":
            return .iPad
        case "iPad3,4", "iPad3,5", "iPad3,6":
            return .iPad
        case "iPad4,1", "iPad4,2", "iPad4,3":
            return .iPad
        case "iPad5,3", "iPad5,4":
            return .iPad
        case "iPad6,11", "iPad6,12":
            return .iPad
        case "iPad7,5", "iPad7,6":
            return .iPad
        case "iPad2,5", "iPad2,6", "iPad2,7":
            return .iPad
        case "iPad4,4", "iPad4,5", "iPad4,6":
            return .iPad
        case "iPad4,7", "iPad4,8", "iPad4,9":
            return .iPad
        case "iPad5,1", "iPad5,2":
            return .iPad
        case "iPad6,3", "iPad6,4":
            return .iPad
        case "iPad6,7", "iPad6,8":
            return .iPad
        case "iPad7,1", "iPad7,2":
            return .iPad
        case "iPad7,3", "iPad7,4":
            return .iPad
        default:
            return .invalid
        }
    }
}

extension MIDIPacket {
    
     func asArray() -> [UInt8]{
        var internalData = [UInt8](repeating: 0, count: 0) //reset internalData
        var computedLength = 0
        //voodoo
        let mirrorData = Mirror(reflecting: self.data)
        for (_, value) in mirrorData.children {
            if computedLength < self.length {
                computedLength += 1
            }
            guard let byte = value as? UInt8 else {
                print("unable to create sysex midi byte")
                break
            }
            internalData.append(byte)
            if byte == 247 {
                break
            }
        }
        return internalData
    }
    
    mutating func set(index: Int, value: UInt8){
        // This seems completely ridiculous, but...
        guard index <= 63 else {
            print("index greater than the permitted data length - we have only defined cases for indices from 0 to 63")
            return
        }
        switch index {
        case 0:
            self.data.0 = value
        case 1:
            self.data.1 = value
        case 2:
            self.data.2 = value
        case 3:
            self.data.3 = value
        case 4:
            self.data.4 = value
        case 5:
            self.data.5 = value
        case 6:
            self.data.6 = value
        case 7:
            self.data.7 = value
        case 8:
            self.data.8 = value
        case 9:
            self.data.9 = value
        case 10:
            self.data.10 = value
        case 11:
            self.data.11 = value
        case 12:
            self.data.12 = value
        case 13:
            self.data.13 = value
        case 14:
            self.data.14 = value
        case 15:
            self.data.15 = value
        case 16:
            self.data.16 = value
        case 17:
            self.data.17 = value
        case 18:
            self.data.18 = value
        case 19:
            self.data.19 = value
        case 20:
            self.data.20 = value
        case 21:
            self.data.21 = value
        case 22:
            self.data.22 = value
        case 23:
            self.data.23 = value
        case 24:
            self.data.24 = value
        case 25:
            self.data.25 = value
        case 26:
            self.data.26 = value
        case 27:
            self.data.27 = value
        case 28:
            self.data.28 = value
        case 29:
            self.data.29 = value
        case 30:
            self.data.30 = value
        case 31:
            self.data.31 = value
        case 32:
            self.data.32 = value
        case 33:
            self.data.33 = value
        case 34:
            self.data.34 = value
        case 35:
            self.data.35 = value
        case 36:
            self.data.36 = value
        case 37:
            self.data.37 = value
        case 38:
            self.data.38 = value
        case 39:
            self.data.39 = value
        case 40:
            self.data.40 = value
        case 41:
            self.data.41 = value
        case 42:
            self.data.42 = value
        case 43:
            self.data.43 = value
        case 44:
            self.data.44 = value
        case 45:
            self.data.45 = value
        case 46:
            self.data.46 = value
        case 47:
            self.data.47 = value
        case 48:
            self.data.48 = value
        case 49:
            self.data.49 = value
        case 50:
            self.data.50 = value
        case 51:
            self.data.51 = value
        case 52:
            self.data.52 = value
        case 53:
            self.data.53 = value
        case 54:
            self.data.54 = value
        case 55:
            self.data.55 = value
        case 56:
            self.data.56 = value
        case 57:
            self.data.57 = value
        case 58:
            self.data.58 = value
        case 59:
            self.data.59 = value
        case 60:
            self.data.60 = value
        case 61:
            self.data.61 = value
        case 62:
            self.data.62 = value
        case 63:
            self.data.63 = value
        default:
            break
        }
    }
}
