//
//  Globals.swift
//  Skwitch Filter
//
//  Created by David Skulina on 23/04/2018.
//  Copyright © 2018 Skoogmusic Ltd. All rights reserved.
//

import Foundation
#if os(iOS)
import UIKit
#elseif os(OSX)
import Cocoa
#endif

public var defaults = UserDefaults.standard
public var projectSettings : NSMutableDictionary = NSMutableDictionary.init()

//extension NSMutableDictionary {
//    func set(_ value: Any?, forKey: String ){
//        self.setValue(value, forKey: forKey)
//        ProjectViewController.saveProjectAsPlist(name: projectFileName)
//    }
//}

public var projectFileName : String = ""

public var numberOfSegments = 3 {
    didSet {
        print("setting the numberOfSegments default")
        defaults.set(numberOfSegments, forKey: "numSegments")
    }
}

#if os(iOS)
public var session = Session()



public var Settings = DeviceSettings()
#endif

#if os(iOS)
public struct Brand_Color {
    var orange = UIColor.init(red: 236/255, green: 105/255, blue: 12/255, alpha: 1.0)
    var green = UIColor.init(red: 0/255, green: 150/255, blue: 64/255, alpha: 1.0)
    var blue = UIColor.init(red: 39/255, green: 75/255, blue: 155/255, alpha: 1.0)
    var yellow = UIColor.init(red: 255/255, green: 22/255, blue: 33/255, alpha: 1.0)
    var red = UIColor.init(red: 190/255, green: 22/255, blue: 34/255, alpha: 1.0)
}

public struct Theme_Color {
    var green = UIColor.init(red: 183/255, green: 249/255, blue: 0/255, alpha: 1.0)
    var blue = UIColor.init(red: 0/255, green: 170/255, blue: 249/255, alpha: 1.0)
    var red = UIColor.init(red: 220/255, green: 0/255, blue: 249/255, alpha: 1.0)
    var orange = UIColor.init(red: 220/255, green: 0/255, blue: 249/255, alpha: 1.0)
}

public var brand_colors = Brand_Color()

public var theme_colors = Theme_Color(green: UIColor.init(red: 103/255, green: 159/255, blue: 40/255, alpha: 1.0),
                                      blue: UIColor.init(red: 60/255, green: 182/255, blue: 239/255, alpha: 1.0),
                                      red: UIColor.init(red: 220/255, green: 0/255, blue: 249/255, alpha: 1.0),
                                      orange: brand_colors.orange)

public let theme_color_array : [UIColor] = [theme_colors.green, theme_colors.blue, theme_colors.red, theme_colors.orange]


#elseif os(OSX)
public struct Brand_Color {
    var orange = NSColor.init(red: 236/255, green: 105/255, blue: 12/255, alpha: 1.0)
    var green = NSColor.init(red: 0/255, green: 150/255, blue: 64/255, alpha: 1.0)
    var blue = NSColor.init(red: 39/255, green: 75/255, blue: 155/255, alpha: 1.0)
    var yellow = NSColor.init(red: 255/255, green: 22/255, blue: 33/255, alpha: 1.0)
    var red = NSColor.init(red: 190/255, green: 22/255, blue: 34/255, alpha: 1.0)
}

public struct Theme_Color {
    var green = NSColor.init(red: 183/255, green: 249/255, blue: 0/255, alpha: 1.0)
    var blue = NSColor.init(red: 0/255, green: 170/255, blue: 249/255, alpha: 1.0)
    var red = NSColor.init(red: 220/255, green: 0/255, blue: 249/255, alpha: 1.0)
    var orange = NSColor.init(red: 220/255, green: 0/255, blue: 249/255, alpha: 1.0)
}

public var brand_colors = Brand_Color()

public var theme_colors = Theme_Color(green: NSColor.init(red: 103/255, green: 159/255, blue: 40/255, alpha: 1.0),
                                      blue: NSColor.init(red: 60/255, green: 182/255, blue: 239/255, alpha: 1.0),
                                      red: NSColor.init(red: 220/255, green: 0/255, blue: 249/255, alpha: 1.0),
                                      orange: brand_colors.orange)

public let theme_color_array : [NSColor] = [theme_colors.green, theme_colors.blue, theme_colors.red, theme_colors.orange]

#endif

public var theme_color = theme_colors.green

public struct Gyro {
    var x = 0.0
    var y = 0.0
    var z = 0.0
}

public struct Cartesian {
    var x = 0.0
    var y = 0.0
    var z = 0.0
    func magnitude() -> Double{
        return (x*x + y*y + z*z).squareRoot()
    }
}

public enum AudioMode : Int{
    case midi = 0
    case generator
}


