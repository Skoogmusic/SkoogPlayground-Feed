//
//  Ping.swift
//  SupportingContent
//
//  Created by James Callaghan on 14/08/2018.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

import Foundation
import SpriteKit
import GameplayKit
import AudioToolbox
import UIKit

public class SkwitchPing: SKShapeNode {
    
    public enum PingType {
        case noteShift
        case fixedNote
        case chord
        case chordShift
    }
    
    public var noteOffset : Int = 0
    public var colorString : String = ""
    public var note : Int = 0
    public var type : PingType = .noteShift
    public var lastPlayedNote : [MidiNoteNumber] = [0]
    var noteLabel = SKLabelNode(text: "")
    
    static func ping(width: CGFloat) -> SkwitchPing {
        let skwitchPing = SkwitchPing(rectOf: CGSize(width: width, height: width))
        
        skwitchPing.lineWidth = 0.0
        skwitchPing.strokeColor = .clear
        skwitchPing.isAccessibilityElement = true
        skwitchPing.addChild(skwitchPing.noteLabel)
        return skwitchPing
    }
    
    public override var accessibilityLabel : String? {
        set { }
        get {
            let x = self.position.x
            let y = self.position.y - 22
            let angle : CGFloat = atan2(-x, -y) * (180.0 / CGFloat.pi) + 180
            let distance : CGFloat = (sqrt(x * x + y * y) - 64 - 5 - 0.5 * self.frame.width) / 48
            let onTopString = NSLocalizedString("On top of the Skwitch Circle", comment: "on top string")
            let angleString = String(format: NSLocalizedString("sd:allPages.angleMessage", comment: "angle message - {angle in degrees}"), angle)
            let distanceString = String(format: NSLocalizedString("sd:allPages.distanceMessage", comment: "distance message - {distance in pixels}"), distance)
            let string = String(format: "%@, %@, %@, %@", self.name!, self.colorString, distance < 0 ? onTopString : distanceString, angleString)
            return string
        }
    }
    
    public override var accessibilityCustomActions : [UIAccessibilityCustomAction]? {
        set { }
        get {
            let description = UIAccessibilityCustomAction(name: NSLocalizedString("Ping description", comment: "ping custom action description"), target: self, selector: #selector(pingDescriptionAXAction))
            return [description]
        }
    }
    @objc func pingDescriptionAXAction() {
        let pingDescription = String(format: NSLocalizedString("sd:allPages.pingDescription", comment: "ping description message"), self.colorString, self.noteOffset)
        UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification, pingDescription)
    }
}
