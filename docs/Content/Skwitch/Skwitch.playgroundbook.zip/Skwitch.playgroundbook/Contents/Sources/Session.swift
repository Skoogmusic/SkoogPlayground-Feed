//
//  Scale.swift
//  Skwitch
//
//  Created by David Skulina on 16/01/2018.
//  Copyright © 2018 Skoogmusic Ltd. All rights reserved.
//
import Foundation

public enum Key : Int, Codable {
    case C = 0
    case Cs
    case D
    case Eb
    case E
    case F
    case Fs
    case G
    case Gs
    case A
    case Bb
    case B
    var name: String {
        switch(self){
        case .C:
            return NSLocalizedString("C", comment: "the musical note C")
        case .Cs:
            return NSLocalizedString("C♯", comment: "the musical note C♯")
        case .D:
            return NSLocalizedString("D", comment: "the musical note D")
        case .Eb:
            return NSLocalizedString("E♭", comment: "the musical note E♭")
        case .E:
            return NSLocalizedString("E", comment: "the musical note E")
        case .F:
            return NSLocalizedString("F", comment: "the musical note F")
        case .Fs:
            return NSLocalizedString("F♯", comment: "the musical note F♯")
        case .G:
            return NSLocalizedString("G", comment: "the musical note G")
        case .Gs:
            return NSLocalizedString("G♯", comment: "the musical note G♯")
        case .A:
            return NSLocalizedString("A", comment: "the musical note A")
        case .Bb:
            return NSLocalizedString("B♭", comment: "the musical note B♭")
        case .B:
            return NSLocalizedString("B", comment: "the musical note B")
        }
    }
    static var allCases: [Key] {
        var values: [Key] = []
        var index = 0
        while let element = self.init(rawValue: index) {
            values.append(element)
            index += 1
        }
        return values
    }
}

public struct Triad {
    var notes : [MidiNoteNumber] = [0,4,7]
    var index = 0
    mutating func make(_ scale: [MidiNoteNumber], i: Int) -> Triad{
        let notesInScale = scale.count - 1
        notes[0] = scale[i]
        notes[1] = scale[(2 + i) % notesInScale] + Int((2 + i)/notesInScale) * 12
        notes[2] = scale[(4 + i) % notesInScale] + Int((4 + i)/notesInScale) * 12
        index = i
        return self
    }
    mutating func invert(_ number: Int){
        var newNotes =  notes
        if number >= 0 {
            newNotes[0] = notes[number % 3]
            newNotes[1] = notes[(number + 1) % 3] + Int((number + 1)/3) * 12
            newNotes[2] = notes[(number + 2) % 3] + Int((number + 2)/3) * 12
        }
        else{
            newNotes[0] = notes[(number + 3) % 3] - 12
            newNotes[1] = notes[(number + 4) % 3] - number < -1 ? 12 : 0
            newNotes[2] = notes[(number + 5) % 3]
        }
    }
}

public enum ScaleType : Int, Codable {
    case major
    case minor
    case dorian
    case phrygian
    case lydian
    case mixolydian
    case locrian
    case flamenco
    case hungarian
    case persian
    case altered
    var notes: [MidiNoteNumber] {
        switch self {
        case .major:
            return [0, 2, 4, 5, 7, 9, 11]
        case .minor:
            return [0, 2, 3, 5, 7, 8, 10]
        case .dorian:
            return [0, 2, 3, 5, 7, 9, 10]
        case .phrygian:
            return [0, 1, 3, 5, 7, 8, 10]
        case .lydian:
            return [0, 2, 4, 6, 7, 9, 11]
        case .mixolydian:
            return [0, 2, 4, 5, 7, 9, 10]
        case .locrian:
            return [0, 1, 3, 5, 6, 8, 10]
        case .flamenco:
            return [0, 1, 4, 5, 7, 8, 11]
        case .hungarian:
            return [0, 2, 3, 6, 7, 8, 10]
        case .persian:
            return [0, 1, 4, 5, 6, 8, 11]
        case .altered:
            return [0, 1, 3, 4, 6, 8, 10]
        }
    }
    var name: String {
        switch(self){
        case .major:
            return NSLocalizedString("Major", comment: "Major Scale")
        case .minor:
            return NSLocalizedString("Minor", comment: "Minor Scale")
        case .dorian:
            return NSLocalizedString("Dorian", comment: "Dorian Scale")
        case .phrygian:
            return NSLocalizedString("Phrygian", comment: "Phrygian Scale")
        case .lydian:
            return NSLocalizedString("Lydian", comment: "Lydian Scale")
        case .mixolydian:
            return NSLocalizedString("Mixolydian", comment: "Mixolydian Scale")
        case .locrian:
            return NSLocalizedString("Locrian", comment: "Locrian Scale")
        case .flamenco:
            return NSLocalizedString("Flamenco", comment: "Flamenco Scale")
        case .hungarian:
            return NSLocalizedString("Hungarian", comment: "Hungarian Scale")
        case .persian:
            return NSLocalizedString("Persian", comment: "Persian Scale")
        case .altered:
            return NSLocalizedString("Altered", comment: "Altered Scale")
        }
    }
    var tonality: Tonality {
        switch(self){
        case .major:
            return .major
        case .minor:
            return .minor
        case .dorian:
            return .minor
        case .phrygian:
            return .minor
        case .lydian:
            return .major
        case .mixolydian:
            return .major
        case .locrian:
            return .minor
        case .flamenco:
            return .major
        case .hungarian:
            return .minor
        case .persian:
            return .major
        case .altered:
            return .minor
        }
    }
    
    public enum Tonality : Int, Codable {
        case major = 0
        case minor
    }
    
    static var allCases: [ScaleType] {
        var values: [ScaleType] = []
        var index = 0
        while let element = self.init(rawValue: index) {
            values.append(element)
            index += 1
        }
        return values
    }
}

public struct Note {
    var current : MidiNoteNumber = 60 {
        didSet{
            last = oldValue
        }
    }
    var last : MidiNoteNumber = 60
}


public struct Riff : Codable {
    var notes : [MidiNoteNumber] = []
    var name : String = "Riff"
    var preferredKey : Key = .C
    var preferredScale : ScaleType = .major
    var isEditable = false
    init(notes: [MidiNoteNumber], name: String){
        self.notes = notes
        self.name = name
    }
    init(notes: [MidiNoteNumber], name: String, isEditable : Bool){
        self.notes = notes
        self.name = name
        self.isEditable = isEditable
    }
}


public struct Session {
    var key : Key = .C {
        didSet {
            if key != oldValue {
                defaults.set(key.rawValue, forKey: "scaleKey")
//                projectSettings.set(key.rawValue, forKey: "scaleKey")
            }
        }
    }
    var type : ScaleType = .major {
        didSet {
            if type != oldValue {
                defaults.set(type.rawValue, forKey: "scaleType")
//                projectSettings.set(type.rawValue, forKey: "scaleType")
            }
        }
    }
    public var scale : [MidiNoteNumber] = ScaleType.major.notes
    public var scaleNoteNames : [String] = ["C","D","E","F","G","A","B"]
    public var rootNote : MidiNoteNumber = 72
    var octave : Int = 5
    var octaveRange : Int = 3
    var octaveLowest : Int = 5

    public var currentNote : [MidiNoteNumber] = [75] {
        didSet {
            self.previousNote = oldValue
        }
    }
    public var previousNote : [MidiNoteNumber] = [75]
    
    public var pitchBendTarget : [Float?] = [nil]
    
    var notes : [MidiNoteNumber] = [0, 2, 4, 5, 7, 9, 11, 12]
    var noteIndex = 0
    
    var arpIndex = 0
    
    var chords : [Triad] = Array.init(repeating: Triad(), count: 7)
    var chordIndex = 0

    var triads : [Triad] = Array.init(repeating: Triad(), count: 7)
    var triadNames : [String] = ["C","D","E","F","G","A","B"]

    
    var riffIndex = 0
    var riff : [Riff] = [Riff(notes: [0,1,2,3,4,5,6,7], name: "Scale"),
                         Riff(notes: [0,0,2,2,3,2,0], name: "Riff 1"),
                         Riff(notes: [0,1,2,4,5], name: "Riff Two"),
                         Riff(notes: [1,4,0,3,2,0], name: "Ruff 3"),
                         Riff(notes: [4,4,5,4,7,6,
                                      4,4,5,4,8,7,
                                      4,4,11,9,7,6,5,
                                      10,10,9,7,8,7], name: "Happy B")]
    
    var userRiff : [Riff] = [] {
        didSet{
            print("didset")
            let encoder = JSONEncoder()
            do {
                let jsonData = try encoder.encode(userRiff)
                defaults.setValue(jsonData, forKey: "userRiffs")
//                projectSettings.set(jsonData, forKey: "userRiffs")
            }
            catch {
                print("encoder failed")
            }
            if oldValue.count == 0 { //if on first load, add the whole userRiff library to the main riff
                print("didset - count 0", userRiff)

                riff.append(contentsOf: userRiff)
                print("didset - count 0, riff:", riff )
            }
            else if oldValue.count < userRiff.count {
                print("didset - count <")

                riff.append(userRiff.last!)
            }
        }
    }

    var customRiffActive = false //temp to test riff editor
    var progIndex = 0
    var progression : [Riff] = [Riff(notes: [0,1,2,3,4,5,6,7], name: "Sequence"),
                                Riff(notes: [0,2,4], name: "I-III-V"),
                                Riff(notes: [0,3,4], name: "I-IV-V"),
                                Riff(notes: [0,5,3,4], name: "I-VI-IV-V"),
                                Riff(notes: [0,3,6,2,5,1,4,0], name: "Circle1")]
    
    var userProgression : [Riff] = [] {
        didSet{
            print("didset")
            let encoder = JSONEncoder()
            do {
                let jsonData = try encoder.encode(userProgression)
                defaults.setValue(jsonData, forKey: "userProgressions")
//                projectSettings.set(jsonData, forKey: "userProgressions")
            }
            catch {
                print("encoder failed")
            }
            if oldValue.count == 0 { //if on first load, add the whole userRiff library to the main riff
                print("didset - count 0", userProgression)
                progression.append(contentsOf: userProgression)
                print("didset - count 0, riff:", progression)
            }
            else if oldValue.count < userProgression.count {
                print("didset - count <")
                progression.append(userProgression.last!)
            }
        }
    }
    
    //MARK: User Defaults Functions
    
    mutating func restoreUserDefaults(){
        let decoder = JSONDecoder()
        if let data = (defaults.object(forKey: "userRiffs") as? Data) {
            do {
                let userRiff = try decoder.decode([Riff].self, from: data)
                self.userRiff = userRiff
//                projectSettings.set(data, forKey: "userRiffs")
                //self.riff.append(contentsOf: userRiff)
            }
            catch {
                print("decoder failed", error)
            }
        }
        else {
            print("error with userRiffs:", defaults.object(forKey: "userRiffs"))
        }
        
        if let data = (defaults.object(forKey: "userProgressions") as? Data) {
            do {
                let userProgression = try decoder.decode([Riff].self, from: data)
                self.userProgression = userProgression
//                projectSettings.set(userProgression, forKey: "userProgressions")
            }
            catch {
                print("decoder failed", error)
            }
        }
        else {
            print("error with userProg:", defaults.object(forKey: "userProgressions"))
        }
        
        if let key = (defaults.integer(forKey: "scaleKey") as? Int) {
            self.key = Key.init(rawValue: key)!
//            projectSettings.set(key, forKey: "scaleKey")
        }
        
        if let type = (defaults.integer(forKey: "scaleType") as? Int) {
            self.type = ScaleType.init(rawValue: type)!
//            projectSettings.set(type, forKey: "scaleType")
        }
        
        self.setKey(self.key, type: self.type)
    }
    
    
    
    //MARK: Session Setup Functions
    
    public mutating func setKey(_ key: Key, type: ScaleType) {
        self.key = key
        self.type = type
        
        rootNote = octave * 12 + key.rawValue
        scale = type.notes
        setRiff(riffIndex)
        
        triads = Array.init(repeating: Triad(), count: scale.count)
        for (i,_) in scale.enumerated() {
            triads[i] = triads[i].make(scale, i: i)
        }
        setProgression(progIndex)
        self.scaleNoteNames = getScaleNoteNames()
        self.triadNames = getScaleNoteNames()
    }
    
    mutating func setRiff(_ index: Int) {
        let r = riff[index].notes
        self.notes = Array.init(repeating: MidiNoteNumber(0), count: r.count)
        for (i, j) in r.enumerated() {
            let noteIndexInRiff = j % (scale.count)
            let noteOctaveInRiff = Int(j / (scale.count))
            self.notes[i] = self.scale[noteIndexInRiff] + noteOctaveInRiff * 12
        }
        // wrap the note index if required
        if noteIndex >= r.count - 1 {
            noteIndex = noteIndex % r.count
        }
        riffIndex = index
        rootNote = octave * 12 + key.rawValue
        currentNote = [rootNote + self.notes[0]]
    }
    
    mutating func setCustomRiff(riff: Riff) {
        customRiffActive = true
        let r = riff.notes
        self.notes = Array.init(repeating: MidiNoteNumber(0), count: r.count)
        for (i, j) in r.enumerated() {
            let noteIndexInRiff = j >= 0 ? j % (scale.count) : (scale.count + j) % scale.count
            let noteOctaveInRiff = j >= 0 ? Int(j / (scale.count)) : Int((j - scale.count + 1) / scale.count)
            self.notes[i] = self.scale[noteIndexInRiff] + noteOctaveInRiff * 12
        }
        // wrap the note index if required
        if noteIndex >= r.count - 1 {
            noteIndex = noteIndex % r.count
        }
        //riffIndex = index
        rootNote = octave * 12 + key.rawValue
        currentNote = [rootNote + self.notes[0]]
    }
    
    mutating func setCustomProgression(progression: Riff) {
        customRiffActive = true
        let p = progression.notes
        self.chords = Array.init(repeating: Triad(), count: p.count)
        for (i, j) in p.enumerated() {
            let chordIndexInProg = j >= 0 ? j % (triads.count) : (triads.count + j) % triads.count
            let chordOctaveInProg = j >= 0 ? Int(j / (triads.count)) : Int((j - triads.count + 1) / triads.count)
            chords[i] = triads[chordIndexInProg]
            self.chords[i].notes = chords[i].notes.map({$0 + chordOctaveInProg * 12})
        }
        // wrap the note index if required
        if chordIndex >= p.count - 1 {
            chordIndex = chordIndex % p.count
        }
        //riffIndex = index
        rootNote = octave * 12 + key.rawValue
        currentNote = chords[chordIndex].notes.map({$0 + rootNote})
    }
    
    mutating func setProgression(_ index: Int) {
        let p = progression[index].notes
        self.chords = Array.init(repeating: Triad(), count: p.count)
        for (i, j) in p.enumerated() {
            let chordIndexInProg = j % (triads.count)
            let chordOctaveInProg = Int(j / (triads.count))
            chords[i] = triads[chordIndexInProg]
            chords[i].notes = chords[i].notes.map({$0 + chordOctaveInProg * 12})
        }
        if chordIndex >= p.count - 1 {
            chordIndex = chordIndex % p.count
        }
        progIndex = index
        rootNote = octave * 12 + key.rawValue
        currentNote = chords[chordIndex].notes.map({$0 + rootNote})
    }
    
    mutating func getScaleNoteNames() -> [String] {
        var names = [String].init(repeating: "", count: scale.count)
        for (i, note) in scale.enumerated() {
            names[i] = Key(rawValue: (note + key.rawValue) % 12)!.name
        }
        return names
    }
    
    mutating func getRiffNoteNames() -> [String] {
        var names = [String].init(repeating: "", count: riff[riffIndex].notes.count)
        for (i, note) in riff[riffIndex].notes.enumerated() {
            names[i] = Key(rawValue: note % 12)!.name
        }
        return names
    }
    
    mutating func getRiffNoteNames(riff: Riff) -> [String] {
        var names = [String].init(repeating: "", count: riff.notes.count)
        for (i, index) in riff.notes.enumerated() {
            let noteIndexInRiff = index % (scale.count)
            let noteOctaveInRiff = Int(index / (scale.count))
            let note = self.scale[noteIndexInRiff] + noteOctaveInRiff * 12
            //names[i] = Key(rawValue: note % 12)!.name
            names[i] = self.scaleNoteNames[index % scale.count]
        }
        return names
    }
    
    

   //MARK: Note Functions
    mutating func randomNote(withOctave: Bool? = false) -> [MidiNoteNumber] {
        (currentNote, noteIndex) = getRandomNote(withOctave: withOctave)
        return currentNote
    }
    
    mutating func getRandomNote(withOctave: Bool? = false) -> ([MidiNoteNumber], Int) {
        let index = Int(arc4random_uniform(UInt32(notes.count)))
        if withOctave != nil && withOctave! {
            return ([notes[index] + (octaveLowest + MidiNoteNumber(arc4random_uniform(UInt32(octaveRange)))) * 12], index)
        }
        else {
            return ([notes[index] + rootNote], index)
        }
    }

    mutating func noteUp() -> [MidiNoteNumber] {
        (currentNote, noteIndex) = getNoteUp()
        return currentNote
    }
    
    mutating func getNoteUp() -> ([MidiNoteNumber], Int) {
        let index = noteIndex + 1 < notes.count ? noteIndex + 1 : 0
        let note = [notes[index] + rootNote]
        return (note, index)
    }
    
    mutating func noteDown() -> [MidiNoteNumber] {
        (currentNote, noteIndex) =  getNoteDown()
        return currentNote
    }
    
    mutating func getNoteDown() -> ([MidiNoteNumber], Int) {
        let index = noteIndex - 1 >= 0 ? noteIndex - 1 : notes.count - 1
        let note = [notes[index] + rootNote]
        return (note, index)
    }
    
//    mutating func noteUpDown() -> [MidiNoteNumber] {
//        (currentNote, noteIndex) =  getNoteUpDown()
//        return currentNote
//    }
//    
//    mutating func getNoteUpDown() -> ([MidiNoteNumber], Int) {
//        let index = noteIndex + 1 < notes.count ? noteIndex + 1 : notes.count - 1
//        let note = [notes[index] + rootNote]
//        return (note, index)
//    }
    
    mutating func firstNote() -> [MidiNoteNumber] {
        noteIndex = 0
        currentNote = [notes[noteIndex] + rootNote]
        return currentNote
    }
    
    mutating func lastNote() -> [MidiNoteNumber] {
        noteIndex = notes.count - 1
        currentNote = [notes[noteIndex] + rootNote]
        return currentNote
    }
    
    mutating func holdNote() -> [MidiNoteNumber] {
        currentNote = getHoldNote()
        return currentNote
    }
    
    mutating func getHoldNote() -> [MidiNoteNumber] {
        let note = [notes[noteIndex] + rootNote]
        return note
    }
    
    mutating func fixedNote(_ index: Int) -> [MidiNoteNumber] {
        currentNote = getFixedNote(index)
        return currentNote
    }
    
    mutating func getFixedNote(_ index: Int) -> [MidiNoteNumber] {
        let note = [rootNote + scale[index]]
        return note
    }
    

    //MARK: Chord Functions

    mutating func randomChord(withInversion: Bool? = false) -> [MidiNoteNumber] {
        (currentNote, chordIndex) = getRandomChord(withInversion: withInversion)
        return currentNote
    }
    
    mutating func getRandomChord(withInversion: Bool? = false) -> ([MidiNoteNumber], Int) {
        let index = Int(arc4random_uniform(UInt32(chords.count)))
        if withInversion != nil && withInversion! {
            return (chords[index].notes.map({$0 + (octaveLowest + MidiNoteNumber(arc4random_uniform(UInt32(octaveRange)))) * 12}), index)
        }
        else {
            return (chords[index].notes.map({$0 + rootNote}), index)
        }
    }
    
    mutating func chordUp() -> [MidiNoteNumber] {
        (currentNote,chordIndex) = getChordUp()
        return currentNote
    }
    mutating func getChordUp() -> ([MidiNoteNumber], Int) {
        let index = chordIndex + 1 < chords.count ? chordIndex + 1 : 0
        let note = chords[index].notes.map({$0 + rootNote})
        
        return (note, index)
    }
    
    mutating func chordDown() -> [MidiNoteNumber] {
        (currentNote, chordIndex) = getChordDown()
        return currentNote
    }
    mutating func getChordDown() -> ([MidiNoteNumber], Int) {
        let index = chordIndex - 1 >= 0 ? chordIndex - 1 : chords.count - 1
        let note = chords[index].notes.map({$0 + rootNote})
        return (note, index)
    }
    
    mutating func firstChord() -> [MidiNoteNumber] {
        chordIndex = 0
        currentNote = chords[chordIndex].notes.map({$0 + rootNote})
        return currentNote
    }
    mutating func lastChord() -> [MidiNoteNumber] {
        chordIndex = chords.count - 1
        currentNote = chords[chordIndex].notes.map({$0 + rootNote})
        return currentNote
    }
    
    mutating func holdChord() -> [MidiNoteNumber] {
        currentNote = getHoldChord()
        return currentNote
    }
    mutating func getHoldChord() -> [MidiNoteNumber] {
        let note = chords[chordIndex].notes.map({$0 + rootNote})
        return note
    }
    
    mutating func fixedChord(_ index: Int) -> [MidiNoteNumber] {
        currentNote = getFixedChord(index)
        return currentNote
    }
    mutating func getFixedChord(_ index: Int) -> [MidiNoteNumber] {
        let note = triads[index].notes.map({$0 + rootNote})
        return note
    }
    
    mutating func chordArpUp() -> [MidiNoteNumber] {
        arpIndex = arpIndex + 1 < chords[chordIndex].notes.count ? arpIndex + 1 : 0
        currentNote = [chords[chordIndex].notes[arpIndex] + rootNote]
        return currentNote
    }
    
    mutating func chordArpDown() -> [MidiNoteNumber] {
        arpIndex = arpIndex - 1 >= 0 ? arpIndex - 1 : chords[chordIndex].notes.count - 1
        currentNote = [chords[chordIndex].notes[arpIndex] + rootNote]
        return currentNote
    }
    
    mutating func chordArpUpDown() -> [MidiNoteNumber] {
        arpIndex = arpIndex + 1 < 2 * chords[chordIndex].notes.count - 1 ? arpIndex + 1 : 0
        let count = Int(arpIndex / (chords[chordIndex].notes.count))
        if count == 0 {
            currentNote = [chords[chordIndex].notes[arpIndex] + rootNote]
//            print("arpup: ", arpIndex)
        }
        else {
            let downIndex = (chords[chordIndex].notes.count - 1) - arpIndex % chords[chordIndex].notes.count - 1
//            print("arpdown: ", downIndex)
        }
        //currentNote = [chords[chordIndex].notes[arpIndex] + rootNote]
        return currentNote
    }
    
    mutating func chordArpRandom(withInversion: Bool? = false) -> [MidiNoteNumber] {
        arpIndex = Int(arc4random_uniform(UInt32(chords[chordIndex].notes.count)))
        currentNote = [chords[chordIndex].notes[arpIndex] + rootNote]
        return currentNote
    }
    
}
