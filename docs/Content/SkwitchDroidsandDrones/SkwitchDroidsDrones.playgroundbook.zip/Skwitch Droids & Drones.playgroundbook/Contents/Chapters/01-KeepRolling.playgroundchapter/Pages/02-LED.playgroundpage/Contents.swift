//#-hidden-code
//
//  Contents.swift
//  spheroArcade
//
//  Created by Jordan Hesse on 2017-04-26.
//  Copyright © 2017 Sphero Inc. All rights reserved.
//
//#-end-hidden-code

/*:
 Here you can send sphero a different command with every press of the Skwitch. Currently we're set up to drive sphero in a square using 4 presses of the Skwitch.
 */

//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, onReady(), self, connectedAction(), continous(side: Side), didValueChange(currentValue: , lastValue), disconnectedAction(), messageFilterRate, orangeAction(), redCounter)
//#-code-completion(identifier, show, ., roll(heading:speed:), stopRoll(), wait(for:), setMainLed(color:), setBackLed(brightness:), setStabilization(state:), setCollisionDetection(configuration:), startAiming(), stopAiming(), enableSensors(sensorMask:), disableSensors(), configureLocator(newX:newY:newYaw:), addSensorListener(_:), addCollisionListener(_:), setRawMotor(leftMotorPower:leftMotorMode:rightMotorPower:rightMotorMode:), addFreefallListener(_:), RawMotor, RawMotorMode, forward, reverse, off, brake, ignore, addLandListener(_:), Sound, play(), applause, ding, dizzy, no, sad, complete, success, shake, spin, tap, jump, slowDown, fall, hit, speedUp, powerDown, pop, bounce, plummet, evilLaugh, powerUp, bell, buttonPulse, celebrate, cheering, tick, lightning, bleep, sparkle, bloop, grow, allSounds, setFrontPSILed(color:), setBackPSILed(color:), setHoloProjectorLed(brightness:), setLogicDisplaysLed(brightness:), setDomePosition(angle:), setStance(_:), play(sound:playbackMode:), play(sound:), setHeadLed(brightness:), R2D2Sound, happy, cheerful, joyful, hello, excited, sad, scared, cautious, scan, talking, immediately, playOnlyIfNotPlaying, afterCurrent, R2D2Stance, bipod, tripod, waddle, CollisionData, attitude, locator, accelerometer, gyro, orientation, on, playAnimation(_:), R2D2Animations, alarmed, angry, annoyed, chatty, drive, excited, happy, ionBlast, laugh, sassy, scared, yes, sleep, surprised)

public class SpheroSkoogListener: SkoogListener {
    public var spheroHeading = 0
    public var toggle = true
    //#-end-hidden-code
    var counter : Int = 0
    // Press Skwitch to change color drive
    func press() {
        if counter == 0 {
            //#-editable-code
            setMainLed(color: .orange)
            roll(heading: 0, speed: 100)
            //#-end-editable-code
            counter += 1
        }
        else if counter == 1 {
            //#-editable-code
            setMainLed(color: .red)
            roll(heading: 90, speed: 100)
            //#-end-editable-code
            counter += 1
        }
        else if counter == 2 {
            //#-editable-code
            setMainLed(color: .blue)
            roll(heading: 180, speed: 100)
            //#-end-editable-code
            counter += 1
        }
        else {
            //#-editable-code
            setMainLed(color: .green)
            roll(heading: 270, speed: 100)
            //#-end-editable-code
            counter = 0
        }
    }
    //#-hidden-code
    
    @objc func white() {
        setMainLed(color: .white)
    }
    
    public override func peak(_ side: Side, _ peak: Double) {
        press()
    }
    
    
}

let spheroSkoogListener = SpheroSkoogListener()

func onReady() {
    addJoystickListener { (x, y) in
        if !spheroSkoogListener.skoogConnected {
            if x == 0 && y == 0 {
                stopRoll()
            } else {
                let heading = atan2(x, y) * 180.0 / Double.pi
                
                let speed = (x*x + y*y) * 255.0
                
                roll(heading: Int(heading), speed: Int(speed))
            }
        }
    }
    
    addAimHeadingListener { (heading: Int) in
        rotateAim(heading: heading)
    }
    
    addAimStartListener {
        startAiming()
    }
    
    addAimStopListener {
        stopAiming()
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true
setupContent(assessment: TemplateAssessmentController(), userCode: onReady)
//#-end-hidden-code

