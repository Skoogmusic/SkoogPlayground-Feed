////
////  Skoog.swift
////  Skoog
////
////  Created by Keith Nagle on 10/06/2016.
////  Copyright © 2016 Skoogmusic Ltd. All rights reserved.
////
//
import CoreMIDI
// MARK: use UIKit for iOS apps
import UIKit
// MARK: use Cocoa  for macOS apps
// import Cocoa
import QuartzCore
//
//public protocol SkoogDelegate: class {
//    func peak(_ side: Side,_ peak: Double)
//    func continuous(_ side: Side)
//    func release(_ side: Side)
//    func skoogConnectionStatus(_ connected: Bool)
//    func updateProbe(_ packet: [Int])
//    func showMagnetWarning()
//}
//
public enum ColorString: String {
    case red
    case blue
    case yellow
    case green
    case orange
    case white
    var string: String {
        switch self {
        case .red:
            return "red"
        case .blue:
            return "blue"
        case .yellow:
            return "yellow"
        case .green:
            return "green"
        case .orange:
            return "orange"
        case .white:
            return "white"
        }
    }
}
//
//
//
//
///**
// Side Class - used to store info about the playing state of each side of the Skoog
//
// - active:  Indicates if the side is turned on or off.
// - isPlaying:  Used to monitor the current playing state of the side.
// - color: UIColor value of the side.
// - rawValue: The raw squeeze data.
// - response: Sets the response adjustment level (0 - 12).
// - value: The response curve adjusted squeeze value.
// - peak: Reports the strength of peaks detected in the squeeze data.
// - angle: Reports the 0-359 degree angle (where yellow is 0 or 360 degrees) for the current press.
// - name: String name of the current side.
// - blend_in_xy:
// - blend_out_xy:
// - play(): Function to set the active state of the side to true (turn on).
// - stop(): Function to set the active state of the side to false (turn off).
// */

public class Side: NSObject {
    public var active : Bool = true
    public var isPlaying : Bool = false
    // MARK: use UIColor for iOS apps
    public var color : UIColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
    // MARK: use NSColor for macOS apps
    //public var color : NSColor = NSColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
    public var rawValue : Double = 0
    public var value : Double = 0
    public var peak : Peak? = Peak.init()
    public var peakValue : Double? = 0
    public var deltaT : Double? = 0
    public var index : Int = 0 // perhaps not needed but useful for identifying by index for now
    public var response : Double = 0.0
    public var angle : Double = 0.0
    public var name : ColorString = .white
    public var blend_in_xy : Double = 0.0
    public var blend_out_xy : Double = 0.0
    public var blend_in_z : Double = 0.0
    public var dx : Double = 0.0
    public var dy : Double = 0.0
    public var dr : Double = 0.0
    public var dz : Double = 0.0
    public var threshold : Double = 0.0
    public func play() {
        self.active = true
    }
    public func stop() {
        self.active = false
    }
    public override init() {
        super.init()
    }
}

