import Foundation
import UIKit
import CoreBluetooth
import PlaygroundSupport

//func peak(_ side: Side,_ peak: Double)
//func continuous(_ value: Double)
//func release(_ side: Side)
//var sides : [Side] {get set}
let CABTMIDINotificationKey = "com.skoogmusic.CABTMIDINotificationKey"

open class SkoogListener : NSObject, SkwitchMIDIDelegate {
//    public let skoog    = Skoog.sharedInstance
    public var bluetooth : BLEMessages?
    
    public var calibrationTimer : Timer?
    
    public var skoogConnected : Bool = false
    public var newConnection : Bool = false
    public var connectedSkoog : CBPeripheral? = nil
    public var bluetoothUI : BluetoothMIDIViewController?
    
    public var midi = SkwitchMIDI()
    public var midiNotes : [MidiNoteNumber] = [61, 91]
    public var noteIndex : Int = 0
    
    public var red = Side()
    public var blue = Side()
    public var yellow = Side()
    public var green = Side()
    public var orange = Side()
    public var sides = Array.init(repeatElement(Side(), count: 5))
    
    public var threshold : Double = 0.0
    
    public var readyToPlay : Bool = false
    
    var connectedPeripheral : CBPeripheral?
    
    public override init() {
        super.init()
//        bluetooth = BLEMessages()
//        bluetooth?.delegate = self
        self.sides = [red, blue, yellow, green, orange]
        Timer.scheduledTimer(timeInterval:0.1, target: self, selector: #selector(skoogSearchTask), userInfo: nil, repeats: false)
        NotificationCenter.default.addObserver(forName: NSNotification.Name(rawValue: CABTMIDINotificationKey), object: nil, queue: nil, using: notify)
        midi.delegate = self
        midi.start()
    }
    
    public func notify(notification:Notification) -> Void {
        
        guard let userInfo = notification.userInfo,
            let status = userInfo["status"] as? CABTMIDIStatus
            
            else {
                print("No userInfo found in notification")
                return
        }
        
        print ("Connection Status is :", status)
        DispatchQueue.main.async {
            //            self.CABTperipheral?.dismissVC()
            //            if !(self.CABT?.skoogConnected)! {
            let connected = status.connected == .connectedToPeripheral
            if connected {
                self.bluetoothUI?.skoogConnected = connected
                self.bluetoothUI?.skoogConnectionStatus(connected:connected)
                self.setReadyToPlay()
                //                    switch (status.BLEMIDIDeviceIdiom){
                //                    case .pad:
                //                        self.CABT?.disconnectedTexture = SKTexture(imageNamed: "access_transmitting_iPad_icon")
                //                    case .phone:
                //                        self.CABT?.disconnectedTexture = SKTexture(imageNamed: "access_transmitting_iPhone_icon")
                //                    default:
                //                        self.CABT?.disconnectedTexture = SKTexture(imageNamed: "access_transmitting_iPad_icon")
                //                    }
                //                    self.CABT?.imageNode?.run(SKAction.fadeAlpha(to: 1.0, duration: 0.1))
                //                    self.CABT?.accessibilityLabel = NS_LocalizedString("Skoog", comment: "Do not translate.")
                //                    self.CABT?.accessibilityValue = NS_LocalizedString("Disconnected", comment: "Disconnected text")
                //                    self.CABT?.accessibilityHint = NS_LocalizedString("Double tap to open connection menu", comment: "connect menu AX hint text")
            }
            else {
                //                    self.CABT?.disconnectedTexture = SKTexture(imageNamed: "access_disconnected_outline_icon")
                //                    self.CABT?.imageNode?.run(SKAction.fadeAlpha(to: 1.0, duration: 0.1))
                //                    self.CABT?.accessibilityLabel = NS_LocalizedString("Skoog", comment: "Do not translate.")
                //                    self.CABT?.accessibilityValue = NS_LocalizedString("Disconnected", comment: "Disconnected text")
                //                    self.CABT?.accessibilityHint = NS_LocalizedString("Double tap to open connection menu", comment: "connect menu AX hint text")
                
                self.bluetoothUI?.skoogConnected = connected
                self.bluetoothUI?.skoogConnectionStatus(connected:connected)
            }
            //                self.CABT?.imageNode?.texture = self.CABT?.disconnectedTexture
            //                self.shouldEnterRecipientMode(status)
        }
    }
    
    open func peak(_ side: Side, _ peak: Double) {
        // stub
    }
    
    open func continuous(_ value: Double) {
        // stub
    }
    
    open func release(_ side: Side) {
        // stub
    }
    
    public func setReadyToPlay(value: Bool? = nil) {
        if let val = value {
            if val {
                if Settings.cabtMIDI.connected == .connectedToPeripheral {
                    //                    skoog.calibrating = false
                }
            }
            
            self.readyToPlay = val
            
            red.active = val
            blue.active = val
            yellow.active = val
            green.active = val
            orange.active = val
        }
    }
    
    @objc public func setReadyToPlay() {
        if Settings.cabtMIDI.connected == .connectedToPeripheral {
            self.readyToPlay = true
            //            skoog.calibrating = false
            red.active = true
            blue.active = true
            yellow.active = true
            green.active = true
            orange.active = true
        }
    }
    
    @objc open func skoogSearchTask() {
           midi.searchForSkwitch()
//        skoog.searchForSkoog()
        // if we have a BLE connection to Skoog this will trigger a calibration
        // If not, nothing will happen, it will fail gracefully.
    }
    
    @objc open func calibrateTask() {

        
    }
    
public func skoogConnectionStatus(_ connected: Bool) {
    bluetoothUI?.skoogConnectionStatus(connected: connected)
    
    if connected == true && Settings.cabtMIDI.connected == .connectedToPeripheral {
            midi.searchForSkwitch()
        //            Timer.scheduledTimer(timeInterval:1.5, target: self, selector: #selector(calibrateTask), userInfo: nil, repeats: false)

    }
    else {
        setReadyToPlay(value:false) //this has to happen beofew showing the CABT
    }
}
    
    public func refreshBTUI() {
        if bluetoothUI != nil {
            bluetoothUI!.view.removeFromSuperview()
            bluetoothUI!.removeFromParentViewController()
            bluetoothUI = nil
        }
        bluetoothUI = BluetoothMIDIViewController()
        bluetoothUI?.view.translatesAutoresizingMaskIntoConstraints = false
        
        Timer.scheduledTimer(timeInterval:0.1, target: self, selector: #selector(skoogSearchTask), userInfo: nil, repeats: false)
    }
}
