//#-hidden-code
// Copyright (C) 2016-2017 Parrot SA
//
//    Redistribution and use in source and binary forms, with or without
//    modification, are permitted provided that the following conditions
//    are met:
//    * Redistributions of source code must retain the above copyright
//      notice, this list of conditions and the following disclaimer.
//    * Redistributions in binary form must reproduce the above copyright
//      notice, this list of conditions and the following disclaimer in
//      the documentation and/or other materials provided with the
//      distribution.
//    * Neither the name of Parrot nor the names
//      of its contributors may be used to endorse or promote products
//      derived from this software without specific prior written
//      permission.
//
//    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//    FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
//    COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
//    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
//    OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
//    AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
//    OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
//    SUCH DAMAGE.
//
//  Created by Nicolas CHRISTE, <nicolas.christe@parrot.com>
//             Jerome BOUVARD, <jerome.bouvard@parrot.com>

//#-end-hidden-code
/*:#localized(key: "")
 Here you can send the parrot drone instructions one by one using Skwitch. Make sure you connect your drone and Skwitch, then tap "Run My Code" to start.
 
 Press once to take off, again to perform a command of your choice and once more to land.
 */
//#-hidden-code
import UIKit
import PlaygroundSupport
//waitDroneConnected()
droneSpeed = 20

public class ParrotSkoogListener: SkoogListener {
    
    
    
    public var lastRedValue = 0.0
    public var redCounter = 0
    public var lastBlueValue = 0.0
    public var blueCounter = 0
    public var lastYellowValue = 0.0
    public var yellowCounter = 0
    public var lastGreenValue = 0.0
    public var greenCounter = 0
    public var lastOrangeValue = 0.0
    public var orangeCounter = 0
    public var messageFilterRate = 40
    
    //#-code-completion(everything, hide)
    //#-code-completion(currentmodule, show)
    //#-code-completion(identifier, hide, expected, success)
    //#-code-completion(identifier, show, takeOff(), land(), wait(_:), .)
    //#-code-completion(identifier, show, turn(direction:angle:), TurnDirection, left, right)
    //#-code-completion(identifier, show, move(pitch:roll:gaz:yaw:duration:), move(direction:duration:), move(direction:), stopMoving(), MoveDirection, forward, backward, left, right, up, down)
    //#-code-completion(identifier, show, flip(direction:), FlipDirection, front, back, left, right)
    //#-code-completion(identifier, show, openGrabber(), closeGrabber())
    //#-code-completion(identifier, show, takePicture())
    //#-end-hidden-code
    public var isLanded = true
    public var counter : Int = 0
    
    func press() {
        if isLanded {
            takeOff()
            isLanded = false
            counter += 1
        }
        else if counter == 1 {
            //#-editable-code
            //Try adding your own instruction here!
            flip(direction: FlipDirection.front)
            //#-end-editable-code
            counter += 1
        }
        else {
            land()
            isLanded = true
            counter = 0
        }
        
    }
    //#-hidden-code
    
    public override func peak(_ side: Side, _ peak: Double) {
        press()
    }
    
    func didValueChange(_ currentValue: Double,_ lastValue: Double)->Bool {
        if currentValue != lastValue {
            return true
        }
        return false
    }
    
}
let parrotSkoogListener = ParrotSkoogListener()

while true {
    let event = waitNextMotionEvent()
}
//#-end-hidden-code
