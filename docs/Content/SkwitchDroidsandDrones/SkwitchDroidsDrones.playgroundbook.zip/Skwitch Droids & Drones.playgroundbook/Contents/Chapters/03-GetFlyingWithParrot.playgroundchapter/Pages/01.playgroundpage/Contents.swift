//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
/*:#localized(key: "")
 Welcome to the Skwitch-MeeBot playground!
 
 Here you can make MeeBot dance using Skwitch. Make sure you connect your bot and skwitch, then tap "Run My Code" to start.
 
 If Skwitch is connected it will send commands to MeeBot.
 */
//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), bendAndTwist(), shake(), wave(), swagger(), crazyDance(), moveToLeft(beats:), moveToRight(beats:), moveForward(beats:), moveBackward(beats:), raiseHands(beats:), bend(beats:), happy(beats:), split(beats:), skip(beats:), twist(beats:), stepAndShake(beats:), bendAndTwist(beats:), shake(beats:), wave(beats:), swagger(beats:), moveBody(moves:), moveBody(beats:moves:), moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:), moveLeftArm(angle:beats:), moveRightArm(angle:beats:), moveLeftLeg(angle:beats:), moveRightLeg(angle:beats:), moveLeftFoot(angle:beats:), moveRightFoot(angle:beats:), crazyDance(beats:))
//#-code-completion(keyword, show, for, func, if, var, while)
//#-hidden-code
public class GimuSkoogListener: SkoogListener {
    //#-end-hidden-code
    // Press Skwitch to call this function
    func press() {
        //#-editable-code
        split()
        //#-end-editable-code
    }
    
    //#-hidden-code
    public override func peak(_ side: Side, _ peak: Double) {
        DispatchQueue.main.async {
            self.press()
        }
    }
}

let gimuSkoogListener = GimuSkoogListener()

//#-end-hidden-code

