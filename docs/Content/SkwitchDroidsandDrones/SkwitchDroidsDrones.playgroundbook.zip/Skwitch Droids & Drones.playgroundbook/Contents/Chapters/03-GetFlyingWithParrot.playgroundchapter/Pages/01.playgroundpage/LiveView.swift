/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
import PlaygroundSupport
import UIKit

let world = loadGridWorld(named: "Stage")

setUpLiveViewWith(world , .lesson9)

let page = PlaygroundPage.current.liveView as! SceneController

extension SkoogListener {
    public var topLevelViewController : SceneController {
        return page
    }
        
    public func refreshBTUIExtension() {
        refreshBTUI()
//        refreshCalibrateButton()
//        self.topLevelViewController.view.addSubview(calibrateButton!)
        self.topLevelViewController.addChild(bluetoothUI!)
        self.topLevelViewController.view.addSubview((bluetoothUI?.view)!)

//        NSLayoutConstraint.activate([
//            calibrateButton!.topAnchor.constraint(equalTo: self.topLevelViewController.liveViewSafeAreaGuide.topAnchor, constant: 80),
//            calibrateButton!.leadingAnchor.constraint(equalTo: self.topLevelViewController.liveViewSafeAreaGuide.leadingAnchor, constant: 76),
//            ])

        NSLayoutConstraint.activate([
            bluetoothUI!.view.leadingAnchor.constraint(equalTo: self.topLevelViewController.liveViewSafeAreaGuide.leadingAnchor, constant: 20),
            bluetoothUI!.view.topAnchor.constraint(equalTo: self.topLevelViewController.liveViewSafeAreaGuide.topAnchor, constant: 18)
            ])
    }
}

extension BluetoothMIDIViewController {
    public var topLevelViewController : SceneController {
        return page
    }
    public func buttonCallback() {
        topLevelViewController.dismissAudioMenu()
        buttonCAllbackAction()
    }
    
//    public func showCalibration() {
//        topLevelViewController.loadingView.isHidden = false
//    }
//
//    public func hideCalibration() {
//        topLevelViewController.loadingView.isHidden = true
//    }
}

extension SceneController {
    public var btmvc: BluetoothMIDIViewController {
        return skoogListener.bluetoothUI!
    }
    open override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        btmvc.handleOutsideTouches()
    }
}

let skoogListener = SkoogListener()
skoogListener.refreshBTUIExtension()
