//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
/*:#localized(key: "")
 Now that you've got the hang of making MeeBot dance with Skwitch, lets set up some dance moves of your own!
 
 Try entering a dance command (e.g. split(), twist()) in the if statements in our press function. By adding more 'if else' statements you can queue up more
 dance moves for MeeBot to perform!
 */
//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), bendAndTwist(), shake(), wave(), swagger(), crazyDance(), moveToLeft(beats:), moveToRight(beats:), moveForward(beats:), moveBackward(beats:), raiseHands(beats:), bend(beats:), happy(beats:), split(beats:), skip(beats:), twist(beats:), stepAndShake(beats:), bendAndTwist(beats:), shake(beats:), wave(beats:), swagger(beats:), moveBody(moves:), moveBody(beats:moves:), moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:), moveLeftArm(angle:beats:), moveRightArm(angle:beats:), moveLeftLeg(angle:beats:), moveRightLeg(angle:beats:), moveLeftFoot(angle:beats:), moveRightFoot(angle:beats:), crazyDance(beats:))
//#-code-completion(keyword, show, for, func, if, var, while)
//#-hidden-code
public class GimuSkoogListener: SkoogListener {
    //#-end-hidden-code
    var counter : Int = 0
    // Press Skwitch to call this function
    func press() {
        if counter == 0 {
            //#-editable-code
            split()
            //#-end-editable-code
            counter += 1
        }
        else if counter == 1 {
            //#-editable-code
            
            //#-end-editable-code
            counter += 1
        }
            /*:
             Try adding more 'else if' statements to make MeeBot perform a series of dance moves!
             */
            //#-editable-code
            
            //#-end-editable-code
        else {
            //#-editable-code
            twist()
            //#-end-editable-code
            counter = 0
        }
    }
    //#-hidden-code
    public override func peak(_ side: Side, _ peak: Double) {
        DispatchQueue.main.async {
            self.press()
        }
    }
}

let gimuSkoogListener = GimuSkoogListener()
//#-end-hidden-code

