//
// Copyright © 2017 Apple Inc.  All rights reserved. 
// 

import UIKit

// Note: To use view controllers in a story board with Swift Playgrounds, 
// it currently requires the @objc declaration AND playgrounds requires the
// compiled storyboard, which this project automatically inserts into the 
// playground book's resource directory.

@objc(LiveViewControllerMeebot)
public class LiveViewControllerMeebot: UIViewController {
    
    public static func makeFromStoryboard() -> LiveViewControllerMeebot {
        let bundle = Bundle(for: LiveViewControllerMeebot.self)
        let storyboard = UIStoryboard(name: "Main", bundle: bundle)
        return storyboard.instantiateInitialViewController() as! LiveViewControllerMeebot
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()        
    }

    public override var prefersStatusBarHidden: Bool {
        return true
    }
}

