//
//  SKView+Utils.swift
//  DeathStarEscape
//
//  Created by Anthony Blackman on 2017-06-21.
//  Copyright © 2018 Sphero Inc. All rights reserved.
//

import SpriteKit

extension SKView {
    public static let renderingView = SKView()
}
