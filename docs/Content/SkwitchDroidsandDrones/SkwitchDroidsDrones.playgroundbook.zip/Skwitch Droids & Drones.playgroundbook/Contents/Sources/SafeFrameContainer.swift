//
//  SafeFrameContainer.swift
//  SupportingContent
//
//  Created by Larsson Burch on 5/6/19.
//  Copyright © 2019 Sphero Inc. All rights reserved.
//

import Foundation
import SpriteKit

public protocol SafeFrameContainer: class {
    var liveViewSafeAreaFrame: CGRect { get }
}
