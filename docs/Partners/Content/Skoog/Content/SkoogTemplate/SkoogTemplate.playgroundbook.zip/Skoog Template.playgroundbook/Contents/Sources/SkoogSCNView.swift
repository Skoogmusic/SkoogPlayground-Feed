//
//  SkoogSCNScene.swift
//  Skoog
//
//  Created by David Skulina on 17/03/2017.
//  Copyright © 2017 Skoogmusic Ltd. All rights reserved.
//

import Foundation
import UIKit
import SceneKit
import QuartzCore

protocol SkoogSCNViewDelegate: class {
	func peak(side: Side, peak: Double)
    func continuous(side: Side)
	func release(side: Side)
	
	var red : Side {get}
	var blue : Side {get}
	var yellow : Side {get}
	var green  : Side {get}
	var orange : Side {get}
	
	var readyToPlay : Bool {get set}
	var showRipples : Bool {get set}

}

public class SkoogSCNView: SCNView {
	
    weak var SCNdelegate : SkoogSCNViewDelegate?
    var node = SCNNode()
    var skoognode = SCNNode()
    var bluenode = SCNNode()

    var yRotation : Float = -.pi/4
    var bodyHit : Int = 0

    public var skoogSCNscene : SCNScene!
    
    public var spin = CABasicAnimation(keyPath: "rotation.w") // only animate the angle

    public let colors : [UIColor] = [   UIColor(colorLiteralRed: 218.0/255.0, green: 60.0/255.0, blue: 0.0, alpha: 1.0),         // red
                                        UIColor(colorLiteralRed: 55.0/255.0, green: 127.0/255.0, blue: 178.0/255.0, alpha: 1.0),   // blue
                                        UIColor(colorLiteralRed: 250.0/255.0, green: 217.0/255.0, blue: 0.0, alpha: 1.0),          // yellow
                                        UIColor(colorLiteralRed: 163.0/255.0, green: 203.0/255.0, blue: 0.0, alpha: 1.0),          // green
                                        UIColor(colorLiteralRed: 249.0/255.0, green: 154.0/255.0, blue: 0.0, alpha: 1.0)]          // orange
    
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override init(frame: CGRect, options: [String : Any]? = nil) {
        super.init(frame: frame, options: options)
        
        
        
        skoogSCNscene = SCNScene()
        self.scene = skoogSCNscene
        
        self.autoenablesDefaultLighting = true
        self.backgroundColor = UIColor.black.withAlphaComponent(CGFloat(0.0))
        
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0, y: 22, z: 2)
        cameraNode.eulerAngles = SCNVector3(x: -0.65, y: 0, z: 0)
        cameraNode.camera!.usesOrthographicProjection = true
        cameraNode.camera!.orthographicScale = 20

        skoogSCNscene.rootNode.addChildNode(cameraNode)
        
        let skoogScene = SCNScene(named: "skoogwireframefinal_0.4.scn")
        

        if skoogScene == nil {
			self.backgroundColor = UIColor.red
        }
        else{
            self.backgroundColor = UIColor.darkGray

            if let thisnode = skoogScene!.rootNode.childNode(withName: "Body", recursively: true) {
                node = thisnode
                skoogSCNscene.rootNode.addChildNode(node)
            }
            node.eulerAngles = SCNVector3(x: 0, y: -.pi/4, z:0)
			let nodezoom = Float(1.2)
            node.scale  = SCNVector3(x: nodezoom * 6.25, y: nodezoom * 1.5, z: nodezoom * 6.25)
        }
    }
    


    var prevPos : Float = 0.0
    var prevY : Float = 0.0
    var xPos : Float = 0.0
    var yPos : Float = 0.0
    var deltaSpin: Float = 0.0
    var deltaY: Float = 0.0

    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        for t in touches {
            xPos = 0.0
            deltaSpin = 0.0
            yPos = 0.0
            deltaY = 0.0
            
            let position :CGPoint = t.location(in: self)
            prevPos = xPos
            xPos = Float(position.x)
            deltaSpin = xPos - prevPos
            
            
            yPos = Float(position.y)
            prevY = yPos
            deltaY = prevY - yPos
            
            let yMax = Float(50.0)
            if deltaY > yMax {
                deltaY = 1.0
            }
            else if deltaY < -yMax {
                deltaY = -1.0
            }
            else {
                deltaY = deltaY/yMax
            }
            
            let contVal = Double(0.2 + 0.2 * deltaY)
			
            bodyHit = skoogHitTest(location: position)
            
			switch (bodyHit) {
            case 1: //Red
				SCNdelegate?.readyToPlay = true
				SCNdelegate?.peak(side: (SCNdelegate?.red)!, peak: 0.9)
                SCNdelegate?.red.value = contVal
                SCNdelegate?.red.rawValue = contVal
                SCNdelegate?.continuous(side: (SCNdelegate?.red)!)
            case 2: //Blue
                SCNdelegate?.readyToPlay = true
                SCNdelegate?.peak(side: (SCNdelegate?.blue)!, peak: 0.9)
                SCNdelegate?.blue.value = contVal
                SCNdelegate?.blue.rawValue = contVal
                SCNdelegate?.continuous(side: (SCNdelegate?.blue)!)
            case 3: //Yellow
                SCNdelegate?.readyToPlay = true
                SCNdelegate?.peak(side: (SCNdelegate?.yellow)!, peak: 0.9)
                SCNdelegate?.yellow.value = contVal
                SCNdelegate?.yellow.rawValue = contVal
                SCNdelegate?.continuous(side: (SCNdelegate?.yellow)!)
            case 4: //Green
                SCNdelegate?.readyToPlay = true
                SCNdelegate?.peak(side: (SCNdelegate?.green)!, peak: 0.9)
                SCNdelegate?.green.value = contVal
                SCNdelegate?.green.rawValue = contVal
                SCNdelegate?.continuous(side: (SCNdelegate?.green)!)
            case 5: //Orange
                SCNdelegate?.readyToPlay = true
                SCNdelegate?.peak(side: (SCNdelegate?.orange)!, peak: 0.9)
                SCNdelegate?.orange.value = contVal
                SCNdelegate?.orange.rawValue = contVal
                SCNdelegate?.continuous(side: (SCNdelegate?.orange)!)
            case 10: //Body was hit
                break
			default: break
			}
			
        }
    }
    
    
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            self.touchMoved(toPoint: t.location(in: self))
            let position :CGPoint = t.location(in: self)
            prevPos = xPos
            xPos = Float(position.x)
            deltaSpin = xPos - prevPos

            yPos = Float(position.y)
            deltaY = prevY - yPos
            
            
            let yMax = Float(50.0)
            if deltaY > yMax {
                deltaY = 1.0
            }
            else if deltaY < -yMax {
                deltaY = -1.0
            }
            else {
                deltaY = deltaY/yMax
            }
            
            let contVal = Double(0.2 + 0.2 * deltaY)

            
            yRotation = (yRotation + (deltaSpin * 0.01)).truncatingRemainder(dividingBy: 2.0 * .pi)
            if bodyHit > 0 {
                    node.eulerAngles = SCNVector3(x:0 , y: yRotation, z: 0)
                
                switch (bodyHit) {
                case 1: //Red
                    SCNdelegate?.red.value = contVal
                    SCNdelegate?.red.rawValue = contVal
                    SCNdelegate?.continuous(side: (SCNdelegate?.red)!)
                case 2: //Blue
                    SCNdelegate?.blue.value = contVal
                    SCNdelegate?.blue.rawValue = contVal
                    SCNdelegate?.continuous(side: (SCNdelegate?.blue)!)
                case 3: //Yellow
                    SCNdelegate?.yellow.value = contVal
                    SCNdelegate?.yellow.rawValue = contVal
                    SCNdelegate?.continuous(side: (SCNdelegate?.yellow)!)
                case 4: //Green
                    SCNdelegate?.green.value = contVal
                    SCNdelegate?.green.rawValue = contVal
                    SCNdelegate?.continuous(side: (SCNdelegate?.green)!)
                case 5: //Orange
                    SCNdelegate?.orange.value = contVal
                    SCNdelegate?.orange.rawValue = contVal
                    SCNdelegate?.continuous(side: (SCNdelegate?.orange)!)
                default:
                    SCNdelegate?.red.value = 0.0
                    SCNdelegate?.blue.value = 0.0
                    SCNdelegate?.yellow.value = 0.0
                    SCNdelegate?.green.value = 0.0
                    SCNdelegate?.orange.value = 0.0
                    SCNdelegate?.red.rawValue = 0.0
                    SCNdelegate?.blue.rawValue = 0.0
                    SCNdelegate?.yellow.rawValue = 0.0
                    SCNdelegate?.green.rawValue = 0.0
                    SCNdelegate?.orange.rawValue = 0.0

                    SCNdelegate?.continuous(side: (SCNdelegate?.red)!)
                    SCNdelegate?.continuous(side: (SCNdelegate?.blue)!)
                    SCNdelegate?.continuous(side: (SCNdelegate?.yellow)!)
                    SCNdelegate?.continuous(side: (SCNdelegate?.green)!)
                    SCNdelegate?.continuous(side: (SCNdelegate?.orange)!)
                }
            }
            
            
        }
        
    }
	
	public func skoogHitTest(location: CGPoint) -> Int {
		
		let hitResults = self.hitTest(location, options: nil)
		
		if hitResults.count > 0 {
			let hitnode = (hitResults.first)!.node
			//print("\nName of node hit is \(hitnode.name)")
            switch (hitnode.name!){
            case "Body":
//                self.backgroundColor = UIColor.white.withAlphaComponent(CGFloat(0.0))
                return 10
            case "Red":
//                self.backgroundColor = colors[0]
                return 1
            case "Blue":
//                self.backgroundColor = colors[1]
                return 2
            case "Yellow":
//                self.backgroundColor = colors[2]
                return 3
            case "Green":
//                self.backgroundColor = colors[3]
                return 4
            case "Orange":
//                self.backgroundColor = colors[4]
                return 5
            default:
                return 10
            }
		}
		else {
			//self.backgroundColor = UIColor.purple
			return 0
		}
	}
	
//	public func loadAllNodesFromScene() {
//		let node = SCNNode()
//		let skoogNodeArray = scene.rootNode.childNodes
//
//		for childNode in skoogNodeArray {
//			node.addChildNode(childNode as SCNNode)
//		}
//		skoogSCNscene.rootNode.addChildNode(node)
//	}
	
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
	

    func touchDown(atPoint pos : CGPoint) {


    }

    func touchMoved(toPoint pos : CGPoint) {
    }
    
    func touchUp(atPoint pos : CGPoint) {
        //Stop all sides playing
		SCNdelegate?.release(side: (SCNdelegate?.red)!)
        SCNdelegate?.release(side: (SCNdelegate?.blue)!)
        SCNdelegate?.release(side: (SCNdelegate?.yellow)!)
        SCNdelegate?.release(side: (SCNdelegate?.green)!)
        SCNdelegate?.release(side: (SCNdelegate?.orange)!)
        
        SCNdelegate?.red.value = 0.0
        SCNdelegate?.blue.value = 0.0
        SCNdelegate?.yellow.value = 0.0
        SCNdelegate?.green.value = 0.0
        SCNdelegate?.orange.value = 0.0
        SCNdelegate?.red.rawValue = 0.0
        SCNdelegate?.blue.rawValue = 0.0
        SCNdelegate?.yellow.rawValue = 0.0
        SCNdelegate?.green.rawValue = 0.0
        SCNdelegate?.orange.rawValue = 0.0
        
        SCNdelegate?.continuous(side: (SCNdelegate?.red)!)
        SCNdelegate?.continuous(side: (SCNdelegate?.blue)!)
        SCNdelegate?.continuous(side: (SCNdelegate?.yellow)!)
        SCNdelegate?.continuous(side: (SCNdelegate?.green)!)
        SCNdelegate?.continuous(side: (SCNdelegate?.orange)!)
        
        bodyHit = 0

    }
    
}
